<?php

if (isset($_POST['res_nic']) && isset($_POST['res_name']) && isset($_POST['res_contact']) && isset($_POST['res_email']) && $_POST['card_no'] && $_POST['reservedSeats']) {
    include 'utilities/enccon/mql/connection.php';
    $res_nic = $_POST['res_nic'];
    $res_name = $_POST['res_name'];
    $res_contact = $_POST['res_contact'];
    $res_email = $_POST['res_email'];
    $card_no = $_POST['card_no'];
    $reservedSeats = $_POST['reservedSeats'];
    $masked_card_no = substr($card_no, 0, 6) . "********" . substr($card_no, 14, 2);

    //$SeatArr = split("\,", $reservedSeats);
    $SeatArr = explode(",", $reservedSeats);
    $SeatArrReserved = array();
    $totalPurchasedPrice = 0;
    $seatsBooked = false;

    for ($i = 0; $i < sizeOf($SeatArr); $i++) {
        //check whether the seat is available		
        $sql1 = "SELECT price FROM seat where res_status='Available' and seatNo='$SeatArr[$i]' and price>0";
        $result = mysqli_query($conn, $sql1);
        if ($row = mysqli_fetch_assoc($result)) {
            
        } else {
            $seatsBooked = true;
        }
    }

    if (!$seatsBooked) {
    $reservationDetails="";
        for ($i = 0; $i < sizeOf($SeatArr); $i++) {
            
//            $reservationDetails="\t Seat No \tOriginal Amount \tDiscounted Amount";
            

            //check whether the seat is available		
            $sql1 = "SELECT price FROM seat where res_status='Available' and seatNo='$SeatArr[$i]' and price>0";
            $result = mysqli_query($conn, $sql1);
            if ($row = mysqli_fetch_assoc($result)) {

                $price = $row["price"];
                $purchasedPrice = $price;
                $sql2 = "Update seat set res_nic='$res_nic',res_name='$res_name',res_contact='$res_contact',res_email='$res_email',card_no='$card_no',res_datetime=now(),res_status='Reserved', purchasedPrice=$purchasedPrice where seatNo='$SeatArr[$i]' and res_status='Available'";
                mysqli_query($conn, $sql2);
                array_push($SeatArrReserved, $SeatArr[$i]);
                $totalPurchasedPrice+=$purchasedPrice;
                
                $reservationDetails.="\tSeat No: ".$SeatArr[$i]."\t(LKR ".number_format($purchasedPrice)."/-)\n\n";
            }
        }

        $seatNoforPrinting = "";


        for ($x = 0; $x < sizeOf($SeatArrReserved); $x++) {
//            $SeatNoDetails = split("_", $SeatArrReserved[$x]);
            $SeatNoDetails = explode("_", $SeatArrReserved[$x]);
            $floor = "";
            if ($SeatNoDetails[0] == "G") {
                $floor = "Ground Floor";
            }
            $seatNoforPrinting.="\n\t" . ($x + 1) . ") " . $floor . " - " . $SeatArrReserved[$x];
        }


        if ($totalPurchasedPrice > 0) {
//            $msgToCustomer = "Dear Customer,\n\n SUCCESS! \n\n Your reservation of the following seats for ARSIKLAND is currently being processed. \n\n You have successfully reserved following seats for the Event." . $seatNoforPrinting . "\n\n LKR " . number_format($totalPurchasedPrice) . "/- the total amount applicable for your ticket purchases will be \n charged from your given NDB credit card $masked_card_no \n after confirmation from the NDB Bank Card Center.\n\nThank You.\nNDB Card Center";
            $msgToCustomer = "Dear $res_name,\n\n SUCCESS! \n\n Your reservation of the following seats for Clarence Marians Musical Extravaganza is currently being  processed. \n\n" . $reservationDetails." Total : LKR " . number_format($totalPurchasedPrice)."/-\n\n Please note that this is not a confirmation. \n\n One of our agents will contact you shortly for confirmation and the delivery of the tickets. \n\n Thank you for using the NDB Good Life Credit Card.\n\n We hope you enjoy AVENGERS! \n\nRegards, \n\nNDB Bank";
            echo $msgToCustomer;


            $msgToCardCenter = "Dear Card Center,\n\n $res_name ($res_contact) has successfully reserved following seats for the Event." . $seatNoforPrinting . "\n\n LKR " . number_format($totalPurchasedPrice) . "/- the total amount applicable for ticket purchases should be \n charged from NDB credit card $card_no \n. Please Confirm.\n\nThank You.";
            
            if ($sendEmail) {
                require_once "PHPMailer/PHPMailerAutoload.php";
                
                //--------------------------------send to customer-----------------//
                $toMail = $res_email;
                $toName = $res_name;
                $emailsubject = "AVENGERS : ENDGAME - NDB Bank - Seat Booking";
                $message = $msgToCustomer;
                
                
                $mail = new PHPMailer;
                //loading from connection file
                $mail->SMTPDebug = $smtpDebug;
                $mail->isSMTP();
                $mail->Host = $smtpHost;
                $mail->SMTPAuth = $SMTPAuth;
                $mail->Username = $MailUsername;
                $mail->Password = $MailPassword;
                $mail->SMTPSecure = $SMTPSecure;
                $mail->Port = $TCPPort;
                $mail->From = $EmailFrom;
                $mail->FromName = $EmailFromName;
                $mail->isHTML($isHTML);

                //loading from this file
                $mail->addAddress($toMail, $toName);
                $mail->Subject = $emailsubject;
                $mail->Body = $message;
                $mail->AltBody = $message;

                if (!$mail->send()) {
                    echo "Mailer Error: " . $mail->ErrorInfo;
                } else {
//                    echo "Message has been sent successfully";
                }
                //--------------------------------End of send to customer-----------------//


                //--------------------------------send to cards-----------------//
                $toMail = $cardCenterEmail_1;
                $toName = $cardCenterName_1;
                $emailsubject = "AVENGERS : ENDGAME - NDB Bank - Seat Booking";
                $message = $msgToCardCenter;

                //send to Cards
                $cc1Mail = $cardCenterEmail_2;
                $cc1Name = $cardCenterName_2;
                $cc2Mail = $cardCenterEmail_3;
                $cc2Name = $cardCenterName_3;
                $cc3Mail = $cardCenterEmail_4;
                $cc3Name = $cardCenterName_4;
                $cc4Mail = $cardCenterEmail_5;
                $cc4Name = $cardCenterName_5;

                $mail2 = new PHPMailer;
                //loading from connection file
                $mail2->SMTPDebug = $smtpDebug;
                $mail2->isSMTP();
                $mail2->Host = $smtpHost;
                $mail2->SMTPAuth = $SMTPAuth;
                $mail2->Username = $MailUsername;
                $mail2->Password = $MailPassword;
                $mail2->SMTPSecure = $SMTPSecure;
                $mail2->Port = $TCPPort;
                $mail2->From = $EmailFrom;
                $mail2->FromName = $EmailFromName;
                $mail2->isHTML($isHTML);

                //loading from this file
                $mail2->AddCC($cc1Mail, $cc1Name);
                $mail2->AddCC($cc2Mail, $cc2Name);
                $mail2->AddCC($cc3Mail, $cc3Name);
                $mail2->AddCC($cc4Mail, $cc4Name);
                $mail2->addAddress($toMail, $toName);
                $mail2->Subject = $emailsubject;
                $mail2->Body = $message;
                $mail2->AltBody = $message;

                if (!$mail2->send()) {
                    echo "Mailer Error: " . $mail2->ErrorInfo;
                } else {
//                    echo "Message has been sent successfully";
                }
                //--------------------------------End of send to cards-----------------//

            }
        } else {
            echo "Booking Unsuccessfull. Please Try Again.";
        }
    } else {
        echo "Some of the seats that you have selected are already reserved. Please Try Again.";
    }
    mysqli_close($conn);
} else {
    print "Something went wrong";
}
?>