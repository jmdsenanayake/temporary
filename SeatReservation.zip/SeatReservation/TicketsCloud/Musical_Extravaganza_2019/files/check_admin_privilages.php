<?php

$isValidAdmin = false;

if (isset($_POST['user']) && $_POST['pwd']) {
    $user = $_POST['user'];
    $pwd = $_POST['pwd'];

    if (strcmp($user, "MariEvent@2019") == 0 && strcmp($pwd, "MariNelu19#NDB_SRC") == 0) {
        $isValidAdmin = true;
    }
}
?>