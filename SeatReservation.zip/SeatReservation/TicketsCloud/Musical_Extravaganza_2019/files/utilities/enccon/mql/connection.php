<?php

$servername = "localhost";
$username = "root";
$password = "123";
$dbname = "seatbooking";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

//Configurations Related to sending emails
//allowSendingMails
$sendEmail = false;

//Enable SMTP debugging. 
$smtpDebug = 3; //3 for enabling 0 for disabling

//Set SMTP host name       
$smtpHost = "10.96.198.30";

//Set this to true if SMTP host requires authentication to send email
$SMTPAuth = true;

//Provide username and password     
$MailUsername = "support_admin@ndbsupport.int";
$MailPassword = "NDB@123";

//If SMTP requires TLS encryption then set it
$SMTPSecure = "tls";

//Set TCP port to connect to 
$TCPPort = 587;

$EmailFrom = "cards@ndbbank.com";
$EmailFromName = "NDB Cards";

$isHTML=true;

//$cardCenterEmail_1="zeyan.hameed@ndbbank.com";
//$cardCenterName_1="Zeyan Hameed";
//
//$cardCenterEmail_2="pushpani.wanniarachchi@ndbbank.com";
//$cardCenterName_2="Pushpani Wanniarachchi";
//
//$cardCenterEmail_3="ruwanara.weerakoon@ndbbank.com";
//$cardCenterName_3="Ruwanara Weerakoon";
//
//$cardCenterEmail_4="prinji.shachinthi@ndbbank.com";
//$cardCenterName_4="Prinji Shachinthi";
//
//$cardCenterEmail_5="ravishka.rathnayake@ndbbank.com";
//$cardCenterName_5="Ravishka Rathnayake";

$cardCenterEmail_1="janaka.senanayake@ndbbank.com";
$cardCenterName_1="Janaka Senanayake";

$cardCenterEmail_2="janaka.senanayake@ndbbank.com";
$cardCenterName_2="Janaka Senanayake";

$cardCenterEmail_3="janaka.senanayake@ndbbank.com";
$cardCenterName_3="Janaka Senanayake";

$cardCenterEmail_4="janaka.senanayake@ndbbank.com";
$cardCenterName_4="Janaka Senanayake";

$cardCenterEmail_5="janaka.senanayake@ndbbank.com";
$cardCenterName_5="Janaka Senanayake";
?>