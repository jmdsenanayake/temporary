<?php

if (isset($_POST["res_nic"]) && isset($_POST["res_name"]) && isset($_POST["res_contact"]) && isset($_POST["res_email"])) {
    include 'utilities/enccon/mql/connection.php';
    $res_nic = $_POST['res_nic'];
    $res_name = $_POST['res_name'];
    $res_contact = $_POST['res_contact'];
    $res_email = $_POST['res_email'];
    $sql2 = "INSERT INTO nocardlist (contactName,contactNo,contactEmail,contactNIC,currentDateTime) values ('$res_name','$res_contact','$res_email','$res_nic',now())";
    mysqli_query($conn, $sql2);
    mysqli_close($conn);

    if ($sendEmail) {
        require_once "PHPMailer/PHPMailerAutoload.php";
        $msgToCardCenter = "Dear Card Center,\n\n Following person is interested on a Credit Card.\n\n"
                . "Name : $res_name \n\n"
                . "Contact No : $res_contact \n\n"
                . "NIC : $res_nic \n\n"
                . "Email : $res_email \n\nThank You.";

        $toMail = $cardCenterEmail_1;
        $toName = $cardCenterName_1;
        $emailsubject = "Mariens Unplugged - NDB Bank - New Customer";
        $message = $msgToCardCenter;

        //send to Cards
        $cc1Mail = $cardCenterEmail_2;
        $cc1Name = $cardCenterName_2;
        $cc2Mail = $cardCenterEmail_3;
        $cc2Name = $cardCenterName_3;
        $cc3Mail = $cardCenterEmail_4;
        $cc3Name = $cardCenterName_4;
        $cc4Mail = $cardCenterEmail_5;
        $cc4Name = $cardCenterName_5;

        $mail2 = new PHPMailer;
        //loading from connection file
        $mail2->SMTPDebug = $smtpDebug;
        $mail2->isSMTP();
        $mail2->Host = $smtpHost;
        $mail2->SMTPAuth = $SMTPAuth;
        $mail2->Username = $MailUsername;
        $mail2->Password = $MailPassword;
        $mail2->SMTPSecure = $SMTPSecure;
        $mail2->Port = $TCPPort;
        $mail2->From = $EmailFrom;
        $mail2->FromName = $EmailFromName;
        $mail2->isHTML($isHTML);

        //loading from this file
        $mail2->AddCC($cc1Mail, $cc1Name);
        $mail2->AddCC($cc2Mail, $cc2Name);
        $mail2->AddCC($cc3Mail, $cc3Name);
        $mail2->AddCC($cc4Mail, $cc4Name);
        $mail2->addAddress($toMail, $toName);
        $mail2->Subject = $emailsubject;
        $mail2->Body = $message;
        $mail2->AltBody = $message;

        if (!$mail2->send()) {
            echo "Mailer Error: " . $mail2->ErrorInfo;
        } else {
//                    echo "Message has been sent successfully";
        }
    }


    print "Added to Contact";
} else {
    echo "Something went wrong";
}
?>