<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Clarence Marians Musical Extravaganza</title>
        <script src="js/jquery.min.js"></script>
        <script src="js/skel.min.js"></script>
        <script src="js/skel-layers.min.js"></script>
        <script src="js/init.js"></script>
        <noscript>
        <link rel="stylesheet" href="css/skel.css" />
        <link rel="stylesheet" href="css/style.css" />
        <link rel="stylesheet" href="css/style-xlarge.css" />
        </noscript>

        <!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->

        <link href="css/bootstrap-toggle.min.css" rel="stylesheet">
        <link href="css/toggle-button.css" rel="stylesheet">				
        <link href="css/bootstrap.css" rel="stylesheet" >
        <link href="css/bootstrap-select.css" rel="stylesheet" >

        <script src="js/jquery-3.3.1.min.js"></script>
        <script src="js/bootstrap-toggle.min.js"></script>
        <script src="js/bootstrap.js"></script>
        <script src="js/bootstrap-select.js"></script>		
        <script src="js/jspdf.min.js"></script>	
        <script src="js/sweetalert.min.js"></script>	
        <style>
            .floorPlan tr, .floorPlan td{
                border: 0px;
            }

            body {
                background-image: radial-gradient(circle, rgba(255, 254, 208,0), rgba(153, 30, 84,1));
            }

        </style>

        <script>
            var totalPrice = 0;
            var reserevedSeatsNo = [];
            var availalbeSeatsCountArr = {5000: 0, 3000: 0, 2000: 0, 1500: 0, 1000: 0, 0: 0};

            //collorcodes            
            var color5000 = "#66ff9d";
            var color3000 = "#800080";
            var color2000 = "#f9a602";
            var color1500 = "#6f7bca";
            var color1000 = "#cca700";
            var colorNotAvailable = "#000000";
            var colorReserved = "#FF0000";

            function docReady() {
                seatSummaryDisplay();

                $("#legend5000").css("background-color", color5000);
                $("#legend3000").css("background-color", color3000);
                $("#legend2000").css("background-color", color2000);
                $("#legend1500").css("background-color", color1500);
                $("#legend1000").css("background-color", color1000);
                $("#legendNotAvailalbe").css("background-color", colorNotAvailable);
                $("#legendReserved").css("background-color", colorReserved);
                checkReservedSeats();
                $('#reservedSeatsShow').val('');
                $.ajax({
                    type: "POST",
                    url: "controller.php",
                    data: "&functionName=get_available_seats_price",
                    dataType: "json",
                    success: function (data) {

                        var seatsArr = data;
                        for (var i = 0; i < seatsArr.length; i++) {

                            var checkbox = $("#" + seatsArr[i].seatNo);
                            var price = seatsArr[i].price;
                            checkbox.val(price);
                            // checkbox.attr("disabled", true);
                            var spanOfChkBox = checkbox.parent().children()[1].id;
                            if (price === "5000") {
                                $("#" + spanOfChkBox).css({"background": color5000});
                            }
                            if (price === "3000") {
                                $("#" + spanOfChkBox).css({"background": color3000});
                            }
                            if (price === "2000") {
                                $("#" + spanOfChkBox).css({"background": color2000});
                            }
                            if (price === "1500") {
                                $("#" + spanOfChkBox).css({"background": color1500});
                            }
                            if (price === "1000") {
                                $("#" + spanOfChkBox).css({"background": color1000});
                            }
                            if (price === "0") {
                                $("#" + spanOfChkBox).css({"background": colorNotAvailable});
                                checkbox.attr("disabled", true);

                            }
                        }
                    }
                });

                totalPrice = 0;
                reserevedSeatsNo = [];
                $('#res_nic').val("");
                $('#res_name').val("");
                $('#res_contact').val("");
                $('#res_email').val("");
                $('#res_card').val("");
                $('#totValueShow').val("");
                $('#totValue').val("");

                $('.switch-input').each(function () {
                    this.checked = false;
                });

                $('.switch-yes-no').each(function () {
                    var seatPrice = $($(this).html()).val();
                    if (seatPrice === 'on') {
                        this.style = "background:" + colorReserved;

                    }
                });
            }
            
            function promptForStaffAcOrCC() {
                swal({
                    title: "What is your payment method?",
                    icon: "warning", buttons: {
                        StaffAcc: 'Staff Account',
                        CreditCard: 'Credit Card!'
                    },
                    dangerMode: true,
                }).then(function (isConfirm) {
                    if (isConfirm === "CreditCard") {
                        location.href="cards.php";
                    }
                    else if (isConfirm === "StaffAcc") {

                    }
                    else {
                        promptForStaffAcOrCC();
                    }
                });
            }

            $(document).ready(function () {

                promptForStaffAcOrCC();

                docReady();

                $("#res_card").mouseover(function () {
                    var x = document.getElementById("res_card");
                    x.type = "text";
                });

                $("#res_card").mouseout(function () {
                    var x = document.getElementById("res_card");
                    x.type = "password";
                });

                $("#res_contact").keyup(function () {
                    if (this.value.match(/[^0-9]/g)) {
                        this.value = this.value.replace(/[^0-9/.]/g, '');
                    }
                });

                $("#res_card").keyup(function () {
                    if (this.value.match(/[^0-9]/g)) {
                        this.value = this.value.replace(/[^0-9/.]/g, '');
                    }
                });

                $("#res_name").keyup(function () {
                    if (this.value.match(/[^a-zA-Z ]/g)) {
                        this.value = this.value.replace(/[^a-zA-Z /.]/g, '');
                    }
                });

                $("#res_nic").keyup(function () {
                    if (this.value.match(/[^0-9vV]/g)) {
                        this.value = this.value.replace(/[^0-9vV/.]/g, '');
                    }
                });

                $('.switch-input').change(function () {
                    if (!isNaN($(this).val())) {
                        var seatPrice = parseFloat($(this).val());
                        if (this.checked) {
                            if (reserevedSeatsNo.length === 20) {
                                swal({
                                    title: 'You can not reserve more than 20 seats!',
                                    icon: 'error',
                                });
                                this.checked = false;
                            } else {
                                totalPrice += seatPrice;
                                reserevedSeatsNo.push("" + this.id);
                            }


                        }
                        else {
                            totalPrice -= seatPrice;
                            var index = reserevedSeatsNo.indexOf("" + this.id);
                            if (index > -1) {
                                reserevedSeatsNo.splice(index, 1);
                            }
                        }

                        $("#reservedSeats").val(reserevedSeatsNo.toString());
                        $("#reservedSeatsShow").val(reserevedSeatsNo.toString());
                        $("#totValue").val(totalPrice);
                        $("#totValueShow").val(totalPrice);
                    }


                });

                $('.switch-yes-no').mouseover(function () {
                    var seatPrice = $($(this).html()).val();
                    if (seatPrice === 'on') {
                        this.title = "Reserved";

                    }
                    else {

                        if (seatPrice === '0') {

                            this.title = "N/A";
                        }
                        else {
                            this.title = "Price LKR " + seatPrice + "/-";
                        }
                    }
                });

                $('#reserveSeats').click(function () {
                    if ($('#res_name').val() !== "" && $('#res_contact').val() !== "" && $('#res_email').val() !== "" && $('#res_card').val() !== "" && $('#res_nic').val()) {
                        if ($('#res_contact').val().length === 10) {
                            if (validateEmail($('#res_email').val())) {
                                if (reserevedSeatsNo.length > 0) {
                                    if (reserevedSeatsNo.length <= 20) {
                                        var cardNo = $('#res_card').val();
                                        if (cardNo.length === 12) {                                           
                                            
                                                var values = "&res_nic=" + $('#res_nic').val() + "&res_name=" + $('#res_name').val() + "&res_contact=" + $('#res_contact').val() + "&res_email=" + $('#res_email').val() + "&card_no=" + cardNo + "&reservedSeats=" + $('#reservedSeats').val() + "&functionName=reserve_seats";
                                                $.ajax({
                                                    type: "POST",
                                                    url: "controller.php",
                                                    data: values,
                                                    dataType: "text", success: function (data) {
                                                        if (data.includes("Please Try Again")) {
                                                            swal({
                                                                title: data,
                                                                icon: 'error',
                                                            });
                                                            var res_name=$('#res_name').val();
                                                            var res_contact=$('#res_contact').val();
                                                            var res_email=$('#res_email').val();
                                                            docReady();
                                                            $('#res_name').val(res_name);
                                                            $('#res_contact').val(res_contact);
                                                            $('#res_email').val(res_email);
                                                        }
                                                        else {
                                                            var pdf = new jsPDF();
                                                            pdf.setFontSize(12);
                                                            pdf.setProperties({
                                                                title: 'Mariens Unplugged with NDB',
                                                                subject: 'Mariens Unplugged with NDB',
                                                                author: 'NDBSRC 2019'
                                                            });
                                                            pdf.text(10, 25, data);
                                                            pdf.save();
                                                            swal({
                                                                title: 'Reservation is being Processed',
                                                                text: data,
                                                                icon: 'success',
                                                            });
                                                            docReady();
                                                        }
                                                    }
                                                });
                                            

                                        }
                                        else {
                                            swal({
                                                title: 'Invalid Staff Account Number',
                                                icon: 'error',
                                            });

                                        }

                                    }
                                    else {
                                        swal({
                                            title: 'You can not reserve more than 20 seats!',
                                            icon: 'error',
                                        });
                                    }
                                }
                                else {
                                    swal({
                                        title: 'Please select seat(s)!',
                                        icon: 'error',
                                    });
                                }
                            }
                            else {
                                swal({
                                    title: 'Invalid Email!',
                                    icon: 'error',
                                });
                            }
                        }
                        else {
                            swal({
                                title: 'Contact number should contain 10 digits!',
                                icon: 'error',
                            });
                        }
                    }
                    else {
                        swal({
                            title: 'Please enter required details',
                            icon: 'error',
                        });
                    }
                });                

                $('.closeModal').click(function () {
                    $('#new_nic').val("");
                    $('#new_name').val("");
                    $('#new_contact').val("");
                    $('#new_email').val("");
                    location.reload();
                });

                $('#floorList').on('change', function (e) {
                    var selectedFloor = $('#floorList :selected').text();
                    if (selectedFloor === 'Select Floor') {
                        //hide all
                        $('#groundFloor').hide();
                        $('#balcony1').hide();
                        $('#balcony2').hide();
                        $('#legend').hide();
                        $('#formDetails').hide();
                    }
                    else {
                        checkReservedSeats();
                        $('#formDetails').show();
                        $('#legend').show();

                        if (selectedFloor === 'Ground') {
                            $('#groundFloor').show();
                            $('#balcony1').hide();
                            $('#balcony2').hide();

                        }
                        else if (selectedFloor === '1st Balcony') {
                            $('#groundFloor').hide();
                            $('#balcony1').show();
                            $('#balcony2').hide();
                        }
                        else if (selectedFloor === '2nd Balcony') {
                            $('#groundFloor').hide();
                            $('#balcony1').hide();
                            $('#balcony2').show();
                        }
                    }



                });

            });

            function seatSummaryDisplay() {
                $.ajax({
                    type: "POST",
                    url: "controller.php",
                    data: "&functionName=getSeatSummary",
                    dataType: "json",
                    success: function (data) {
                        for (var i = 0; i < data.length; i++) {
                            availalbeSeatsCountArr[data[i]['seatPrice']] = data[i]['availableSeats'];
                        }

                        $('#seat5000').html(availalbeSeatsCountArr[5000]);
                        $('#seat3000').html(availalbeSeatsCountArr[3000]);
                        $('#seat2000').html(availalbeSeatsCountArr[2000]);
                        $('#seat1500').html(availalbeSeatsCountArr[1500]);
                        $('#seat1000').html(availalbeSeatsCountArr[1000]);

                        $('#seat5000Availability').html((availalbeSeatsCountArr[5000] > 0) ? "<strong><font color='green'>Available</font></strong>" : "<strong><font color='red'>Sold Out!</font></strong>");
                        $('#seat3000Availability').html((availalbeSeatsCountArr[3000] > 0) ? "<strong><font color='green'>Available</font></strong>" : "<strong><font color='red'>Sold Out!</font></strong>");
                        $('#seat2000Availability').html((availalbeSeatsCountArr[2000] > 0) ? "<strong><font color='green'>Available</font></strong>" : "<strong><font color='red'>Sold Out!</font></strong>");
                        $('#seat1500Availability').html((availalbeSeatsCountArr[1500] > 0) ? "<strong><font color='green'>Available</font></strong>" : "<strong><font color='red'>Sold Out!</font></strong>");
                        $('#seat1000Availability').html((availalbeSeatsCountArr[1000] > 0) ? "<strong><font color='green'>Available</font></strong>" : "<strong><font color='red'>Sold Out!</font></strong>");
                    }
                });
            }

            function checkReservedSeats() {
                $.ajax({
                    type: "POST",
                    url: "controller.php",
                    data: "&functionName=check_reserved_seats",
                    dataType: "json",
                    success: function (data) {
                        var seatNosArr = data;
                        for (var i = 0; i < seatNosArr.length; i++) {
                            var checkbox = $("#" + seatNosArr[i].seatNo);
                            checkbox.attr("disabled", true);
                            if (checkbox.is(":checked")) {
                                checkbox.prop('checked', false);
                                $(checkbox).trigger("change");
                            }

                            var spanOfChkBox = checkbox.parent().children()[1].id;
                            $("#" + spanOfChkBox).css({"background": colorReserved});
                            // spanOfChkBox.style = "background:red";
                            $("#" + spanOfChkBox).attr('checked', false);

                            $("#" + spanOfChkBox).hide();
                        }
                    }
                });
            }

            function validateEmail(email) {
                var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                return re.test(String(email).toLowerCase());
            }

            function initiateCreditCardPrompt() {
                swal({
                    title: "Do you have a NDB Good Life Credit Card?",
                    icon: "warning", buttons: {
                        NoCard: 'No, I do not have',
                        YesCard: 'Yes, I have!'
                    },
                    dangerMode: true,
                }).then(function (isConfirm) {
                    if (isConfirm === "NoCard") {
                        $('#myModal').modal({
                            keyboard: false,
                            backdrop: 'static',
                        })
                    }
                    else if (isConfirm === "YesCard") {

                    }
                    else {
                        initiateCreditCardPrompt();
                    }
                });
            }

        </script>
    </head>
    <body>
        <div style="text-align: center"><img src="img/header.jpg" width="100%" ></div>
        <br/>    

        <div class="row">       
            <div class="col-sm-5"></div>
            <div class="col-sm-2">
                <select name="floorList" form="floorListForm" class="selectpicker" id="floorList" required>
                    <option>Select Floor</option>
                    <option>Ground</option>
                    <option>1st Balcony</option>
                    <option>2nd Balcony</option>  
                </select>
            </div>
            <div class="col-sm-5"></div>

        </div>
        <br/>

        <div class="row" id="legend" style="display: none" align="center">
            <div class="col-sm-3"></div>
            <div class="col-sm-6">
                <table class="table">
                    <tr>                                
                        <td id="legend5000" align="center" style="color:black; font-size:small" width="12.5%">5,000/-</td>
                        <td id="legend3000" align="center" style="color:white; font-size:small" width="12.5%">3,000/-</td>
                        <td id="legend2000" align="center" style="color:white; font-size:small" width="12.5%">2,000/-</td>
                        <td id="legend1500" align="center" style="color:white; font-size:small" width="12.5%">1,500/-</td>
                        <td id="legend1000" align="center" style="color:white; font-size:small" width="12.5%">1,000/-</td>
                        <td id="legendReserved" align="center" style="color:white; font-size:small" width="12.5%">Reserved</td>
                        <td id="legendNotAvailalbe" align="center" style="color:white; color:white; font-size:small" width="12.5%">NA</td>
                    </tr>
                </table>
            </div>
            <div class="col-sm-3"></div>
        </div>	
        <br/>


        <div style="overflow:auto ; display:none" align="center" id="groundFloor">
            <table class="floorPlan" style="color:black">
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_A_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_A_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_A_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_A_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_A_5"></span><span class="switch-handle"></span></label></td>
                    <td>A</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_A_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_A_7"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_A_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_A_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_A_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_A_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_A_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_A_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_A_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_A_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_A_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_A_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_A_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_A_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_A_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_A_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_G_A_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_23"/><span class="switch-label" data-on="23" data-off="23" id="Span_G_A_23"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_24"/><span class="switch-label" data-on="24" data-off="24" id="Span_G_A_24"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_25"/><span class="switch-label" data-on="25" data-off="25" id="Span_G_A_25"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_26"/><span class="switch-label" data-on="26" data-off="26" id="Span_G_A_26"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_27"/><span class="switch-label" data-on="27" data-off="27" id="Span_G_A_27"></span><span class="switch-handle"></span></label></td>
                    <td>A</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_28"/><span class="switch-label" data-on="28" data-off="28" id="Span_G_A_28"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_29"/><span class="switch-label" data-on="29" data-off="29" id="Span_G_A_29"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_30"/><span class="switch-label" data-on="30" data-off="30" id="Span_G_A_30"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_31"/><span class="switch-label" data-on="31" data-off="31" id="Span_G_A_31"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_32"/><span class="switch-label" data-on="32" data-off="32" id="Span_G_A_32"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>		
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>

                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_B_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_B_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_B_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_B_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_B_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_B_6"></span><span class="switch-handle"></span></label></td>
                    <td>B</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_B_7"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_B_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_B_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_B_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_B_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_B_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_B_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_B_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_B_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_B_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_B_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_B_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_B_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_B_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_B_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_G_B_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_23"/><span class="switch-label" data-on="23" data-off="23" id="Span_G_B_23"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_24"/><span class="switch-label" data-on="24" data-off="24" id="Span_G_B_24"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_25"/><span class="switch-label" data-on="25" data-off="25" id="Span_G_B_25"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_26"/><span class="switch-label" data-on="26" data-off="26" id="Span_G_B_26"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_27"/><span class="switch-label" data-on="27" data-off="27" id="Span_G_B_27"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_28"/><span class="switch-label" data-on="28" data-off="28" id="Span_G_B_28"></span><span class="switch-handle"></span></label></td>
                    <td>B</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_29"/><span class="switch-label" data-on="29" data-off="29" id="Span_G_B_29"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_30"/><span class="switch-label" data-on="30" data-off="30" id="Span_G_B_30"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_31"/><span class="switch-label" data-on="31" data-off="31" id="Span_G_B_31"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_32"/><span class="switch-label" data-on="32" data-off="32" id="Span_G_B_32"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_33"/><span class="switch-label" data-on="33" data-off="33" id="Span_G_B_33"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox"  id="G_B_34"/><span class="switch-label" data-on="34" data-off="34" id="Span_G_B_34"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>		
                    <td></td>
                    <td></td>
                    <td></td>

                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_C_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_C_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_C_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_C_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_C_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_C_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_C_7"></span><span class="switch-handle"></span></label></td>
                    <td>C</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_C_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_C_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_C_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_C_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_C_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_C_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_C_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_C_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_C_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_C_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_C_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_C_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_C_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_C_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_G_C_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_23"/><span class="switch-label" data-on="23" data-off="23" id="Span_G_C_23"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_24"/><span class="switch-label" data-on="24" data-off="24" id="Span_G_C_24"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_25"/><span class="switch-label" data-on="25" data-off="25" id="Span_G_C_25"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_26"/><span class="switch-label" data-on="26" data-off="26" id="Span_G_C_26"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_27"/><span class="switch-label" data-on="27" data-off="27" id="Span_G_C_27"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_28"/><span class="switch-label" data-on="28" data-off="28" id="Span_G_C_28"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_29"/><span class="switch-label" data-on="29" data-off="29" id="Span_G_C_29"></span><span class="switch-handle"></span></label></td>
                    <td>C</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_30"/><span class="switch-label" data-on="30" data-off="30" id="Span_G_C_30"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_31"/><span class="switch-label" data-on="31" data-off="31" id="Span_G_C_31"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_32"/><span class="switch-label" data-on="32" data-off="32" id="Span_G_C_32"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_33"/><span class="switch-label" data-on="33" data-off="33" id="Span_G_C_33"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_34"/><span class="switch-label" data-on="34" data-off="34" id="Span_G_C_34"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_35"/><span class="switch-label" data-on="35" data-off="35" id="Span_G_C_35"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_36"/><span class="switch-label" data-on="36" data-off="36" id="Span_G_C_36"></span><span class="switch-handle"></span></label></td>	
                    <td></td>		
                    <td></td>
                    <td></td>
                    <td></td>

                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_D_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_D_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_D_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_D_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_D_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_D_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_D_7"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_D_8"></span><span class="switch-handle"></span></label></td>
                    <td>D</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_D_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_D_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_D_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_D_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_D_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_D_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_D_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_D_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_D_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_D_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_D_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_D_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_D_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_G_D_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_23"/><span class="switch-label" data-on="23" data-off="23" id="Span_G_D_23"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_24"/><span class="switch-label" data-on="24" data-off="24" id="Span_G_D_24"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_25"/><span class="switch-label" data-on="25" data-off="25" id="Span_G_D_25"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_26"/><span class="switch-label" data-on="26" data-off="26" id="Span_G_D_26"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_27"/><span class="switch-label" data-on="27" data-off="27" id="Span_G_D_27"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_28"/><span class="switch-label" data-on="28" data-off="28" id="Span_G_D_28"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_29"/><span class="switch-label" data-on="29" data-off="29" id="Span_G_D_29"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_30"/><span class="switch-label" data-on="30" data-off="30" id="Span_G_D_30"></span><span class="switch-handle"></span></label></td>
                    <td>D</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_31"/><span class="switch-label" data-on="31" data-off="31" id="Span_G_D_31"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_32"/><span class="switch-label" data-on="32" data-off="32" id="Span_G_D_32"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_33"/><span class="switch-label" data-on="33" data-off="33" id="Span_G_D_33"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_34"/><span class="switch-label" data-on="34" data-off="34" id="Span_G_D_34"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_35"/><span class="switch-label" data-on="35" data-off="35" id="Span_G_D_35"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_36"/><span class="switch-label" data-on="36" data-off="36" id="Span_G_D_36"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_37"/><span class="switch-label" data-on="37" data-off="37" id="Span_G_D_37"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_38"/><span class="switch-label" data-on="38" data-off="38" id="Span_G_D_38"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>

                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_E_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_E_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_E_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_E_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_E_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_E_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_E_7"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_E_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_E_9"></span><span class="switch-handle"></span></label></td>
                    <td>E</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_E_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_E_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_E_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_E_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_E_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_E_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_E_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_E_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_E_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_E_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_E_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_E_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_G_E_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_23"/><span class="switch-label" data-on="23" data-off="23" id="Span_G_E_23"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_24"/><span class="switch-label" data-on="24" data-off="24" id="Span_G_E_24"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_25"/><span class="switch-label" data-on="25" data-off="25" id="Span_G_E_25"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_26"/><span class="switch-label" data-on="26" data-off="26" id="Span_G_E_26"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_27"/><span class="switch-label" data-on="27" data-off="27" id="Span_G_E_27"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_28"/><span class="switch-label" data-on="28" data-off="28" id="Span_G_E_28"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_29"/><span class="switch-label" data-on="29" data-off="29" id="Span_G_E_29"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_30"/><span class="switch-label" data-on="30" data-off="30" id="Span_G_E_30"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_31"/><span class="switch-label" data-on="31" data-off="31" id="Span_G_E_31"></span><span class="switch-handle"></span></label></td>
                    <td>E</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_32"/><span class="switch-label" data-on="32" data-off="32" id="Span_G_E_32"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_33"/><span class="switch-label" data-on="33" data-off="33" id="Span_G_E_33"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_34"/><span class="switch-label" data-on="34" data-off="34" id="Span_G_E_34"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_35"/><span class="switch-label" data-on="35" data-off="35" id="Span_G_E_35"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_36"/><span class="switch-label" data-on="36" data-off="36" id="Span_G_E_36"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_37"/><span class="switch-label" data-on="37" data-off="37" id="Span_G_E_37"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_38"/><span class="switch-label" data-on="38" data-off="38" id="Span_G_E_38"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_39"/><span class="switch-label" data-on="39" data-off="39" id="Span_G_E_39"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_40"/><span class="switch-label" data-on="40" data-off="40" id="Span_G_E_40"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>

                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_F_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_F_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_F_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_F_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_F_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_F_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_F_7"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_F_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_F_9"></span><span class="switch-handle"></span></label></td>
                    <td>F</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_F_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_F_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_F_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_F_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_F_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_F_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_F_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_F_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_F_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_F_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_F_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_F_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_G_F_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_23"/><span class="switch-label" data-on="23" data-off="23" id="Span_G_F_23"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_24"/><span class="switch-label" data-on="24" data-off="24" id="Span_G_F_24"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_25"/><span class="switch-label" data-on="25" data-off="25" id="Span_G_F_25"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_26"/><span class="switch-label" data-on="26" data-off="26" id="Span_G_F_26"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_27"/><span class="switch-label" data-on="27" data-off="27" id="Span_G_F_27"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_28"/><span class="switch-label" data-on="28" data-off="28" id="Span_G_F_28"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_29"/><span class="switch-label" data-on="29" data-off="29" id="Span_G_F_29"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_30"/><span class="switch-label" data-on="30" data-off="30" id="Span_G_F_30"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_31"/><span class="switch-label" data-on="31" data-off="31" id="Span_G_F_31"></span><span class="switch-handle"></span></label></td>
                    <td>F</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_32"/><span class="switch-label" data-on="32" data-off="32" id="Span_G_F_32"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_33"/><span class="switch-label" data-on="33" data-off="33" id="Span_G_F_33"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_34"/><span class="switch-label" data-on="34" data-off="34" id="Span_G_F_34"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_35"/><span class="switch-label" data-on="35" data-off="35" id="Span_G_F_35"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_36"/><span class="switch-label" data-on="36" data-off="36" id="Span_G_F_36"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_37"/><span class="switch-label" data-on="37" data-off="37" id="Span_G_F_37"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_38"/><span class="switch-label" data-on="38" data-off="38" id="Span_G_F_38"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_39"/><span class="switch-label" data-on="39" data-off="39" id="Span_G_F_39"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_40"/><span class="switch-label" data-on="40" data-off="40" id="Span_G_F_40"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>

                </tr>
                <tr>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_G_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_G_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_G_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_G_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_G_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_G_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_G_7"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_G_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_G_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_G_10"></span><span class="switch-handle"></span></label></td>
                    <td>G</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_G_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_G_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_G_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_G_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_G_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_G_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_G_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_G_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_G_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_G_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_G_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_G_G_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_23"/><span class="switch-label" data-on="23" data-off="23" id="Span_G_G_23"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_24"/><span class="switch-label" data-on="24" data-off="24" id="Span_G_G_24"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_25"/><span class="switch-label" data-on="25" data-off="25" id="Span_G_G_25"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_26"/><span class="switch-label" data-on="26" data-off="26" id="Span_G_G_26"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_27"/><span class="switch-label" data-on="27" data-off="27" id="Span_G_G_27"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_28"/><span class="switch-label" data-on="28" data-off="28" id="Span_G_G_28"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_29"/><span class="switch-label" data-on="29" data-off="29" id="Span_G_G_29"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_30"/><span class="switch-label" data-on="30" data-off="30" id="Span_G_G_30"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_31"/><span class="switch-label" data-on="31" data-off="31" id="Span_G_G_31"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_32"/><span class="switch-label" data-on="32" data-off="32" id="Span_G_G_32"></span><span class="switch-handle"></span></label></td>
                    <td>G</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_33"/><span class="switch-label" data-on="33" data-off="33" id="Span_G_G_33"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_34"/><span class="switch-label" data-on="34" data-off="34" id="Span_G_G_34"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_35"/><span class="switch-label" data-on="35" data-off="35" id="Span_G_G_35"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_36"/><span class="switch-label" data-on="36" data-off="36" id="Span_G_G_36"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_37"/><span class="switch-label" data-on="37" data-off="37" id="Span_G_G_37"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_38"/><span class="switch-label" data-on="38" data-off="38" id="Span_G_G_38"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_39"/><span class="switch-label" data-on="39" data-off="39" id="Span_G_G_39"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_40"/><span class="switch-label" data-on="40" data-off="40" id="Span_G_G_40"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_41"/><span class="switch-label" data-on="41" data-off="41" id="Span_G_G_41"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_42"/><span class="switch-label" data-on="42" data-off="42" id="Span_G_G_42"></span><span class="switch-handle"></span></label></td>
                    <td></td>

                </tr>
                <tr>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_H_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_H_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_H_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_H_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_H_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_H_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_H_7"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_H_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_H_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_H_10"></span><span class="switch-handle"></span></label></td>
                    <td>H</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_H_11"></span><span class="switch-handle"></span></label></td>		
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_H_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_H_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_H_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_H_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_H_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_H_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_H_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_H_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_H_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_H_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_G_H_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_23"/><span class="switch-label" data-on="23" data-off="23" id="Span_G_H_23"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_24"/><span class="switch-label" data-on="24" data-off="24" id="Span_G_H_24"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_25"/><span class="switch-label" data-on="25" data-off="25" id="Span_G_H_25"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_26"/><span class="switch-label" data-on="26" data-off="26" id="Span_G_H_26"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_27"/><span class="switch-label" data-on="27" data-off="27" id="Span_G_H_27"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_28"/><span class="switch-label" data-on="28" data-off="28" id="Span_G_H_28"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_29"/><span class="switch-label" data-on="29" data-off="29" id="Span_G_H_29"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_30"/><span class="switch-label" data-on="30" data-off="30" id="Span_G_H_30"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_31"/><span class="switch-label" data-on="31" data-off="31" id="Span_G_H_31"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_32"/><span class="switch-label" data-on="32" data-off="32" id="Span_G_H_32"></span><span class="switch-handle"></span></label></td>
                    <td>H</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_33"/><span class="switch-label" data-on="33" data-off="33" id="Span_G_H_33"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_34"/><span class="switch-label" data-on="34" data-off="34" id="Span_G_H_34"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_35"/><span class="switch-label" data-on="35" data-off="35" id="Span_G_H_35"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_36"/><span class="switch-label" data-on="36" data-off="36" id="Span_G_H_36"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_37"/><span class="switch-label" data-on="37" data-off="37" id="Span_G_H_37"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_38"/><span class="switch-label" data-on="38" data-off="38" id="Span_G_H_38"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_39"/><span class="switch-label" data-on="39" data-off="39" id="Span_G_H_39"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_40"/><span class="switch-label" data-on="40" data-off="40" id="Span_G_H_40"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_41"/><span class="switch-label" data-on="41" data-off="41" id="Span_G_H_41"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_42"/><span class="switch-label" data-on="42" data-off="42" id="Span_G_H_42"></span><span class="switch-handle"></span></label></td>
                    <td></td>

                </tr>
                <tr>
                    <td colspan="46">&nbsp;</td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_I_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_I_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_I_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_I_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_I_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_I_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_I_7"></span><span class="switch-handle"></span></label></td>
                    <td>I</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_I_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_I_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_I_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_I_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_I_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_I_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_I_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_I_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_I_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_I_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_I_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_I_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_I_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_I_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_G_I_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_23"/><span class="switch-label" data-on="23" data-off="23" id="Span_G_I_23"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_24"/><span class="switch-label" data-on="24" data-off="24" id="Span_G_I_24"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_25"/><span class="switch-label" data-on="25" data-off="25" id="Span_G_I_25"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_26"/><span class="switch-label" data-on="26" data-off="26" id="Span_G_I_26"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_27"/><span class="switch-label" data-on="27" data-off="27" id="Span_G_I_27"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_28"/><span class="switch-label" data-on="28" data-off="28" id="Span_G_I_28"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_29"/><span class="switch-label" data-on="29" data-off="29" id="Span_G_I_29"></span><span class="switch-handle"></span></label></td>
                    <td>I</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_30"/><span class="switch-label" data-on="30" data-off="30" id="Span_G_I_30"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_31"/><span class="switch-label" data-on="31" data-off="31" id="Span_G_I_31"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_32"/><span class="switch-label" data-on="32" data-off="32" id="Span_G_I_32"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_33"/><span class="switch-label" data-on="33" data-off="33" id="Span_G_I_33"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_34"/><span class="switch-label" data-on="34" data-off="34" id="Span_G_I_34"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_35"/><span class="switch-label" data-on="35" data-off="35" id="Span_G_I_35"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_36"/><span class="switch-label" data-on="36" data-off="36" id="Span_G_I_36"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>

                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_J_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_J_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_J_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_J_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_J_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_J_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_J_7"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_J_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_J_9"></span><span class="switch-handle"></span></label></td>
                    <td>J</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_J_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_J_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_J_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_J_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_J_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_J_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_J_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_J_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_J_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_J_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_J_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_J_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_G_J_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_23"/><span class="switch-label" data-on="23" data-off="23" id="Span_G_J_23"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_24"/><span class="switch-label" data-on="24" data-off="24" id="Span_G_J_24"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_25"/><span class="switch-label" data-on="25" data-off="25" id="Span_G_J_25"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_26"/><span class="switch-label" data-on="26" data-off="26" id="Span_G_J_26"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_27"/><span class="switch-label" data-on="27" data-off="27" id="Span_G_J_27"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_28"/><span class="switch-label" data-on="28" data-off="28" id="Span_G_J_28"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_29"/><span class="switch-label" data-on="29" data-off="29" id="Span_G_J_29"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_30"/><span class="switch-label" data-on="30" data-off="30" id="Span_G_J_30"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_31"/><span class="switch-label" data-on="31" data-off="31" id="Span_G_J_31"></span><span class="switch-handle"></span></label></td>
                    <td>J</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_32"/><span class="switch-label" data-on="32" data-off="32" id="Span_G_J_32"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_33"/><span class="switch-label" data-on="33" data-off="33" id="Span_G_J_33"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_34"/><span class="switch-label" data-on="34" data-off="34" id="Span_G_J_34"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_35"/><span class="switch-label" data-on="35" data-off="35" id="Span_G_J_35"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_36"/><span class="switch-label" data-on="36" data-off="36" id="Span_G_J_36"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_37"/><span class="switch-label" data-on="37" data-off="37" id="Span_G_J_37"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_38"/><span class="switch-label" data-on="38" data-off="38" id="Span_G_J_38"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_39"/><span class="switch-label" data-on="39" data-off="39" id="Span_G_J_39"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_40"/><span class="switch-label" data-on="40" data-off="40" id="Span_G_J_40"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>

                </tr>
                <tr>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_K_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_K_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_K_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_K_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_K_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_K_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_K_7"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_K_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_K_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_K_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_K_11"></span><span class="switch-handle"></span></label></td>
                    <td>K</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_K_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_K_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_K_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_K_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_K_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_K_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_K_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_K_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_K_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_K_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_G_K_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_23"/><span class="switch-label" data-on="23" data-off="23" id="Span_G_K_23"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_24"/><span class="switch-label" data-on="24" data-off="24" id="Span_G_K_24"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_25"/><span class="switch-label" data-on="25" data-off="25" id="Span_G_K_25"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_26"/><span class="switch-label" data-on="26" data-off="26" id="Span_G_K_26"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_27"/><span class="switch-label" data-on="27" data-off="27" id="Span_G_K_27"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_28"/><span class="switch-label" data-on="28" data-off="28" id="Span_G_K_28"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_29"/><span class="switch-label" data-on="29" data-off="29" id="Span_G_K_29"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_30"/><span class="switch-label" data-on="30" data-off="30" id="Span_G_K_30"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_31"/><span class="switch-label" data-on="31" data-off="31" id="Span_G_K_31"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_32"/><span class="switch-label" data-on="32" data-off="32" id="Span_G_K_32"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_33"/><span class="switch-label" data-on="33" data-off="33" id="Span_G_K_33"></span><span class="switch-handle"></span></label></td>
                    <td>K</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_34"/><span class="switch-label" data-on="34" data-off="34" id="Span_G_K_34"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_35"/><span class="switch-label" data-on="35" data-off="35" id="Span_G_K_35"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_36"/><span class="switch-label" data-on="36" data-off="36" id="Span_G_K_36"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_37"/><span class="switch-label" data-on="37" data-off="37" id="Span_G_K_37"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_38"/><span class="switch-label" data-on="38" data-off="38" id="Span_G_K_38"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_39"/><span class="switch-label" data-on="39" data-off="39" id="Span_G_K_39"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_40"/><span class="switch-label" data-on="40" data-off="40" id="Span_G_K_40"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_41"/><span class="switch-label" data-on="41" data-off="41" id="Span_G_K_41"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_42"/><span class="switch-label" data-on="42" data-off="42" id="Span_G_K_42"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_43"/><span class="switch-label" data-on="43" data-off="43" id="Span_G_K_43"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_44"/><span class="switch-label" data-on="44" data-off="44" id="Span_G_K_44"></span><span class="switch-handle"></span></label></td>

                </tr>
                <tr>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_L_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_L_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_L_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_L_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_L_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_L_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_L_7"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_L_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_L_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_L_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_L_11"></span><span class="switch-handle"></span></label></td>
                    <td>L</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_L_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_L_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_L_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_L_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_L_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_L_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_L_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_L_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_L_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_L_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_G_L_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_23"/><span class="switch-label" data-on="23" data-off="23" id="Span_G_L_23"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_24"/><span class="switch-label" data-on="24" data-off="24" id="Span_G_L_24"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_25"/><span class="switch-label" data-on="25" data-off="25" id="Span_G_L_25"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_26"/><span class="switch-label" data-on="26" data-off="26" id="Span_G_L_26"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_27"/><span class="switch-label" data-on="27" data-off="27" id="Span_G_L_27"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_28"/><span class="switch-label" data-on="28" data-off="28" id="Span_G_L_28"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_29"/><span class="switch-label" data-on="29" data-off="29" id="Span_G_L_29"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_30"/><span class="switch-label" data-on="30" data-off="30" id="Span_G_L_30"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_31"/><span class="switch-label" data-on="31" data-off="31" id="Span_G_L_31"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_32"/><span class="switch-label" data-on="32" data-off="32" id="Span_G_L_32"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_33"/><span class="switch-label" data-on="33" data-off="33" id="Span_G_L_33"></span><span class="switch-handle"></span></label></td>
                    <td>L</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_34"/><span class="switch-label" data-on="34" data-off="34" id="Span_G_L_34"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_35"/><span class="switch-label" data-on="35" data-off="35" id="Span_G_L_35"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_36"/><span class="switch-label" data-on="36" data-off="36" id="Span_G_L_36"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_37"/><span class="switch-label" data-on="37" data-off="37" id="Span_G_L_37"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_38"/><span class="switch-label" data-on="38" data-off="38" id="Span_G_L_38"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_39"/><span class="switch-label" data-on="39" data-off="39" id="Span_G_L_39"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_40"/><span class="switch-label" data-on="40" data-off="40" id="Span_G_L_40"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_41"/><span class="switch-label" data-on="41" data-off="41" id="Span_G_L_41"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_42"/><span class="switch-label" data-on="42" data-off="42" id="Span_G_L_42"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_43"/><span class="switch-label" data-on="43" data-off="43" id="Span_G_L_43"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_44"/><span class="switch-label" data-on="44" data-off="44" id="Span_G_L_44"></span><span class="switch-handle"></span></label></td>

                </tr>
                <tr>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_M_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_M_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_M_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_M_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_M_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_M_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_M_7"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_M_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_M_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_M_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_M_11"></span><span class="switch-handle"></span></label></td>
                    <td>M</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_M_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_M_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_M_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_M_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_M_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_M_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_M_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_M_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_M_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_M_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_G_M_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_23"/><span class="switch-label" data-on="23" data-off="23" id="Span_G_M_23"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_24"/><span class="switch-label" data-on="24" data-off="24" id="Span_G_M_24"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_25"/><span class="switch-label" data-on="25" data-off="25" id="Span_G_M_25"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_26"/><span class="switch-label" data-on="26" data-off="26" id="Span_G_M_26"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_27"/><span class="switch-label" data-on="27" data-off="27" id="Span_G_M_27"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_28"/><span class="switch-label" data-on="28" data-off="28" id="Span_G_M_28"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_29"/><span class="switch-label" data-on="29" data-off="29" id="Span_G_M_29"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_30"/><span class="switch-label" data-on="30" data-off="30" id="Span_G_M_30"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_31"/><span class="switch-label" data-on="31" data-off="31" id="Span_G_M_31"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_32"/><span class="switch-label" data-on="32" data-off="32" id="Span_G_M_32"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_33"/><span class="switch-label" data-on="33" data-off="33" id="Span_G_M_33"></span><span class="switch-handle"></span></label></td>
                    <td>M</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_34"/><span class="switch-label" data-on="34" data-off="34" id="Span_G_M_34"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_35"/><span class="switch-label" data-on="35" data-off="35" id="Span_G_M_35"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_36"/><span class="switch-label" data-on="36" data-off="36" id="Span_G_M_36"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_37"/><span class="switch-label" data-on="37" data-off="37" id="Span_G_M_37"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_38"/><span class="switch-label" data-on="38" data-off="38" id="Span_G_M_38"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_39"/><span class="switch-label" data-on="39" data-off="39" id="Span_G_M_39"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_40"/><span class="switch-label" data-on="40" data-off="40" id="Span_G_M_40"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_41"/><span class="switch-label" data-on="41" data-off="41" id="Span_G_M_41"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_42"/><span class="switch-label" data-on="42" data-off="42" id="Span_G_M_42"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_43"/><span class="switch-label" data-on="43" data-off="43" id="Span_G_M_43"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_44"/><span class="switch-label" data-on="44" data-off="44" id="Span_G_M_44"></span><span class="switch-handle"></span></label></td>

                </tr>
                <tr>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_N_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_N_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_N_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_N_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_N_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_N_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_N_7"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_N_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_N_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_N_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_N_11"></span><span class="switch-handle"></span></label></td>
                    <td>N</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_N_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_N_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_N_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_N_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_N_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_N_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_N_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_N_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_N_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_N_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_G_N_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_23"/><span class="switch-label" data-on="23" data-off="23" id="Span_G_N_23"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_24"/><span class="switch-label" data-on="24" data-off="24" id="Span_G_N_24"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_25"/><span class="switch-label" data-on="25" data-off="25" id="Span_G_N_25"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_26"/><span class="switch-label" data-on="26" data-off="26" id="Span_G_N_26"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_27"/><span class="switch-label" data-on="27" data-off="27" id="Span_G_N_27"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_28"/><span class="switch-label" data-on="28" data-off="28" id="Span_G_N_28"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_29"/><span class="switch-label" data-on="29" data-off="29" id="Span_G_N_29"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_30"/><span class="switch-label" data-on="30" data-off="30" id="Span_G_N_30"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_31"/><span class="switch-label" data-on="31" data-off="31" id="Span_G_N_31"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_32"/><span class="switch-label" data-on="32" data-off="32" id="Span_G_N_32"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_33"/><span class="switch-label" data-on="33" data-off="33" id="Span_G_N_33"></span><span class="switch-handle"></span></label></td>
                    <td>N</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_34"/><span class="switch-label" data-on="34" data-off="34" id="Span_G_N_34"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_35"/><span class="switch-label" data-on="35" data-off="35" id="Span_G_N_35"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_36"/><span class="switch-label" data-on="36" data-off="36" id="Span_G_N_36"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_37"/><span class="switch-label" data-on="37" data-off="37" id="Span_G_N_37"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_38"/><span class="switch-label" data-on="38" data-off="38" id="Span_G_N_38"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_39"/><span class="switch-label" data-on="39" data-off="39" id="Span_G_N_39"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_40"/><span class="switch-label" data-on="40" data-off="40" id="Span_G_N_40"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_41"/><span class="switch-label" data-on="41" data-off="41" id="Span_G_N_41"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_42"/><span class="switch-label" data-on="42" data-off="42" id="Span_G_N_42"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_43"/><span class="switch-label" data-on="43" data-off="43" id="Span_G_N_43"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_44"/><span class="switch-label" data-on="44" data-off="44" id="Span_G_N_44"></span><span class="switch-handle"></span></label></td>

                </tr>
                <tr>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_O_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_O_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_O_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_O_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_O_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_O_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_O_7"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_O_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_O_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_O_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_O_11"></span><span class="switch-handle"></span></label></td>
                    <td>O</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_O_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_O_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_O_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_O_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_O_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_O_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_O_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_O_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_O_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_O_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_G_O_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_23"/><span class="switch-label" data-on="23" data-off="23" id="Span_G_O_23"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_24"/><span class="switch-label" data-on="24" data-off="24" id="Span_G_O_24"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_25"/><span class="switch-label" data-on="25" data-off="25" id="Span_G_O_25"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_26"/><span class="switch-label" data-on="26" data-off="26" id="Span_G_O_26"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_27"/><span class="switch-label" data-on="27" data-off="27" id="Span_G_O_27"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_28"/><span class="switch-label" data-on="28" data-off="28" id="Span_G_O_28"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_29"/><span class="switch-label" data-on="29" data-off="29" id="Span_G_O_29"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_30"/><span class="switch-label" data-on="30" data-off="30" id="Span_G_O_30"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_31"/><span class="switch-label" data-on="31" data-off="31" id="Span_G_O_31"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_32"/><span class="switch-label" data-on="32" data-off="32" id="Span_G_O_32"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_33"/><span class="switch-label" data-on="33" data-off="33" id="Span_G_O_33"></span><span class="switch-handle"></span></label></td>
                    <td>O</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_34"/><span class="switch-label" data-on="34" data-off="34" id="Span_G_O_34"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_35"/><span class="switch-label" data-on="35" data-off="35" id="Span_G_O_35"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_36"/><span class="switch-label" data-on="36" data-off="36" id="Span_G_O_36"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_37"/><span class="switch-label" data-on="37" data-off="37" id="Span_G_O_37"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_38"/><span class="switch-label" data-on="38" data-off="38" id="Span_G_O_38"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_39"/><span class="switch-label" data-on="39" data-off="39" id="Span_G_O_39"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_40"/><span class="switch-label" data-on="40" data-off="40" id="Span_G_O_40"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_41"/><span class="switch-label" data-on="41" data-off="41" id="Span_G_O_41"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_42"/><span class="switch-label" data-on="42" data-off="42" id="Span_G_O_42"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_43"/><span class="switch-label" data-on="43" data-off="43" id="Span_G_O_43"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_44"/><span class="switch-label" data-on="44" data-off="44" id="Span_G_O_44"></span><span class="switch-handle"></span></label></td>

                </tr>
                <tr>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_P_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_P_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_P_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_P_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_P_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_P_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_P_7"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_P_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_P_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_P_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_P_11"></span><span class="switch-handle"></span></label></td>
                    <td>P</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_P_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_P_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_P_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_P_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_P_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_P_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_P_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_P_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_P_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_P_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_G_P_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_23"/><span class="switch-label" data-on="23" data-off="23" id="Span_G_P_23"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_24"/><span class="switch-label" data-on="24" data-off="24" id="Span_G_P_24"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_25"/><span class="switch-label" data-on="25" data-off="25" id="Span_G_P_25"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_26"/><span class="switch-label" data-on="26" data-off="26" id="Span_G_P_26"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_27"/><span class="switch-label" data-on="27" data-off="27" id="Span_G_P_27"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_28"/><span class="switch-label" data-on="28" data-off="28" id="Span_G_P_28"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_29"/><span class="switch-label" data-on="29" data-off="29" id="Span_G_P_29"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_30"/><span class="switch-label" data-on="30" data-off="30" id="Span_G_P_30"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_31"/><span class="switch-label" data-on="31" data-off="31" id="Span_G_P_31"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_32"/><span class="switch-label" data-on="32" data-off="32" id="Span_G_P_32"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_33"/><span class="switch-label" data-on="33" data-off="33" id="Span_G_P_33"></span><span class="switch-handle"></span></label></td>
                    <td>P</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_34"/><span class="switch-label" data-on="34" data-off="34" id="Span_G_P_34"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_35"/><span class="switch-label" data-on="35" data-off="35" id="Span_G_P_35"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_36"/><span class="switch-label" data-on="36" data-off="36" id="Span_G_P_36"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_37"/><span class="switch-label" data-on="37" data-off="37" id="Span_G_P_37"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_38"/><span class="switch-label" data-on="38" data-off="38" id="Span_G_P_38"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_39"/><span class="switch-label" data-on="39" data-off="39" id="Span_G_P_39"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_40"/><span class="switch-label" data-on="40" data-off="40" id="Span_G_P_40"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_41"/><span class="switch-label" data-on="41" data-off="41" id="Span_G_P_41"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_42"/><span class="switch-label" data-on="42" data-off="42" id="Span_G_P_42"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_43"/><span class="switch-label" data-on="43" data-off="43" id="Span_G_P_43"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_44"/><span class="switch-label" data-on="44" data-off="44" id="Span_G_P_44"></span><span class="switch-handle"></span></label></td>

                </tr>
                <tr>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_Q_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_Q_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_Q_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_Q_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_Q_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_Q_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_Q_7"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_Q_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_Q_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_Q_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_Q_11"></span><span class="switch-handle"></span></label></td>
                    <td>Q</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_Q_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_Q_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_Q_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_Q_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_Q_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_Q_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_Q_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_Q_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_Q_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_Q_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_G_Q_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_23"/><span class="switch-label" data-on="23" data-off="23" id="Span_G_Q_23"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_24"/><span class="switch-label" data-on="24" data-off="24" id="Span_G_Q_24"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_25"/><span class="switch-label" data-on="25" data-off="25" id="Span_G_Q_25"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_26"/><span class="switch-label" data-on="26" data-off="26" id="Span_G_Q_26"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_27"/><span class="switch-label" data-on="27" data-off="27" id="Span_G_Q_27"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_28"/><span class="switch-label" data-on="28" data-off="28" id="Span_G_Q_28"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_29"/><span class="switch-label" data-on="29" data-off="29" id="Span_G_Q_29"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_30"/><span class="switch-label" data-on="30" data-off="30" id="Span_G_Q_30"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_31"/><span class="switch-label" data-on="31" data-off="31" id="Span_G_Q_31"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_32"/><span class="switch-label" data-on="32" data-off="32" id="Span_G_Q_32"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_33"/><span class="switch-label" data-on="33" data-off="33" id="Span_G_Q_33"></span><span class="switch-handle"></span></label></td>
                    <td>Q</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_34"/><span class="switch-label" data-on="34" data-off="34" id="Span_G_Q_34"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_35"/><span class="switch-label" data-on="35" data-off="35" id="Span_G_Q_35"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_36"/><span class="switch-label" data-on="36" data-off="36" id="Span_G_Q_36"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_37"/><span class="switch-label" data-on="37" data-off="37" id="Span_G_Q_37"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_38"/><span class="switch-label" data-on="38" data-off="38" id="Span_G_Q_38"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_39"/><span class="switch-label" data-on="39" data-off="39" id="Span_G_Q_39"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_40"/><span class="switch-label" data-on="40" data-off="40" id="Span_G_Q_40"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_41"/><span class="switch-label" data-on="41" data-off="41" id="Span_G_Q_41"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_42"/><span class="switch-label" data-on="42" data-off="42" id="Span_G_Q_42"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_43"/><span class="switch-label" data-on="43" data-off="43" id="Span_G_Q_43"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_44"/><span class="switch-label" data-on="44" data-off="44" id="Span_G_Q_44"></span><span class="switch-handle"></span></label></td>

                </tr>
                <tr>		
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_R_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_R_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_R_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_R_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_R_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_R_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_R_7"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_R_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_R_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_R_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_R_11"></span><span class="switch-handle"></span></label></td>
                    <td>R</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_R_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_R_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_R_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_R_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_R_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_R_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_R_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_R_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_R_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_R_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_G_R_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_23"/><span class="switch-label" data-on="23" data-off="23" id="Span_G_R_23"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_24"/><span class="switch-label" data-on="24" data-off="24" id="Span_G_R_24"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_25"/><span class="switch-label" data-on="25" data-off="25" id="Span_G_R_25"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_26"/><span class="switch-label" data-on="26" data-off="26" id="Span_G_R_26"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_27"/><span class="switch-label" data-on="27" data-off="27" id="Span_G_R_27"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_28"/><span class="switch-label" data-on="28" data-off="28" id="Span_G_R_28"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_29"/><span class="switch-label" data-on="29" data-off="29" id="Span_G_R_29"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_30"/><span class="switch-label" data-on="30" data-off="30" id="Span_G_R_30"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_31"/><span class="switch-label" data-on="31" data-off="31" id="Span_G_R_31"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_32"/><span class="switch-label" data-on="32" data-off="32" id="Span_G_R_32"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_33"/><span class="switch-label" data-on="33" data-off="33" id="Span_G_R_33"></span><span class="switch-handle"></span></label></td>
                    <td>R</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_34"/><span class="switch-label" data-on="34" data-off="34" id="Span_G_R_34"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_35"/><span class="switch-label" data-on="35" data-off="35" id="Span_G_R_35"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_36"/><span class="switch-label" data-on="36" data-off="36" id="Span_G_R_36"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_37"/><span class="switch-label" data-on="37" data-off="37" id="Span_G_R_37"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_38"/><span class="switch-label" data-on="38" data-off="38" id="Span_G_R_38"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_39"/><span class="switch-label" data-on="39" data-off="39" id="Span_G_R_39"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_40"/><span class="switch-label" data-on="40" data-off="40" id="Span_G_R_40"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_41"/><span class="switch-label" data-on="41" data-off="41" id="Span_G_R_41"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_42"/><span class="switch-label" data-on="42" data-off="42" id="Span_G_R_42"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_43"/><span class="switch-label" data-on="43" data-off="43" id="Span_G_R_43"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_44"/><span class="switch-label" data-on="44" data-off="44" id="Span_G_R_44"></span><span class="switch-handle"></span></label></td>

                </tr>
                <tr>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_S_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_S_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_S_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_S_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_S_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_S_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_S_7"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_S_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_S_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_S_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_S_11"></span><span class="switch-handle"></span></label></td>
                    <td>S</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_S_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_S_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_S_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_S_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_S_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_S_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_S_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_S_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_S_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_S_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_G_S_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_23"/><span class="switch-label" data-on="23" data-off="23" id="Span_G_S_23"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_24"/><span class="switch-label" data-on="24" data-off="24" id="Span_G_S_24"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_25"/><span class="switch-label" data-on="25" data-off="25" id="Span_G_S_25"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_26"/><span class="switch-label" data-on="26" data-off="26" id="Span_G_S_26"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_27"/><span class="switch-label" data-on="27" data-off="27" id="Span_G_S_27"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_28"/><span class="switch-label" data-on="28" data-off="28" id="Span_G_S_28"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_29"/><span class="switch-label" data-on="29" data-off="29" id="Span_G_S_29"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_30"/><span class="switch-label" data-on="30" data-off="30" id="Span_G_S_30"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_31"/><span class="switch-label" data-on="31" data-off="31" id="Span_G_S_31"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_32"/><span class="switch-label" data-on="32" data-off="32" id="Span_G_S_32"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_33"/><span class="switch-label" data-on="33" data-off="33" id="Span_G_S_33"></span><span class="switch-handle"></span></label></td>
                    <td>S</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_34"/><span class="switch-label" data-on="34" data-off="34" id="Span_G_S_34"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_35"/><span class="switch-label" data-on="35" data-off="35" id="Span_G_S_35"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_36"/><span class="switch-label" data-on="36" data-off="36" id="Span_G_S_36"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_37"/><span class="switch-label" data-on="37" data-off="37" id="Span_G_S_37"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_38"/><span class="switch-label" data-on="38" data-off="38" id="Span_G_S_38"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_39"/><span class="switch-label" data-on="39" data-off="39" id="Span_G_S_39"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_40"/><span class="switch-label" data-on="40" data-off="40" id="Span_G_S_40"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_41"/><span class="switch-label" data-on="41" data-off="41" id="Span_G_S_41"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_42"/><span class="switch-label" data-on="42" data-off="42" id="Span_G_S_42"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_43"/><span class="switch-label" data-on="43" data-off="43" id="Span_G_S_43"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_S_44"/><span class="switch-label" data-on="44" data-off="44" id="Span_G_S_44"></span><span class="switch-handle"></span></label></td>

                </tr>
            </table>
        </div>
        <div style="overflow:auto; display:none" align="center" id="balcony1">
            <table class="floorPlan" style="color:white">
                <tr>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_11_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B1_A_11_1"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td>11</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>10</td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_10_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B1_A_10_3"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>

                </tr>
                <tr>        
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_11_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B1_B_11_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_11_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B1_A_11_2"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_10_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B1_A_10_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_10_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B1_B_10_3"></span><span class="switch-handle"></span></label></td>
                    <td></td>

                </tr>

                <tr>        
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_11_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B1_B_11_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_11_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B1_A_11_3"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_10_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B1_A_10_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_10_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B1_B_10_2"></span><span class="switch-handle"></span></label></td>
                    <td></td>

                </tr>

                <tr>        
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_11_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B1_B_11_3"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_10_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B1_B_10_1"></span><span class="switch-handle"></span></label></td>
                    <td></td>

                </tr>


                <tr>        
                    <td colspan="45">&nbsp;</td>

                </tr>

                <tr>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_9_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B1_A_9_1"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td>9</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>8</td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_8_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B1_A_8_5"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>

                </tr>
                <tr>        
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_9_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B1_B_9_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_9_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B1_A_9_2"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_8_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B1_A_8_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_8_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B1_B_8_5"></span><span class="switch-handle"></span></label></td>
                    <td></td>

                </tr>
                <tr>        
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_9_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B1_B_9_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_9_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B1_A_9_3"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_8_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B1_A_8_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_8_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B1_B_8_4"></span><span class="switch-handle"></span></label></td>
                    <td></td>

                </tr>
                <tr>        
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_9_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B1_B_9_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_9_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B1_A_9_4"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_8_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B1_A_8_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_8_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B1_B_8_3"></span><span class="switch-handle"></span></label></td>
                    <td></td>

                </tr>
                <tr>        
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_9_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B1_B_9_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_9_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B1_A_9_5"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_8_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B1_A_8_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_8_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B1_B_8_2"></span><span class="switch-handle"></span></label></td>
                    <td></td>

                </tr>
                <tr>        
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_9_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B1_B_9_5"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_8_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B1_B_8_1"></span><span class="switch-handle"></span></label></td>
                    <td></td>

                </tr>

                <tr>        
                    <td colspan="45">&nbsp;</td>

                </tr>

                <tr>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_7_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B1_A_7_1"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td>7</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>6</td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_6_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B1_A_6_5"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>

                </tr>

                <tr>        
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_7_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B1_B_7_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_7_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B1_A_7_2"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_6_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B1_A_6_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_6_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B1_B_6_5"></span><span class="switch-handle"></span></label></td>
                    <td></td>

                </tr>
                <tr>   
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_7_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B1_C_7_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_7_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B1_B_7_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_7_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B1_A_7_3"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_6_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B1_A_6_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_6_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B1_B_6_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_6_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B1_C_6_5"></span><span class="switch-handle"></span></label></td>

                </tr>
                <tr>   
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_7_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B1_C_7_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_7_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B1_B_7_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_7_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B1_A_7_4"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_6_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B1_A_6_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_6_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B1_B_6_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_6_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B1_C_6_4"></span><span class="switch-handle"></span></label></td>

                </tr><tr>   
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_7_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B1_C_7_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_7_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B1_B_7_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_7_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B1_A_7_5"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_6_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B1_A_6_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_6_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B1_B_6_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_6_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B1_C_6_3"></span><span class="switch-handle"></span></label></td>

                </tr>
                <tr>                
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_7_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B1_C_7_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_7_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B1_B_7_5"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>5</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>3</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>4</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_6_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B1_B_6_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_6_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B1_C_6_2"></span><span class="switch-handle"></span></label></td>

                </tr>
                <tr>                
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_7_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B1_C_7_5"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td>A</td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_5_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B1_A_5_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_5_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B1_A_5_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_5_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B1_A_5_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_5_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B1_A_5_4"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_3_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B1_A_3_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_3_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B1_A_3_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_3_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B1_A_3_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_3_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B1_A_3_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_3_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B1_A_3_5"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_2_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B1_A_2_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_2_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B1_A_2_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_2_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B1_A_2_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_2_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B1_A_2_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_2_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B1_A_2_5"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_4_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B1_A_4_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_4_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B1_A_4_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_4_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B1_A_4_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_A_4_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B1_A_4_4"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td>A</td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_6_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B1_C_6_1"></span><span class="switch-handle"></span></label></td>

                </tr>

                <tr>                
                    <td></td>
                    <td>B</td>
                    <td></td>    
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_5_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B1_B_5_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_5_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B1_B_5_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_5_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B1_B_5_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_5_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B1_B_5_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_5_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B1_B_5_5"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>		
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_3_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B1_B_3_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_3_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B1_B_3_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_3_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B1_B_3_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_3_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B1_B_3_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_3_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B1_B_3_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_3_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_B1_B_3_6"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>&reg;</td>
                    <td>&reg;</td>
                    <td>&reg;</td>
                    <td>&reg;</td>
                    <td>&reg;</td>
                    <td>&reg;</td>
                    <td></td>
                    <td></td> 
                    <td></td> 
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_2_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B1_B_2_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_2_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B1_B_2_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_2_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B1_B_2_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_2_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B1_B_2_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_2_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B1_B_2_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_2_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_B1_B_2_6"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_4_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B1_B_4_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_4_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B1_B_4_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_4_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B1_B_4_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_4_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B1_B_4_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_B_4_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B1_B_4_5"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td>B</td>
                    <td></td>     

                </tr>

                <tr>                
                    <td>C</td>		   
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_5_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B1_C_5_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_5_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B1_C_5_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_5_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B1_C_5_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_5_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B1_C_5_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_5_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B1_C_5_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_5_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_B1_C_5_6"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_3_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B1_C_3_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_3_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B1_C_3_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_3_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B1_C_3_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_3_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B1_C_3_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_3_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B1_C_3_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_3_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_B1_C_3_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_3_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_B1_C_3_7"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>&reg;</td>
                    <td>&reg;</td>
                    <td>&reg;</td>
                    <td>&reg;</td>
                    <td>&reg;</td>
                    <td>&reg;</td>
                    <td>&reg;</td>
                    <td>&reg;</td>
                    <td></td>
                    <td></td> 
                    <td></td> 
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_2_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B1_C_2_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_2_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B1_C_2_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_2_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B1_C_2_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_2_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B1_C_2_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_2_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B1_C_2_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_2_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_B1_C_2_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_2_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_B1_C_2_7"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_4_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B1_C_4_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_4_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B1_C_4_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_4_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B1_C_4_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_4_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B1_C_4_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_4_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B1_C_4_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B1_C_4_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_B1_C_4_6"></span><span class="switch-handle"></span></label></td>
                    <td>C</td>     

                </tr>
            </table>
        </div>
        <div style="overflow:auto; display:none" align="center" id="balcony2">

            <table class="floorPlan" style="color:white">
                <tr>                
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_7_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B2_C_7_1"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_6_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B2_C_6_4"></span><span class="switch-handle"></span></label></td>        
                    <td></td>
                </tr>

                <tr>                
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_7_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B2_D_7_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_7_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B2_C_7_2"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_6_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B2_C_6_3"></span><span class="switch-handle"></span></label></td>        
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_6_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B2_D_6_4"></span><span class="switch-handle"></span></label></td>        
                </tr>

                <tr>                
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_7_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B2_D_7_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_7_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B2_C_7_3"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_6_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B2_C_6_2"></span><span class="switch-handle"></span></label></td>        
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_6_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B2_D_6_3"></span><span class="switch-handle"></span></label></td>        
                </tr>

                <tr>                
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_7_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B2_D_7_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_7_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B2_C_7_4"></span><span class="switch-handle"></span></label></td>
                    <td>7</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>6</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_6_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B2_C_6_1"></span><span class="switch-handle"></span></label></td>        
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_6_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B2_D_6_2"></span><span class="switch-handle"></span></label></td>        
                </tr>

                <tr>                
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_7_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B2_D_7_4"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>        
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_6_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B2_D_6_1"></span><span class="switch-handle"></span></label></td>        
                </tr>

                <tr>                
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_5_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B2_B_5_1"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_4_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B2_B_4_5"></span><span class="switch-handle"></span></label></td>
                    <td></td>        
                    <td></td>        
                </tr>

                <tr>                
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_5_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B2_C_5_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_5_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B2_B_5_2"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_4_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B2_B_4_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_4_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B2_C_4_5"></span><span class="switch-handle"></span></label></td>        
                    <td></td>        
                </tr>

                <tr>                
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_5_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B2_C_5_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_5_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B2_B_5_3"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_4_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B2_B_4_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_4_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B2_C_4_4"></span><span class="switch-handle"></span></label></td>        
                    <td></td>        
                </tr>

                <tr>                
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_5_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B2_C_5_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_5_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B2_B_5_4"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_4_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B2_B_4_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_4_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B2_C_4_3"></span><span class="switch-handle"></span></label></td>        
                    <td></td>        
                </tr>

                <tr>                
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_5_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B2_C_5_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_5_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B2_B_5_5"></span><span class="switch-handle"></span></label></td>
                    <td>5</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>4</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_4_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B2_B_4_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_4_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B2_C_4_2"></span><span class="switch-handle"></span></label></td>        
                    <td></td>        
                </tr>

                <tr>                
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_5_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B2_C_5_5"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_4_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B2_C_4_1"></span><span class="switch-handle"></span></label></td>        
                    <td></td>        
                </tr>

                <tr>                
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_3_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B2_A_3_1"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_2_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B2_A_2_5"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>        
                    <td></td>        
                </tr>

                <tr>                
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_3_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B2_B_3_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_3_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B2_A_3_2"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_2_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B2_A_2_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_2_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B2_B_2_5"></span><span class="switch-handle"></span></label></td>
                    <td></td>        
                    <td></td>        
                </tr>

                <tr>                
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_3_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B2_B_3_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_3_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B2_A_3_3"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_2_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B2_A_2_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_2_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B2_B_2_4"></span><span class="switch-handle"></span></label></td>
                    <td></td>        
                    <td></td>        
                </tr>

                <tr>                
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_3_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B2_B_3_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_3_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B2_A_3_4"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td>3</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>2</td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_2_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B2_A_2_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_2_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B2_B_2_3"></span><span class="switch-handle"></span></label></td>
                    <td></td>        
                    <td></td>        
                </tr>

                <tr>                
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_3_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B2_B_3_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_3_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B2_A_3_5"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_2_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B2_A_2_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_2_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B2_B_2_2"></span><span class="switch-handle"></span></label></td>
                    <td></td>        
                    <td></td>        
                </tr>

                <tr>                
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_3_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B2_B_3_5"></span><span class="switch-handle"></span></label></td>
                    <td>A</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B2_A_1_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B2_A_1_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B2_A_1_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B2_A_1_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B2_A_1_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_B2_A_1_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_B2_A_1_7"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td>A</td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_B2_A_1_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_B2_A_1_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_B2_A_1_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_B2_A_1_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_B2_A_1_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_B2_A_1_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_B2_A_1_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_B2_A_1_15"></span><span class="switch-handle"></span></label></td>
                    <td>&nbsp;</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_B2_A_1_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_B2_A_1_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_B2_A_1_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_B2_A_1_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_B2_A_1_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_B2_A_1_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_B2_A_1_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_23"/><span class="switch-label" data-on="23" data-off="23" id="Span_B2_A_1_23"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td>A</td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_24"/><span class="switch-label" data-on="24" data-off="24" id="Span_B2_A_1_24"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_25"/><span class="switch-label" data-on="25" data-off="25" id="Span_B2_A_1_25"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_26"/><span class="switch-label" data-on="26" data-off="26" id="Span_B2_A_1_26"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_27"/><span class="switch-label" data-on="27" data-off="27" id="Span_B2_A_1_27"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_28"/><span class="switch-label" data-on="28" data-off="28" id="Span_B2_A_1_28"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_29"/><span class="switch-label" data-on="29" data-off="29" id="Span_B2_A_1_29"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_A_1_30"/><span class="switch-label" data-on="30" data-off="30" id="Span_B2_A_1_30"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>A</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_2_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B2_B_2_1"></span><span class="switch-handle"></span></label></td>
                    <td></td>        
                    <td></td>        
                </tr>

                <tr>                
                    <td></td>
                    <td></td>
                    <td>B</td>
                    <td></td>
                    <td></td>        
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B2_B_1_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B2_B_1_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B2_B_1_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B2_B_1_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B2_B_1_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_B2_B_1_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_B2_B_1_7"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_B2_B_1_8"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td>B</td>
                    <td></td>		
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_B2_B_1_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_B2_B_1_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_B2_B_1_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_B2_B_1_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_B2_B_1_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_B2_B_1_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_B2_B_1_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_B2_B_1_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_B2_B_1_17"></span><span class="switch-handle"></span></label></td>
                    <td>&nbsp;</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_B2_B_1_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_B2_B_1_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_B2_B_1_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_B2_B_1_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_B2_B_1_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_23"/><span class="switch-label" data-on="23" data-off="23" id="Span_B2_B_1_23"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_24"/><span class="switch-label" data-on="24" data-off="24" id="Span_B2_B_1_24"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_25"/><span class="switch-label" data-on="25" data-off="25" id="Span_B2_B_1_25"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_26"/><span class="switch-label" data-on="26" data-off="26" id="Span_B2_B_1_26"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td>B</td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_27"/><span class="switch-label" data-on="27" data-off="27" id="Span_B2_B_1_27"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_28"/><span class="switch-label" data-on="28" data-off="28" id="Span_B2_B_1_28"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_29"/><span class="switch-label" data-on="29" data-off="29" id="Span_B2_B_1_29"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_30"/><span class="switch-label" data-on="30" data-off="30" id="Span_B2_B_1_30"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_31"/><span class="switch-label" data-on="31" data-off="31" id="Span_B2_B_1_31"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_32"/><span class="switch-label" data-on="32" data-off="32" id="Span_B2_B_1_32"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_33"/><span class="switch-label" data-on="33" data-off="33" id="Span_B2_B_1_33"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_B_1_34"/><span class="switch-label" data-on="34" data-off="34" id="Span_B2_B_1_34"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td>B</td>
                    <td></td>
                    <td></td>             
                </tr>

                <tr>                
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>               
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B2_C_1_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B2_C_1_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B2_C_1_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B2_C_1_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B2_C_1_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_B2_C_1_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_B2_C_1_7"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_B2_C_1_8"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td>C</td>
                    <td></td> 
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_B2_C_1_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_B2_C_1_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_B2_C_1_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_B2_C_1_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_B2_C_1_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_B2_C_1_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_B2_C_1_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_B2_C_1_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_B2_C_1_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_B2_C_1_18"></span><span class="switch-handle"></span></label></td>
                    <td>&nbsp;</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_B2_C_1_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_B2_C_1_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_B2_C_1_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_B2_C_1_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_23"/><span class="switch-label" data-on="23" data-off="23" id="Span_B2_C_1_23"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_24"/><span class="switch-label" data-on="24" data-off="24" id="Span_B2_C_1_24"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_25"/><span class="switch-label" data-on="25" data-off="25" id="Span_B2_C_1_25"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_26"/><span class="switch-label" data-on="26" data-off="26" id="Span_B2_C_1_26"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_27"/><span class="switch-label" data-on="27" data-off="27" id="Span_B2_C_1_27"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_28"/><span class="switch-label" data-on="28" data-off="28" id="Span_B2_C_1_28"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td>C</td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_29"/><span class="switch-label" data-on="29" data-off="29" id="Span_B2_C_1_29"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_30"/><span class="switch-label" data-on="30" data-off="30" id="Span_B2_C_1_30"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_31"/><span class="switch-label" data-on="31" data-off="31" id="Span_B2_C_1_31"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_32"/><span class="switch-label" data-on="32" data-off="32" id="Span_B2_C_1_32"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_33"/><span class="switch-label" data-on="33" data-off="33" id="Span_B2_C_1_33"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_34"/><span class="switch-label" data-on="34" data-off="34" id="Span_B2_C_1_34"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_35"/><span class="switch-label" data-on="35" data-off="35" id="Span_B2_C_1_35"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_C_1_36"/><span class="switch-label" data-on="36" data-off="36" id="Span_B2_C_1_36"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>             
                    <td></td>
                </tr>

                <tr>                
                    <td></td>
                    <td></td>
                    <td></td>           
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B2_D_1_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B2_D_1_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B2_D_1_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B2_D_1_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B2_D_1_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_B2_D_1_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_B2_D_1_7"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_B2_D_1_8"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td>D</td>
                    <td></td> 
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_B2_D_1_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_B2_D_1_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_B2_D_1_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_B2_D_1_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_B2_D_1_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_B2_D_1_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_B2_D_1_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_B2_D_1_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_B2_D_1_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_B2_D_1_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_B2_D_1_19"></span><span class="switch-handle"></span></label></td>
                    <td>&nbsp;</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_B2_D_1_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_B2_D_1_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_B2_D_1_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_23"/><span class="switch-label" data-on="23" data-off="23" id="Span_B2_D_1_23"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_24"/><span class="switch-label" data-on="24" data-off="24" id="Span_B2_D_1_24"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_25"/><span class="switch-label" data-on="25" data-off="25" id="Span_B2_D_1_25"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_26"/><span class="switch-label" data-on="26" data-off="26" id="Span_B2_D_1_26"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_27"/><span class="switch-label" data-on="27" data-off="27" id="Span_B2_D_1_27"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_28"/><span class="switch-label" data-on="28" data-off="28" id="Span_B2_D_1_28"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_29"/><span class="switch-label" data-on="29" data-off="29" id="Span_B2_D_1_29"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_30"/><span class="switch-label" data-on="30" data-off="30" id="Span_B2_D_1_30"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td>D</td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_31"/><span class="switch-label" data-on="31" data-off="31" id="Span_B2_D_1_31"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_32"/><span class="switch-label" data-on="32" data-off="32" id="Span_B2_D_1_32"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_33"/><span class="switch-label" data-on="33" data-off="33" id="Span_B2_D_1_33"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_34"/><span class="switch-label" data-on="34" data-off="34" id="Span_B2_D_1_34"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_35"/><span class="switch-label" data-on="35" data-off="35" id="Span_B2_D_1_35"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_36"/><span class="switch-label" data-on="36" data-off="36" id="Span_B2_D_1_36"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_37"/><span class="switch-label" data-on="37" data-off="37" id="Span_B2_D_1_37"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_D_1_38"/><span class="switch-label" data-on="38" data-off="38" id="Span_B2_D_1_38"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>             
                </tr>

                <tr>                
                    <td></td>           
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B2_E_1_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B2_E_1_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B2_E_1_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B2_E_1_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B2_E_1_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_B2_E_1_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_B2_E_1_7"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_B2_E_1_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_B2_E_1_9"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td>E</td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_B2_E_1_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_B2_E_1_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_B2_E_1_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_B2_E_1_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_B2_E_1_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_B2_E_1_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_B2_E_1_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_B2_E_1_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_B2_E_1_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_B2_E_1_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_B2_E_1_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_B2_E_1_21"></span><span class="switch-handle"></span></label></td>
                    <td>&nbsp;</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_B2_E_1_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_23"/><span class="switch-label" data-on="23" data-off="23" id="Span_B2_E_1_23"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_24"/><span class="switch-label" data-on="24" data-off="24" id="Span_B2_E_1_24"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_25"/><span class="switch-label" data-on="25" data-off="25" id="Span_B2_E_1_25"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_26"/><span class="switch-label" data-on="26" data-off="26" id="Span_B2_E_1_26"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_27"/><span class="switch-label" data-on="27" data-off="27" id="Span_B2_E_1_27"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_28"/><span class="switch-label" data-on="28" data-off="28" id="Span_B2_E_1_28"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_29"/><span class="switch-label" data-on="29" data-off="29" id="Span_B2_E_1_29"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_30"/><span class="switch-label" data-on="30" data-off="30" id="Span_B2_E_1_30"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_31"/><span class="switch-label" data-on="31" data-off="31" id="Span_B2_E_1_31"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_32"/><span class="switch-label" data-on="32" data-off="32" id="Span_B2_E_1_32"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td>E</td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_33"/><span class="switch-label" data-on="33" data-off="33" id="Span_B2_E_1_33"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_34"/><span class="switch-label" data-on="34" data-off="34" id="Span_B2_E_1_34"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_35"/><span class="switch-label" data-on="35" data-off="35" id="Span_B2_E_1_35"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_36"/><span class="switch-label" data-on="36" data-off="36" id="Span_B2_E_1_36"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_37"/><span class="switch-label" data-on="37" data-off="37" id="Span_B2_E_1_37"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_38"/><span class="switch-label" data-on="38" data-off="38" id="Span_B2_E_1_38"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_39"/><span class="switch-label" data-on="39" data-off="39" id="Span_B2_E_1_39"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_40"/><span class="switch-label" data-on="40" data-off="40" id="Span_B2_E_1_40"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_E_1_41"/><span class="switch-label" data-on="41" data-off="41" id="Span_B2_E_1_41"></span><span class="switch-handle"></span></label></td>
                    <td></td>             
                </tr>

                <tr>                
                    <td></td>    
                    <td></td> 
                    <td></td> 		
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B2_F_1_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B2_F_1_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B2_F_1_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B2_F_1_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B2_F_1_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_B2_F_1_6"></span><span class="switch-handle"></span></label></td>		
                    <td></td>
                    <td>F</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_B2_F_1_7"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_B2_F_1_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_B2_F_1_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_B2_F_1_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_B2_F_1_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_B2_F_1_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_B2_F_1_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_B2_F_1_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_B2_F_1_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_B2_F_1_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_B2_F_1_17"></span><span class="switch-handle"></span></label></td>
                    <td>&nbsp;</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_B2_F_1_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_B2_F_1_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_B2_F_1_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_B2_F_1_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_B2_F_1_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_23"/><span class="switch-label" data-on="23" data-off="23" id="Span_B2_F_1_23"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_24"/><span class="switch-label" data-on="24" data-off="24" id="Span_B2_F_1_24"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_25"/><span class="switch-label" data-on="25" data-off="25" id="Span_B2_F_1_25"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_26"/><span class="switch-label" data-on="26" data-off="26" id="Span_B2_F_1_26"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_27"/><span class="switch-label" data-on="27" data-off="27" id="Span_B2_F_1_27"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>F</td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_28"/><span class="switch-label" data-on="28" data-off="28" id="Span_B2_F_1_28"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_29"/><span class="switch-label" data-on="29" data-off="29" id="Span_B2_F_1_29"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_30"/><span class="switch-label" data-on="30" data-off="30" id="Span_B2_F_1_30"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_31"/><span class="switch-label" data-on="31" data-off="31" id="Span_B2_F_1_31"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_32"/><span class="switch-label" data-on="32" data-off="32" id="Span_B2_F_1_32"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_F_1_33"/><span class="switch-label" data-on="33" data-off="33" id="Span_B2_F_1_33"></span><span class="switch-handle"></span></label></td>		
                    <td></td>        
                    <td></td> 
                    <td></td> 		
                </tr>

                <tr>                
                    <td>1</td>    
                    <td></td> 
                    <td></td> 	
                    <td></td> 		
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B2_G_1_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B2_G_1_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B2_G_1_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B2_G_1_4"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td>G</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B2_G_1_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_B2_G_1_6"></span><span class="switch-handle"></span></label></td>		
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_B2_G_1_7"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_B2_G_1_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_B2_G_1_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_B2_G_1_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_B2_G_1_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_B2_G_1_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_B2_G_1_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_B2_G_1_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_B2_G_1_15"></span><span class="switch-handle"></span></label></td>		
                    <td>&nbsp;</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_B2_G_1_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_B2_G_1_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_B2_G_1_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_B2_G_1_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_B2_G_1_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_B2_G_1_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_B2_G_1_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_23"/><span class="switch-label" data-on="23" data-off="23" id="Span_B2_G_1_23"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_24"/><span class="switch-label" data-on="24" data-off="24" id="Span_B2_G_1_24"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_25"/><span class="switch-label" data-on="25" data-off="25" id="Span_B2_G_1_25"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_26"/><span class="switch-label" data-on="26" data-off="26" id="Span_B2_G_1_26"></span><span class="switch-handle"></span></label></td>		
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>G</td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_27"/><span class="switch-label" data-on="27" data-off="27" id="Span_B2_G_1_27"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_28"/><span class="switch-label" data-on="28" data-off="28" id="Span_B2_G_1_28"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_29"/><span class="switch-label" data-on="29" data-off="29" id="Span_B2_G_1_29"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_G_1_30"/><span class="switch-label" data-on="30" data-off="30" id="Span_B2_G_1_30"></span><span class="switch-handle"></span></label></td>
                    <td></td>        
                    <td></td> 
                    <td></td> 		
                    <td>1</td> 
                </tr>

                <tr>                
                    <td></td>    
                    <td></td> 
                    <td></td> 	
                    <td></td> 	
                    <td></td>    
                    <td></td> 
                    <td></td> 	
                    <td></td> 	
                    <td></td> 
                    <td></td> 	
                    <td></td>
                    <td>H</td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_H_1_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B2_H_1_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_H_1_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B2_H_1_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_H_1_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B2_H_1_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_H_1_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B2_H_1_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_H_1_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B2_H_1_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_H_1_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_B2_H_1_6"></span><span class="switch-handle"></span></label></td>		
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_H_1_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_B2_H_1_7"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_H_1_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_B2_H_1_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_H_1_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_B2_H_1_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_H_1_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_B2_H_1_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_H_1_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_B2_H_1_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_H_1_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_B2_H_1_12"></span><span class="switch-handle"></span></label></td>
                    <td>&nbsp;</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_H_1_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_B2_H_1_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_H_1_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_B2_H_1_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_H_1_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_B2_H_1_15"></span><span class="switch-handle"></span></label></td>		
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_H_1_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_B2_H_1_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_H_1_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_B2_H_1_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_H_1_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_B2_H_1_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_H_1_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_B2_H_1_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_H_1_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_B2_H_1_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_H_1_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_B2_H_1_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_H_1_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_B2_H_1_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_H_1_23"/><span class="switch-label" data-on="23" data-off="23" id="Span_B2_H_1_23"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td>H</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>		
                </tr>

                <tr>                
                    <td></td>    
                    <td></td> 
                    <td></td> 	
                    <td></td> 	
                    <td></td>    
                    <td></td> 
                    <td></td> 	
                    <td></td> 	
                    <td></td> 
                    <td></td> 	
                    <td></td>
                    <td>I</td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_I_1_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B2_I_1_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_I_1_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B2_I_1_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_I_1_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B2_I_1_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_I_1_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B2_I_1_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_I_1_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B2_I_1_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_I_1_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_B2_I_1_6"></span><span class="switch-handle"></span></label></td>		
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_I_1_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_B2_I_1_7"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_I_1_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_B2_I_1_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_I_1_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_B2_I_1_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_I_1_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_B2_I_1_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_I_1_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_B2_I_1_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_I_1_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_B2_I_1_12"></span><span class="switch-handle"></span></label></td>
                    <td>&nbsp;</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_I_1_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_B2_I_1_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_I_1_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_B2_I_1_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_I_1_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_B2_I_1_15"></span><span class="switch-handle"></span></label></td>		
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_I_1_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_B2_I_1_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_I_1_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_B2_I_1_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_I_1_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_B2_I_1_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_I_1_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_B2_I_1_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_I_1_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_B2_I_1_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_I_1_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_B2_I_1_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_I_1_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_B2_I_1_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_I_1_23"/><span class="switch-label" data-on="23" data-off="23" id="Span_B2_I_1_23"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_I_1_24"/><span class="switch-label" data-on="24" data-off="24" id="Span_B2_I_1_24"></span><span class="switch-handle"></span></label></td>
                    <td>I</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>		
                </tr>

                <tr>                
                    <td></td>    
                    <td></td> 
                    <td></td> 	
                    <td></td> 	
                    <td></td>    
                    <td></td> 
                    <td></td> 	
                    <td></td> 	
                    <td></td> 
                    <td></td> 	
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>J</td>
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_J_1_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_B2_J_1_1"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_J_1_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_B2_J_1_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_J_1_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_B2_J_1_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_J_1_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_B2_J_1_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_J_1_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_B2_J_1_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_J_1_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_B2_J_1_6"></span><span class="switch-handle"></span></label></td>		
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_J_1_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_B2_J_1_7"></span><span class="switch-handle"></span></label></td>
                    <td>&nbsp;</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_J_1_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_B2_J_1_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_J_1_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_B2_J_1_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_J_1_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_B2_J_1_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_J_1_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_B2_J_1_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_J_1_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_B2_J_1_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_J_1_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_B2_J_1_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="B2_J_1_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_B2_J_1_14"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    <td>J</td>
                    <td></td> 
                    <td></td> 	
                    <td></td> 	
                    <td></td>    
                    <td></td> 
                    <td></td> 	
                    <td></td> 	
                    <td></td> 
                    <td></td> 	
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
            </table>

        </div>

        <br/>
        <div class="container" style="display: none" id="formDetails">
            <div class="row">                      
                <div class="col-sm-3">
                    <label style="color: white">Name *</label><input type="text" name="res_name" id="res_name"  class="form-control"/>
                </div>
                <div class="col-sm-3">
                    <label style="color: white"> Contact No *</label><input type="text" name="res_contact" id="res_contact"  class="form-control"  maxlength="10"/>
                </div>
                <div class="col-sm-3">
                    <label style="color: white">Email *</label><input type="text" name="res_email" id="res_email"  class="form-control"/>
                </div>
                <div class="col-sm-3">
                    <label style="color: white">Total Price</label>
                    <input type="text" value="0" disabled id="totValueShow" class="form-control"/>
                </div>

            </div>
            <br/>
            <div class="row">  
                <div class="col-sm-12">
                    <label style="color: white">Selected Seats</label>
                    <input type="text" id="reservedSeatsShow" disabled value=""/>
                </div>
            </div>
            <br/>

            <div class="row">
                <div class="col-sm-3">
                    <label style="color: white">EPF No*</label><input type="text" name="res_nic" id="res_nic"  class="form-control" maxlength="5"/>
                </div>
                <div class="col-sm-3">
                    <label style="color: white">Staff Account No *</label><input type="password" name="res_card" id="res_card"  class="form-control" maxlength="12"/>
                </div>

                <div class="col-sm-3" style="text-align: center">
                    <br/>
                    <input type="button" class="btn btn-primary" id="reserveSeats" value="Reserve"/>
                </div>
            </div>


            <input type="hidden" id="reservedSeats" value="0" disabled/><br/>
            <input type="hidden" id="totValue" value="0" disabled />
        </div>


        <!-- Footer -->
        <footer id="footer">
            <div class="container body-text1">
                <div class="row">
                    <section class="4u 6u(medium) 12u$(small)">
                        <h3>Terms & Conditions</h3>
                        <p><ul>

                            <li><p>Tickets will be initially released to staff members for a limited period prior to releasing tickets to general public.</p></li>
                            <li><p>A Staff member can purchase any number of tickets.</P></LI>
                            <li><p>Only 20 tickets are permitted per purchase. (Any number of purchases are allowed).</P></LI>
                            <li><p>All bookings will be treated as final and payments will not be refunded under any circumstances.</P></LI>
                            <li><p>Payments for tickets to be made as follows:</br>
                                    -	Total amount of tickets purchased by a staff member within the limited period will be deducted from the the staff account in two installments (July/August salary).
                                    </br>-	 Total amount of tickets purchased after the limited period will be deducted from the NDB Credit Card or cash should be deposited to a designated account.



                                </p></li>

                        </ul>

                        </p>


                    </section>
                    <section class="4u 6u$(medium) 12u$(small)">
                        <h3>Tickets</h3>

                        <ul class="alt">

                            <table style="width:100%" class="table">
                                <tr>
                                    <th>Price</th>
                                    <th>No Seats</th> 
                                    <th>Availability</th>
                                </tr>                                
                                <tr>
                                    <td>5,000/-</td>
                                    <td style="text-indent: 5%"><span id="seat5000"></span></td> 
                                    <td><span id="seat5000Availability"></span></td>
                                </tr>
                                <tr>
                                    <td>3,000/-</td>
                                    <td style="text-indent: 5%"><span id="seat3000"></span></td> 
                                    <td><span id="seat3000Availability"></span></td>
                                </tr>
                                <tr>
                                    <td>2,000/-</td>
                                    <td style="text-indent: 5%"><span id="seat2000"></span></td> 
                                    <td><span id="seat2000Availability"></span></td>
                                </tr>
                                <tr>
                                    <td>1,500/-</td>
                                    <td style="text-indent: 5%"><span id="seat1500"></span></td> 
                                    <td><span id="seat1500Availability"></span></td>
                                </tr>
                                <tr>
                                    <td>1,000/-</td>
                                    <td style="text-indent: 5%"><span id="seat1000"></span></td> 
                                    <td><span id="seat1000Availability"></td>
                                </tr>

                            </table>
                        </ul>
                    </section>
                    <section class="4u$ 12u$(medium) 12u$(small)">
                        <h3>Details</h3>

                        <ul class="tabular">
                            <li><h3>Date</h3>
                                Saturday 13th July 2019  
                            </li>
                            <li><h3>Time</h3>
                                6.30 pm onwards  
                            </li>
                            <li>
                                <h3>Venue</h3>
                                Nelum Pokuna Mahinda Rajapaksha Theatre<br>
                                Colombo 07
                                <a href="https://goo.gl/maps/1vGJd8ffd432" class="image fit" target="_blank"><img src="img/pic23.jpg" alt=""/></a>

                            </li>

                            <li>
                                <h3>Inquiries</h3>
                                0772009317-Kalinga Senanayake <br/>0773612432-Amitha Koralage<br/>0716663929-Amila Bandara
                            </li>

                        </ul>
                    </section>
                </div>
                <ul class="copyright">
                    <li>&copy; NDBSRC. All rights reserved.</li>
                    <li>Powered by NDB IT</li>

                </ul>
            </div>
        </footer>

    </body>
</html>
