<?php

	include 'Connection.php';
	
	
	$searchBy=$_POST['searchBy'];
	$seatID = "";	
	$epf = "";	
	$sql0="";
	if(strcmp($searchBy,"seat")==0){		
		$seatID = $_POST['seatID'];
		$sql0 = "SELECT * FROM seat where seatNo='$seatID'";
	}
	else if(strcmp($searchBy,"epf")==0){		
		$epf = $_POST['epf'];
		$sql0 = "SELECT * FROM seat where epfNo like '%$epf%'";
	}	
	
	
		$result = mysqli_query($conn, $sql0);
		$resultsArr=array();
		while($row = mysqli_fetch_assoc($result)) {
			$resultsArr[]=$row;		
		}
		print json_encode($resultsArr);
			
	
	mysqli_close($conn);
?>