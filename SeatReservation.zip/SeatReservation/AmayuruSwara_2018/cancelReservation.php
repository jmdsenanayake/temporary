<?php

	include 'Connection.php';
	
	$user = $_POST['user'];
    $pwd = $_POST['pwd'];
	$seatID = $_POST['seatID'];	
	
	if(strcmp($user,"AmilaB")==0 && strcmp($pwd,"AS2018#NDB_SRC")==0){		
	
		$sql0 = "SELECT price FROM seat where status='Reserved' and seatNo='$seatID'";
		$result = mysqli_query($conn, $sql0);
			if($row = mysqli_fetch_assoc($result)) {
				$price= $row["price"];
				$sql1="update seat set status='Available', purchasedPrice=null,epfNo=null,resName=null,resEmail=null,resContact=null,accNo=null, reservedDateTime=null where seatNo='$seatID' and status='reserved'";
				mysqli_query($conn, $sql1);
				$sql2="update seatsummary set reservedSeats=reservedSeats-1 where seatPrice=$price";
				mysqli_query($conn, $sql2);
				
				echo "You have successfully canceled the reservation of seatNo = $seatID \nfor the Amayuru Swara 2018.\n\nThank You.\nNDBSRC";
			}
			else{
				echo "Invalid Reserved SeatNo. Please Try Again.";
			}
	}
	else{		
		echo "Invalid User Credential. Please Try Again.";
	}
	mysqli_close($conn);
?>