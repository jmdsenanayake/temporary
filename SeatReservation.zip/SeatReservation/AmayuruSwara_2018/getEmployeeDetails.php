<?php
	include 'Connection.php';
	
	$epfNo=$_GET['epfNo'];
	
	$sql = "SELECT empName,emailAddress FROM employee where epfNo='$epfNo'";
	$result = mysqli_query($conn, $sql);
	$resultsArr=array();
    while($row = mysqli_fetch_assoc($result)) {
        $resultsArr[]=$row;
    }
	mysqli_close($conn);
	print json_encode($resultsArr);
	
?>