<?php

	include 'Connection.php';
	
	$epfNo = $_POST['epfNo'];
	$empName = $_POST['empName'];
	$empEmail = $_POST['empEmail'];
    $staffAcc = $_POST['staffAcc'];
    $contactNo = $_POST['contactNo'];
	$reservedSeats = $_POST['reservedSeats'];
	$totalPrice = $_POST['totalPrice'];
	
	$SeatArr=split("\,",$reservedSeats);
	$SeatArrReserved=array();
	$totalPurchasedPrice=0;
	$seatsBooked=false;
	
	for ($i = 0; $i < sizeOf($SeatArr); $i++) {
		
		//check whether the seat is available		
		$sql1 = "SELECT price FROM seat where status='Available' and seatNo='$SeatArr[$i]' and price>0";
		$result = mysqli_query($conn, $sql1);
		if($row = mysqli_fetch_assoc($result)) {
			
		}
		else{
			$seatsBooked=true;
		}
		
		
	}
	
	if(!$seatsBooked){
		for ($i = 0; $i < sizeOf($SeatArr); $i++) {
		
		//check whether the seat is available		
		$sql1 = "SELECT price FROM seat where status='Available' and seatNo='$SeatArr[$i]' and price>0";
		$result = mysqli_query($conn, $sql1);
		if($row = mysqli_fetch_assoc($result)) {
			$price= $row["price"];
			$purchasedPrice=$price;
			$sql2 = "Update seat set epfNo='$epfNo',resName='$empName',resEmail='$empEmail',resContact='$contactNo',accNo='$staffAcc',reservedDateTime=now(),status='Reserved', purchasedPrice=$purchasedPrice where seatNo='$SeatArr[$i]' and status='Available'";
			mysqli_query($conn, $sql2);			
			array_push($SeatArrReserved,$SeatArr[$i]);
			$totalPurchasedPrice+=$purchasedPrice;

			$sql3 = "Update seatSummary set reservedSeats=reservedSeats+1 where seatPrice=$price";
			mysqli_query($conn, $sql3);			
			
		}
		
		
	}
	
		$seatNoforPrinting="";	
		
		
		for ($x = 0; $x <  sizeOf($SeatArrReserved); $x++) {
			$SeatNoDetails=split("_",$SeatArrReserved[$x]);		
			$floor="";
			if($SeatNoDetails[0]=="G"){
				$floor="Ground Floor";
			}
			else if($SeatNoDetails[0]=="B1"){
				$floor="1st Floor Balcony";
			}
			else if($SeatNoDetails[0]=="B2"){
				$floor="2nd Floor Balcony";
			}
			$seatNoforPrinting.="\n\t".($x+1).") ".$floor." - ".$SeatArrReserved[$x];
		} 
		if($totalPurchasedPrice>0){
			echo "Dear $empName ($epfNo),\n\n You have successfully reserved following seats for the Amayuru Swara 2018.".$seatNoforPrinting."\n\n Please deposit LKR ".number_format($totalPurchasedPrice)."/- the total amount applicable for your ticket\n purchases to AC No $staffAcc.\n Kindly note that your seating allocation/s will be confirmed only once you have\n deposited the specified amount. Your reservation will be cancelled if the\n amount required is not deposited within the EOD of the reservation, and you\n will be required to make a fresh reservation subject to availability of seats.\n\nThank You.\nNDBSRC";
		}
		else{
			echo "Booking Unsuccessfull. Please Try Again.";
		}
	}
	else{
		echo "Some of the seats that you have selected are already reserved. Those will be de-selected automatically. Please Try Again.";
	}
	
	
	
	mysqli_close($conn);
?>