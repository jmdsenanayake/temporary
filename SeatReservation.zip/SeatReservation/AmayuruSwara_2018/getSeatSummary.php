<?php
	include 'Connection.php';
	
	$sql = "SELECT * FROM seatSummary";
	$result = mysqli_query($conn, $sql);
	$resultsArr=array();
    while($row = mysqli_fetch_assoc($result)) {
        $resultsArr[]=$row;
    }
	mysqli_close($conn);
	print json_encode($resultsArr);
	
?>