<?php

	include 'Connection.php';	
	$sql0 = "SELECT * FROM seat";
	//$sql0 = "SELECT seat.seatNo,floor,status,price,purchasedPrice,seat.epfNo, CASE WHEN resName is null THEN employee.empName ELSE resName END as resName,CASE WHEN resEmail is null THEN employee.emailAddress ELSE resEmail END as resEmail,resContact,accNo,reservedDateTime FROM seat,employee";
	$result = mysqli_query($conn, $sql0);
	$resultsArr=array();
	while($row = mysqli_fetch_assoc($result)) {
		$resultsArr[]=$row;		
	}
	print json_encode($resultsArr);
	mysqli_close($conn);
?>