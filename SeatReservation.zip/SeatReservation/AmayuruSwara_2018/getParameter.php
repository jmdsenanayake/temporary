<?php
	include 'Connection.php';
	
	$parameter=$_GET['parameter'];
	
	$sql = "SELECT $parameter FROM parameters";
	$result = mysqli_query($conn, $sql);
	$resultsArr=array();
    while($row = mysqli_fetch_assoc($result)) {
        $resultsArr[]=$row;
    }

	print json_encode($resultsArr);
	
?>