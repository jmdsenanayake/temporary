<?php
	include 'Connection.php';
	
	$sql = "SELECT seatNo FROM seat where status='Reserved'";
	$result = mysqli_query($conn, $sql);
	$resultsArr=array();
    while($row = mysqli_fetch_assoc($result)) {
        $resultsArr[]=$row;
    }
	
	mysqli_close($conn);
	print json_encode($resultsArr);
?>