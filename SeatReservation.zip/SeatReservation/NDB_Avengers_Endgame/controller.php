<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$functionName = "";

if (isset($_POST["functionName"])) {
    $functionName = $_POST["functionName"];
    
    if (strcmp($functionName, "") != 0) {
        if (strcmp($functionName, "check_reservation") == 0) {
            include 'files/check_reservation.php';
        } else if (strcmp($functionName, "get_available_seats_price") == 0) {
            include 'files/get_available_seats_price.php';
        } else if (strcmp($functionName, "add_to_contact_list") == 0) {
            include 'files/add_to_contact_list.php';
        } else if (strcmp($functionName, "cancel_reservation") == 0) {
            include 'files/cancel_reservation.php';
        } else if (strcmp($functionName, "check_reserved_seats") == 0) {
            include 'files/check_reserved_seats.php';
        } else if (strcmp($functionName, "reserve_seats") == 0) {
            include 'files/reserve_seats.php';
        } else if (strcmp($functionName, "no_cc_data") == 0) {
            include 'files/no_cc_data.php';
        } else if (strcmp($functionName, "seat_data") == 0) {
            include 'files/seat_data.php';
        } else if (strcmp($functionName, "report") == 0) {
            include 'files/report.php';
        } else if (strcmp($functionName, "report_no_cc") == 0) {
            include 'files/report_no_cc.php';
        } else {
            echo 'Something went wrong';
        }
    }
} else {
    echo 'Something went wrong';
}
?>

