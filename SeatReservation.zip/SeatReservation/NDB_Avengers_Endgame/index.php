<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Avengers_Endgame - NDB Bank</title>
        <script src="js/jquery.min.js"></script>
        <script src="js/skel.min.js"></script>
        <script src="js/skel-layers.min.js"></script>
        <script src="js/init.js"></script>
        <noscript>
        <link rel="stylesheet" href="css/skel.css" />
        <link rel="stylesheet" href="css/style.css" />
        <link rel="stylesheet" href="css/style-xlarge.css" />
        </noscript>

        <!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->

        <link href="css/bootstrap-toggle.min.css" rel="stylesheet">
        <link href="css/toggle-button.css" rel="stylesheet">				
        <link href="css/bootstrap.css" rel="stylesheet" >
        <link href="css/bootstrap-select.css" rel="stylesheet" >

        <script src="js/jquery-3.3.1.min.js"></script>
        <script src="js/bootstrap-toggle.min.js"></script>
        <script src="js/bootstrap.js"></script>
        <script src="js/bootstrap-select.js"></script>		
        <script src="js/jspdf.min.js"></script>	
        <script src="js/sweetalert.min.js"></script>	
        <style>
            .floorPlan tr, .floorPlan td{
                border: 0px;
            }

            body {
                background-image: radial-gradient(circle, rgba(255, 255, 255,0), rgba(32, 0, 100,1));
            }

        </style>

        <script>
            var totalPrice = 0;
            var reserevedSeatsNo = [];

            //collorcodes
            var color300 = "#32CD32";          
            var colorReserved = "#FF0000";

            function docReady() {
                checkReservedSeats();
                $('#reservedSeatsShow').val('');
                $.ajax({
                    type: "POST",
                    url: "controller.php",
                    data: "&functionName=get_available_seats_price",
                    dataType: "json",
                    success: function (data) {

                        var seatsArr = data;
                        for (var i = 0; i < seatsArr.length; i++) {

                            var checkbox = $("#" + seatsArr[i].seatNo);
                            var price = seatsArr[i].price;
                            checkbox.val(price);
                            // checkbox.attr("disabled", true);
                            var spanOfChkBox = checkbox.parent().children()[1].id;
                            if (price === "300") {
                                $("#" + spanOfChkBox).css({"background": color300});
                                //ssssssssssssssssssssssssssssssssssss
                                $("#" + seatsArr[i].seatNo).css({"background": color300});
                            }

                           
                        }
                    }
                });

                totalPrice = 0;
                reserevedSeatsNo = [];
                $('#res_nic').val("");
                $('#res_name').val("");
                $('#res_contact').val("");
                $('#res_email').val("");
                $('#res_card').val("");
                $('#totValueShow').val("");
                $('#totValue').val("");

                $('.switch-input').each(function () {
                    this.checked = false;
                });

                $('.switch-yes-no').each(function () {
                    var seatPrice = $($(this).html()).val();
                    if (seatPrice === 'on') {
                        this.style = "background:" + colorReserved;

                    }
                });
            }

            $(document).ready(function () {

                initiateCreditCardPrompt();

                docReady();

                $("#res_card").mouseover(function () {
                    var x = document.getElementById("res_card");
                    x.type = "text";
                });

                $("#res_card").mouseout(function () {
                    var x = document.getElementById("res_card");
                    x.type = "password";
                });

                $("#res_contact").keyup(function () {
                    if (this.value.match(/[^0-9]/g)) {
                        this.value = this.value.replace(/[^0-9/.]/g, '');
                    }
                });

                $("#res_card").keyup(function () {
                    if (this.value.match(/[^0-9]/g)) {
                        this.value = this.value.replace(/[^0-9/.]/g, '');
                    }
                });

                $("#res_name").keyup(function () {
                    if (this.value.match(/[^a-zA-Z ]/g)) {
                        this.value = this.value.replace(/[^a-zA-Z /.]/g, '');
                    }
                });

                $("#res_nic").keyup(function () {
                    if (this.value.match(/[^0-9vV]/g)) {
                        this.value = this.value.replace(/[^0-9vV/.]/g, '');
                    }
                });

                $('.switch-input').change(function () {
                    if (!isNaN($(this).val())) {
                        var seatPrice = parseFloat($(this).val());
                        if (this.checked) {
                            if (reserevedSeatsNo.length === 4) {
                                swal({
                                    title: 'You can not reserve more than 4 seats!',
                                    icon: 'error',
                                });
                                this.checked = false;
                            } else {
                                totalPrice += seatPrice;
                                reserevedSeatsNo.push("" + this.id);
                            }


                        }
                        else {
                            totalPrice -= seatPrice;
                            var index = reserevedSeatsNo.indexOf("" + this.id);
                            if (index > -1) {
                                reserevedSeatsNo.splice(index, 1);
                            }
                        }

                        $("#reservedSeats").val(reserevedSeatsNo.toString());
                        $("#reservedSeatsShow").val(reserevedSeatsNo.toString());
                        $("#totValue").val(totalPrice);
                        $("#totValueShow").val(totalPrice);
                    }


                });

                $('.switch-yes-no').mouseover(function () {
                    var seatPrice = $($(this).html()).val();
                    if (seatPrice === 'on') {
                        this.title = "Reserved";

                    }
                    else {
                        this.title = "Special Price LKR " + seatPrice + "/-";
                    }


                });



                $('#reserveSeats').click(function () {
                    if ($('#res_name').val() !== "" && $('#res_contact').val() !== "" && $('#res_email').val() !== "" && $('#res_card').val()) {
                        if ($('#res_contact').val().length === 10) {
                            if (validateEmail($('#res_email').val())) {
                                if (reserevedSeatsNo.length > 0) {
                                    if (reserevedSeatsNo.length <= 5) {
                                        var cardNo = $('#res_card').val();
                                        if (cardNo.length === 16) {
                                            var BIN = cardNo.substr(0, 6);
                                            if (BIN === "416802" || BIN === "438535" || BIN === "481544" || BIN === "481545" || BIN === "481546") {
                                                var values = "&res_nic=" + $('#res_nic').val() + "&res_name=" + $('#res_name').val() + "&res_contact=" + $('#res_contact').val() + "&res_email=" + $('#res_email').val() + "&card_no=" + cardNo + "&reservedSeats=" + $('#reservedSeats').val() + "&functionName=reserve_seats";
                                                $.ajax({
                                                    type: "POST",
                                                    url: "controller.php",
                                                    data: values,
                                                    dataType: "text", success: function (data) {
                                                        if (data.includes("Please Try Again")) {
                                                            swal({
                                                                title: data,
                                                                icon: 'error',
                                                            });
                                                        }
                                                        else {
                                                            var pdf = new jsPDF();
                                                            pdf.text(10, 25, data);
                                                            pdf.save();
                                                            swal({
                                                                title: 'Reservation is being Processed',
                                                                text: data,
                                                                icon: 'success',
                                                            });
                                                            docReady();
                                                        }
                                                    }
                                                });
                                            }
                                            else {
                                                swal({
                                                    title: 'Not a NDB Credit Card Number!',
                                                    icon: 'error',
                                                });

                                            }

                                        }
                                        else {
                                            swal({
                                                title: 'Invalid Credit Card Number',
                                                icon: 'error',
                                            });

                                        }

                                    }
                                    else {
                                        swal({
                                            title: 'You can not reserve more than 5 seats!',
                                            icon: 'error',
                                        });
                                    }
                                }
                                else {
                                    swal({
                                        title: 'Please select seat(s)!',
                                        icon: 'error',
                                    });
                                }
                            }
                            else {
                                swal({
                                    title: 'Invalid Email!',
                                    icon: 'error',
                                });
                            }
                        }
                        else {
                            swal({
                                title: 'Contact number should contain 10 digits!',
                                icon: 'error',
                            });
                        }
                    }
                    else {
                        swal({
                            title: 'Please enter required details',
                            icon: 'error',
                        });
                    }
                });

                $('#submitNewDetails').click(function () {
                    if ($('#new_nic').val() !== "" && $('#new_name').val() !== "" && $('#new_contact').val() !== "" && $('#new_email').val() !== "") {
                        if ($('#new_nic').val().length === 10 || $('#new_nic').val().length === 12) {
                            if ($('#new_contact').val().length === 10) {
                                if (validateEmail($('#new_email').val())) {
                                    var values = "&res_nic=" + $('#new_nic').val() + "&res_name=" + $('#new_name').val() + "&res_contact=" + $('#new_contact').val() + "&res_email=" + $('#new_email').val() + "&functionName=add_to_contact_list";
                                    $.ajax({
                                        type: "POST",
                                        url: "controller.php",
                                        data: values,
                                        dataType: "text",
                                        success: function (data) {
                                            if (data.includes("Please Try Again")) {
                                                swal({
                                                    title: data,
                                                    icon: 'error',
                                                });
                                                $('#myModal').modal({
                                                    keyboard: false,
                                                    backdrop: 'static',
                                                })

                                            }
                                            else {
                                                $('#new_nic').val("");
                                                $('#new_name').val("");
                                                $('#new_contact').val("");
                                                $('#new_email').val("");
                                                alert(data);
                                                //window.open('https://ndbgoodlife.com/', '_self');
                                            }
                                        }
                                    });
                                }
                                else {
                                    swal({
                                        title: 'Invalid Email!',
                                        icon: 'error',
                                    });
                                }
                            }
                            else {
                                swal({
                                    title: 'Contact number should contain 10 digits!',
                                    icon: 'error',
                                });
                            }
                        } else {
                            swal({
                                title: 'Invalid NIC!',
                                icon: 'error',
                            });
                        }
                    }
                    else {
                        swal({
                            title: 'Please enter required details',
                            icon: 'error',
                        });
                    }


                });

                $('.closeModal').click(function () {
                    $('#new_nic').val("");
                    $('#new_name').val("");
                    $('#new_contact').val("");
                    $('#new_email').val("");
                    location.reload();
                });

            });

            function checkReservedSeats() {
                $.ajax({
                    type: "POST",
                    url: "controller.php",
                    data: "&functionName=check_reserved_seats",
                    dataType: "json",
                    success: function (data) {
                        var seatNosArr = data;
                        for (var i = 0; i < seatNosArr.length; i++) {
                            var checkbox = $("#" + seatNosArr[i].seatNo);
                            checkbox.attr("disabled", true);
                            if (checkbox.is(":checked")) {
                                checkbox.prop('checked', false);
                                $(checkbox).trigger("change");
                            }

                            var spanOfChkBox = checkbox.parent().children()[1].id;
                            $("#" + spanOfChkBox).css({"background": colorReserved});
                            // spanOfChkBox.style = "background:red";
                            $("#" + spanOfChkBox).attr('checked', false);

                            $("#" + spanOfChkBox).hide();
                        }
                    }
                });
            }

            function validateEmail(email) {
                var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                return re.test(String(email).toLowerCase());
            }

            function initiateCreditCardPrompt() {
                swal({
                    title: "Do you have a NDB Good Life Credit Card?",
                    icon: "warning", buttons: {
                        NoCard: 'No, I do not have',
                        YesCard: 'Yes, I have!'
                    },
                    dangerMode: true,
                }).then(function (isConfirm) {
                    if (isConfirm === "NoCard") {
                        $('#myModal').modal({
                            keyboard: false,
                            backdrop: 'static',
                        })
                    }
                    else if (isConfirm === "YesCard") {

                    }
                    else {
                        initiateCreditCardPrompt();
                    }
                });
            }

        </script>
    </head>
    <body>
        <div style="text-align: center"><img src="img/header.jpg" width="100%" ></div>
        <br/>

        <div class="modal fade" tabindex="-1" role="dialog" id="myModal">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 class="modal-title">Please mention following details</h3>
                        <button type="button" class="close closeModal" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">                                  
                            <div class="col-sm-12">
                                <label>NIC *</label><input type="text" name="new_nic" id="new_nic"  class="form-control" maxlength="12"/>
                            </div>
                        </div>
                        <div class="row"> 
                            <div class="col-sm-12">
                                <label>Name *</label><input type="text" name="new_name" id="new_name"  class="form-control"/>
                            </div>
                        </div>
                        <div class="row"> 
                            <div class="col-sm-12">
                                <label> Contact No *</label><input type="text" name="new_contact" id="new_contact"  class="form-control"  maxlength="10"/>
                            </div>
                        </div>
                        <div class="row"> 
                            <div class="col-sm-12">
                                <label>Email *</label><input type="text" name="new_email" id="new_email"  class="form-control"/>
                            </div>

                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" id="submitNewDetails">Submit</button>
                        <button type="button" class="btn btn-secondary closeModal" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>



        <div style="overflow:auto ; display:block" align="center" id="groundFloor">
            <!-- AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA -->
            <table class="floorPlan" style="color:black">
                <tr>         
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_G_A_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_A_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_A_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_A_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_A_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_A_17"></span><span class="switch-handle"></span></label></td>

                    <td>&nbsp;&nbsp;<sup>A&nbsp;</sup>&nbsp;</td>

                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_A_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_A_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_A_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_A_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_A_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_A_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_A_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_A_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_A_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_A_7"></span><span class="switch-handle"></span></label></td>

                    <td>&nbsp;&nbsp;<sup>A</sup>&nbsp;&nbsp;</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_A_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_A_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_A_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_A_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_A_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_A_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_A_1"></span><span class="switch-handle"></span></label></td>

                </tr>
            </table>
            
            <!-- BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB -->
            <table class="floorPlan" style="color:black">
                <tr>   
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_B_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_B_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_B_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_B_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_B_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_B_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_B_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_B_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_B_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_B_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_B_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_B_16"></span><span class="switch-handle"></span></label></td>
                    
                    <td>&nbsp;&nbsp;<sup>B</sup>&nbsp;&nbsp;&nbsp;&nbsp;</td>

                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_B_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_B_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_B_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_B_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_B_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_B_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_B_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_B_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_B_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_B_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_B_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_B_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_B_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_B_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_B_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_B_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_B_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_B_7"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    
                    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<sup>B</sup>&nbsp;&nbsp;</td>
                    
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_B_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_B_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_B_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_B_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_B_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_B_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_B_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_B_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_B_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_B_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_B_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_B_1"></span><span class="switch-handle"></span></label></td>
                </tr>                
            </table>
            
            <!-- CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC -->
            <table class="floorPlan" style="color:black">
                <tr>         
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_G_C_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_C_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_C_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_C_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_C_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_C_17"></span><span class="switch-handle"></span></label></td>

                    <td>&nbsp;&nbsp;<sup>C</sup><sup>&nbsp;</sup>&nbsp;</td>

                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_C_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_C_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_C_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_C_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_C_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_C_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_C_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_C_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_C_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_C_7"></span><span class="switch-handle"></span></label></td>

                    <td>&nbsp;&nbsp;<sup>C</sup>&nbsp;&nbsp;</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_C_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_C_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_C_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_C_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_C_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_C_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_C_1"></span><span class="switch-handle"></span></label></td>

                </tr>
            </table>
            
            <!-- DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD -->
            <table class="floorPlan" style="color:black">
                <tr>   
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_D_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_D_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_D_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_D_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_D_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_D_16"></span><span class="switch-handle"></span></label></td>
                    
                    <td>&nbsp;&nbsp;<sup>D</sup>&nbsp;&nbsp;&nbsp;<sup>&nbsp;&nbsp;</sup></td>

                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_D_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_D_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_D_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_D_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_D_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_D_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_D_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_D_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_D_7"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    
                    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<sup>D</sup>&nbsp;<sup>&nbsp;</sup></td>
                    
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_D_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_D_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_D_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_D_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_D_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_D_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_D_1"></span><span class="switch-handle"></span></label></td>
                </tr>                
            </table>
            
            <!-- EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE -->
            <table class="floorPlan" style="color:black">
                <tr>         
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_G_E_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_E_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_E_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_E_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_E_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_E_17"></span><span class="switch-handle"></span></label></td>

                    <td>&nbsp;&nbsp;<sup>E</sup>&nbsp;</sup>&nbsp;</td>

                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_E_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_E_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_E_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_E_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_E_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_E_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_E_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_E_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_E_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_E_7"></span><span class="switch-handle"></span></label></td>

                    <td>&nbsp;&nbsp;<sup>E</sup>&nbsp;</sup>&nbsp;</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_E_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_E_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_E_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_E_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_E_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_E_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_E_1"></span><span class="switch-handle"></span></label></td>

                </tr>
            </table>
            
            <!-- FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF -->
            <table class="floorPlan" style="color:black">
                <tr>   
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_F_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_F_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_F_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_F_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_F_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_F_16"></span><span class="switch-handle"></span></label></td>
                    
                    <td>&nbsp;&nbsp;<sup>F</sup>&nbsp;&nbsp;&nbsp;&nbsp;<sup>&nbsp;</sup></td>

                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_F_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_F_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_F_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_F_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_F_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_F_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_F_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_F_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_F_7"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    
                    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<sup>F</sup>&nbsp;<sup>&nbsp;</sup></td>
                    
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_F_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_F_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_F_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_F_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_F_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_F_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_F_1"></span><span class="switch-handle"></span></label></td>
                </tr>                
            </table>
            
            <!-- GGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG -->
            <table class="floorPlan" style="color:black">
                <tr>         
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_G_G_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_G_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_G_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_G_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_G_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_G_17"></span><span class="switch-handle"></span></label></td>

                    <td>&nbsp;&nbsp;<sup>G</sup>&nbsp;&nbsp;</td>

                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_G_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_G_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_G_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_G_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_G_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_G_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_G_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_G_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_G_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_G_7"></span><span class="switch-handle"></span></label></td>

                    <td>&nbsp;&nbsp;<sup>G&nbsp;</sup>&nbsp;</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_G_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_G_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_G_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_G_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_G_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_G_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_G_1"></span><span class="switch-handle"></span></label></td>

                </tr>
            </table>
            
            <!-- HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH -->
            <table class="floorPlan" style="color:black">
                <tr>   
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_H_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_H_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_H_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_H_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_H_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_H_16"></span><span class="switch-handle"></span></label></td>
                    
                    <td>&nbsp;&nbsp;<sup>H</sup>&nbsp;&nbsp;&nbsp;&nbsp;<sup>&nbsp;</sup></td>

                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_H_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_H_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_H_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_H_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_H_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_H_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_H_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_H_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_H_7"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    
                    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<sup>H</sup>&nbsp;<sup>&nbsp;</sup></td>
                    
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_H_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_H_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_H_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_H_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_H_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_H_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_H_1"></span><span class="switch-handle"></span></label></td>
                </tr>                
            </table>
            <br/>
            <!-- IIIIIIIIIIIIIIIIIIIIIIIIIIIII -->
            <table class="floorPlan" style="color:black">
                <tr>         
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_G_I_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_I_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_I_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_I_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_I_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_I_17"></span><span class="switch-handle"></span></label></td>

                    <td>&nbsp;&nbsp;&nbsp;<sup>I</sup>&nbsp;&nbsp;</td>

                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_I_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_I_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_I_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_I_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_I_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_I_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_I_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_I_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_I_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_I_7"></span><span class="switch-handle"></span></label></td>

                    <td>&nbsp;&nbsp;&nbsp;<sup>I</sup>&nbsp;&nbsp;</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_I_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_I_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_I_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_I_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_I_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_I_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_I_1"></span><span class="switch-handle"></span></label></td>

                </tr>
            </table>
            
            <!-- JJJJJJJJJJJJJJJJJJJJJJJJJJJJ -->
            <table class="floorPlan" style="color:black">
                <tr>   
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_J_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_J_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_J_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_J_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_J_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_J_16"></span><span class="switch-handle"></span></label></td>
                    
                    <td>&nbsp;&nbsp;&nbsp;<sup>J</sup>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>

                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_J_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_J_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_J_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_J_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_J_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_J_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_J_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_J_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_J_7"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    
                    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<sup>J&nbsp;</sup>&nbsp;</td>
                    
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_J_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_J_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_J_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_J_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_J_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_J_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_J_1"></span><span class="switch-handle"></span></label></td>
                </tr>                
            </table>
            
            <!-- KKKKKKKKKKKKKKKKKKKKKKKKKKKKKK -->
            <table class="floorPlan" style="color:black">
                <tr>         
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_G_K_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_K_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_K_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_K_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_K_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_K_17"></span><span class="switch-handle"></span></label></td>

                    <td>&nbsp;&nbsp;<sup>K&nbsp;&nbsp;</sup>&nbsp;</td>

                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_K_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_K_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_K_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_K_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_K_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_K_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_K_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_K_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_K_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_K_7"></span><span class="switch-handle"></span></label></td>

                    <td>&nbsp;&nbsp;<sup>K&nbsp;</sup>&nbsp;</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_K_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_K_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_K_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_K_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_K_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_K_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_K_1"></span><span class="switch-handle"></span></label></td>

                </tr>
            </table>
            
            <!-- LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL -->
            <table class="floorPlan" style="color:black">
                <tr>   
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_L_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_L_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_L_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_L_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_L_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_L_16"></span><span class="switch-handle"></span></label></td>
                    
                    <td>&nbsp;&nbsp;<sup>L</sup>&nbsp;&nbsp;&nbsp;&nbsp;<sup>&nbsp;</sup></td>

                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_L_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_L_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_L_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_L_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_L_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_L_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_L_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_L_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_L_7"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    
                    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<sup>L</sup>&nbsp;<sup>&nbsp;&nbsp;</sup></td>
                    
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_L_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_L_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_L_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_L_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_L_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_L_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_L_1"></span><span class="switch-handle"></span></label></td>
                </tr>                
            </table>
            
            <!-- MMMMMMMMMMMMMMMMMMMMMMMMM -->
            <table class="floorPlan" style="color:black">
                <tr>         
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_G_M_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_M_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_M_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_M_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_M_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_M_17"></span><span class="switch-handle"></span></label></td>

                    <td>&nbsp;&nbsp;<sup>M</sup>&nbsp;&nbsp;</td>

                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_M_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_M_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_M_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_M_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_M_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_M_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_M_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_M_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_M_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_M_7"></span><span class="switch-handle"></span></label></td>

                    <td>&nbsp;&nbsp;<sup>M&nbsp;</sup>&nbsp;</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_M_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_M_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_M_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_M_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_M_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_M_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_M_1"></span><span class="switch-handle"></span></label></td>

                </tr>
            </table>
            
            <!-- NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN -->
            <table class="floorPlan" style="color:black">
                <tr>   
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_N_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_N_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_N_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_N_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_N_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_N_16"></span><span class="switch-handle"></span></label></td>
                    
                    <td>&nbsp;&nbsp;<sup>N</sup>&nbsp;&nbsp;&nbsp;&nbsp;<sup>&nbsp;</sup></td>

                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_N_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_N_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_N_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_N_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_N_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_N_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_N_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_N_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_N_7"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    
                    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<sup>N</sup>&nbsp;<sup>&nbsp;</sup></td>
                    
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_N_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_N_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_N_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_N_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_N_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_N_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_N_1"></span><span class="switch-handle"></span></label></td>
                </tr>                
            </table>
            
            <!-- OOOOOOOOOOOOOOOOOOOOOOOO -->
            <table class="floorPlan" style="color:black">
                <tr>         
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_G_O_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_O_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_O_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_O_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_O_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_O_17"></span><span class="switch-handle"></span></label></td>

                    <td>&nbsp;&nbsp;<sup>O</sup>&nbsp;</sup>&nbsp;</td>

                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_O_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_O_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_O_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_O_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_O_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_O_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_O_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_O_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_O_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_O_7"></span><span class="switch-handle"></span></label></td>

                    <td>&nbsp;&nbsp;<sup>O</sup>&nbsp;</sup>&nbsp;</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_O_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_O_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_O_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_O_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_O_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_O_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_O_1"></span><span class="switch-handle"></span></label></td>

                </tr>
            </table>
            
            <!-- PPPPPPPPPPPPPPPPPPPPPPPPP -->
            <table class="floorPlan" style="color:black">
                <tr>   
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_P_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_P_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_P_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_P_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_P_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_P_16"></span><span class="switch-handle"></span></label></td>
                    
                    <td>&nbsp;&nbsp;<sup>P</sup>&nbsp;&nbsp;&nbsp;&nbsp;<sup>&nbsp;</sup></td>

                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_P_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_P_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_P_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_P_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_P_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_P_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_P_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_P_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_P_7"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    
                    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<sup>P</sup>&nbsp;<sup>&nbsp;</sup></td>
                    
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_P_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_P_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_P_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_P_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_P_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_P_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_P_1"></span><span class="switch-handle"></span></label></td>
                </tr>                
            </table>
            
            <!-- QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ -->
            <table class="floorPlan" style="color:black">
                <tr>         
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_22"/><span class="switch-label" data-on="22" data-off="22" id="Span_G_Q_22"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_Q_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_Q_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_Q_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_Q_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_Q_17"></span><span class="switch-handle"></span></label></td>

                    <td>&nbsp;&nbsp;<sup>Q</sup>&nbsp;</sup>&nbsp;</td>

                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_Q_16"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_Q_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_Q_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_Q_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_Q_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_Q_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_Q_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_Q_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_Q_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_Q_7"></span><span class="switch-handle"></span></label></td>

                    <td>&nbsp;&nbsp;<sup>Q</sup>&nbsp;</sup>&nbsp;</td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_Q_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_Q_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_Q_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_Q_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_Q_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_Q_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_Q_1"></span><span class="switch-handle"></span></label></td>

                </tr>
            </table>
            <br/>
            <!-- RRRRRRRRRRRRRRRRRRRRRR -->
            <table class="floorPlan" style="color:black">
                <tr>   
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_21"/><span class="switch-label" data-on="21" data-off="21" id="Span_G_R_21"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_20"/><span class="switch-label" data-on="20" data-off="20" id="Span_G_R_20"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_19"/><span class="switch-label" data-on="19" data-off="19" id="Span_G_R_19"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_18"/><span class="switch-label" data-on="18" data-off="18" id="Span_G_R_18"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_17"/><span class="switch-label" data-on="17" data-off="17" id="Span_G_R_17"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_16"/><span class="switch-label" data-on="16" data-off="16" id="Span_G_R_16"></span><span class="switch-handle"></span></label></td>
                    
                    <td>&nbsp;&nbsp;<sup>R</sup>&nbsp;&nbsp;&nbsp;&nbsp;<sup>&nbsp;</sup></td>

                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_15"/><span class="switch-label" data-on="15" data-off="15" id="Span_G_R_15"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_14"/><span class="switch-label" data-on="14" data-off="14" id="Span_G_R_14"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_13"/><span class="switch-label" data-on="13" data-off="13" id="Span_G_R_13"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_12"/><span class="switch-label" data-on="12" data-off="12" id="Span_G_R_12"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_11"/><span class="switch-label" data-on="11" data-off="11" id="Span_G_R_11"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_10"/><span class="switch-label" data-on="10" data-off="10" id="Span_G_R_10"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_9"/><span class="switch-label" data-on="9" data-off="9" id="Span_G_R_9"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_8"/><span class="switch-label" data-on="8" data-off="8" id="Span_G_R_8"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_7"/><span class="switch-label" data-on="7" data-off="7" id="Span_G_R_7"></span><span class="switch-handle"></span></label></td>
                    <td></td>
                    
                    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<sup>R</sup>&nbsp;<sup>&nbsp;</sup></td>
                    
                    <td></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_6"/><span class="switch-label" data-on="6" data-off="6" id="Span_G_R_6"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_5"/><span class="switch-label" data-on="5" data-off="5" id="Span_G_R_5"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_4"/><span class="switch-label" data-on="4" data-off="4" id="Span_G_R_4"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_3"/><span class="switch-label" data-on="3" data-off="3" id="Span_G_R_3"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_2"/><span class="switch-label" data-on="2" data-off="2" id="Span_G_R_2"></span><span class="switch-handle"></span></label></td>
                    <td><label class="switch switch-yes-no"><input class="switch-input" type="checkbox" id="G_R_1"/><span class="switch-label" data-on="1" data-off="1" id="Span_G_R_1"></span><span class="switch-handle"></span></label></td>
                </tr>                
            </table>      
        </div>

        <br/>
        <div class="container">
            <div class="row">      
                <!--            <div class="col-sm-1"></div>
                            <div class="col-sm-2">
                                <label>NIC *</label><input type="text" name="res_nic" id="res_nic"  class="form-control" maxlength="12"/>
                            </div>-->
                <div class="col-sm-3">
                    <label style="color: white">Name *</label><input type="text" name="res_name" id="res_name"  class="form-control"/>
                </div>
                <div class="col-sm-3">
                    <label style="color: white"> Contact No *</label><input type="text" name="res_contact" id="res_contact"  class="form-control"  maxlength="10"/>
                </div>
                <div class="col-sm-3">
                    <label style="color: white">Email *</label><input type="text" name="res_email" id="res_email"  class="form-control"/>
                </div>
                <div class="col-sm-3">
                    <label style="color: white">NDB Credit Card No *</label><input type="password" name="res_card" id="res_card"  class="form-control" maxlength="16"/>
                </div>
            </div>
            <br/>
            <div class="row">      
                <div class="col-sm-3">
                    <label style="color: white">Total Price</label>
                    <input type="text" value="0" disabled id="totValueShow" class="form-control"/>
                </div>
                <div class="col-sm-6">
                    <label style="color: white">Selected Seats</label>
                    <input type="text" id="reservedSeatsShow" disabled value=""/>
                </div>
                <div class="col-sm-3" style="text-align: center">
                    <br/>
                    <input type="button" class="btn btn-primary" id="reserveSeats" value="Reserve"/>
                </div>
            </div>


            <input type="hidden" id="reservedSeats" value="0" disabled/><br/>
            <input type="hidden" id="totValue" value="0" disabled />
        </div>

    </body>
</html>
