<?php

include 'check_admin_privilages.php';

if ($isValidAdmin) {
    include 'utilities/enccon/mql/connection.php';
    $sql0 = "SELECT * FROM nocardlist";
    $result = mysqli_query($conn, $sql0);
    $resultsArr = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $resultsArr[] = $row;
    }
    print json_encode($resultsArr);
    mysqli_close($conn);
} else {
    echo "Invalid User Credential. Please Try Again.";
}
?>