<?php

include 'utilities/enccon/mql/connection.php';

$sql = "SELECT seatNo FROM seat where res_status='Reserved'";
$result = mysqli_query($conn, $sql);
$resultsArr = array();
while ($row = mysqli_fetch_assoc($result)) {
    $resultsArr[] = $row;
}

mysqli_close($conn);
print json_encode($resultsArr);
?>