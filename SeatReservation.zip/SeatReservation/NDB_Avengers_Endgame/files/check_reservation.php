<?php

include 'check_admin_privilages.php';

if ($isValidAdmin) {

    if (isset($_POST['searchBy'])) {
        include 'utilities/enccon/mql/connection.php';

        $searchBy = $_POST['searchBy'];
        $seatID = "";
        $res_name = "";
        $sql0 = "";
        if (strcmp($searchBy, "seat") == 0) {
            $seatID = $_POST['seatID'];
            $sql0 = "SELECT * FROM seat where seatNo='$seatID'";
        } else if (strcmp($searchBy, "name") == 0) {
            $res_name = $_POST['$res_name'];
            $sql0 = "SELECT * FROM seat where res_name like '%$res_name%'";
        }


        $result = mysqli_query($conn, $sql0);
        $resultsArr = array();
        while ($row = mysqli_fetch_assoc($result)) {
            $resultsArr[] = $row;
        }
        print json_encode($resultsArr);

        mysqli_close($conn);
    } else {
        print "Something went wrong";
    }
} else {
    print "Invalid User Credential. Please Try Again.";
}
?>