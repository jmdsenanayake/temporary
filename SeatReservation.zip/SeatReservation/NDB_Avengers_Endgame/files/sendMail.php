<?php
//
//$to = "janaka.senanayake@ndbbank.com";
////    $subject = "NDB Bank - Seat Booking";
////    $txt = "Hello world!";
////    $headers = "From: NDBSeatBooking" . "\r\n" .
////    "CC: janaka.senanayake@ndbbank.com";
////
////    mail($to,$subject,$txt,$headers);
//
//$toMail = "janaka.senanayake@ndbbank.com";
//$toName = "Janaka";
//$cc1Mail="janaka.senanayake@gmail.com";
//$cc1Name="Janaka1";
//
//$cc2Mail="janaka.mit2011@gmail.com";
//$cc2Name="Janaka2";
//
//$emailsubject = "NDB Bank - Seat Booking";
//$message = "Hello world!";
//
//include 'sendMailSMTP.php';
//
//$mail->AddCC($cc1Mail, $cc1Name);
//$mail->AddCC($cc2Mail, $cc2Name);
//
//$mail->addAddress($toMail, $toName);
//
//$mail->Subject = $emailsubject;
//$mail->Body = $message;
//$mail->AltBody = $message;
//
//if (!$mail->send()) {
//    echo "Mailer Error: " . $mail->ErrorInfo;
//} else {
//    echo "Message has been sent successfully";
//}


include 'utilities/enccon/mql/connection.php';
require_once "PHPMailer/PHPMailerAutoload.php";

$toMail = "janaka.senanayake@ndbbank.com";
$toName = "Janaka";
$emailsubject = "NDB Bank - Seat Booking";
$message = "Hello world!";

//send to Customer
$mail = new PHPMailer;
//loading from connection file
$mail->SMTPDebug = $smtpDebug;  
$mail->isSMTP();                            
$mail->Host = $smtpHost;
$mail->SMTPAuth = $SMTPAuth;   
$mail->Username = $MailUsername;                 
$mail->Password = $MailPassword; 
$mail->SMTPSecure = $SMTPSecure; 
$mail->Port = $TCPPort; 
$mail->From = $EmailFrom;
$mail->FromName = $EmailFromName;
$mail->isHTML($isHTML);

//loading from this file
$mail->addAddress($toMail, $toName);
$mail->Subject = $emailsubject;
$mail->Body = $message;
$mail->AltBody = $message;

if (!$mail->send()) {
    echo "Mailer Error: " . $mail->ErrorInfo;
} else {
    echo "Message has been sent successfully";
}
//
////send to Cards
//$cc1Mail="janaka.senanayake@gmail.com";
//$cc1Name="Janaka1";
//$cc2Mail="janaka.mit2011@gmail.com";
//$cc2Name="Janaka2";
//
//$mail2 = new PHPMailer;
////loading from connection file
//$mail2->SMTPDebug = $smtpDebug;  
//$mail2->isSMTP();                            
//$mail2->Host = $smtpHost;
//$mail2->SMTPAuth = $SMTPAuth;   
//$mail2->Username = $MailUsername;                 
//$mail2->Password = $MailPassword; 
//$mail2->SMTPSecure = $SMTPSecure; 
//$mail2->Port = $TCPPort; 
//$mail2->From = $EmailFrom;
//$mail2->FromName = $EmailFromName;
//$mail2->isHTML($isHTML);
//
////loading from this file
//$mail2->AddCC($cc1Mail, $cc1Name);
//$mail2->AddCC($cc2Mail, $cc2Name);
//$mail2->addAddress($toMail, $toName);
//$mail2->Subject = $emailsubject;
//$mail2->Body = $message;
//$mail2->AltBody = $message;
//
//if (!$mail2->send()) {
//    echo "Mailer Error: " . $mail2->ErrorInfo;
//} else {
//    echo "Message has been sent successfully";
//}


?>