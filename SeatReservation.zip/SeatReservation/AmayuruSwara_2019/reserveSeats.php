<?php

	include 'Connection.php';
	
	$epfNo = $_POST['epfNo'];
	//$empName = $_POST['empName'];
	$empName ="";
	//$empEmail = $_POST['empEmail'];
    $staffAcc = $_POST['staffAcc'];
    $contactNo = $_POST['contactNo'];
	$reservedSeats = $_POST['reservedSeats'];	
	$staffDiscount = $_POST['staffDiscount'];
	$staffDiscountPriceCeiling = $_POST['staffDiscountPriceCeiling'];
	$totalDiscountedPrice=$_POST['totalDiscountedPrice'];
	
//	$SeatArr=split("\,",$reservedSeats);
        $SeatArr=explode("\,",$reservedSeats);
	$SeatArrReserved=array();
	$totalPurchasedPrice=0;
	$seatsBooked=false;
	
	$sql = "SELECT empName FROM employee where epfNo='$epfNo'";
	$result = mysqli_query($conn, $sql);
	$resultsArr=array();
    while($row = mysqli_fetch_assoc($result)) {
        $empName=$row['empName'];
    }
	
	if(strcmp($empName,"")!=0){
		for ($i = 0; $i < sizeOf($SeatArr); $i++) {
		
		//check whether the seat is available		
		$sql1 = "SELECT price FROM seat where status='Available' and seatNo='$SeatArr[$i]' and price>0";
		$result = mysqli_query($conn, $sql1);
		if($row = mysqli_fetch_assoc($result)) {
			
		}
		else{
			$seatsBooked=true;
		}
		
		
	}
	
	if(!$seatsBooked){
		for ($i = 0; $i < sizeOf($SeatArr); $i++) {
			
			//check whether the seat is available		
			$sql1 = "SELECT price FROM seat where status='Available' and seatNo='$SeatArr[$i]' and price>0";
			$result = mysqli_query($conn, $sql1);
			if($row = mysqli_fetch_assoc($result)) {
				
				$price= $row["price"];
				$purchasedPrice=($price>=$staffDiscountPriceCeiling? ($price-$staffDiscount): $price);
				//$sql2 = "Update seat set epfNo='$epfNo',resName='$empName',resEmail='$empEmail',resContact='$contactNo',accNo='$staffAcc',reservedDateTime=now(),status='Reserved', purchasedPrice=$purchasedPrice where seatNo='$SeatArr[$i]' and status='Available'";
				$sql2 = "Update seat set epfNo='$epfNo',resContact='$contactNo',accNo='$staffAcc',reservedDateTime=now(),status='Reserved', purchasedPrice=$purchasedPrice where seatNo='$SeatArr[$i]' and status='Available'";
				mysqli_query($conn, $sql2);		
				array_push($SeatArrReserved,$SeatArr[$i]);	
				$totalPurchasedPrice+=$purchasedPrice;			

				$sql3 = "Update seatSummary set reservedSeats=reservedSeats+1 where seatPrice=$price";
				mysqli_query($conn, $sql3);			
			}	
		}
		
		$seatNoforPrinting="";	
	
	
		for ($x = 0; $x <  sizeOf($SeatArrReserved); $x++) {
//			$SeatNoDetails=split("_",$SeatArrReserved[$x]);		
                    $SeatNoDetails=explode("_",$SeatArrReserved[$x]);		
			$floor="";
			if($SeatNoDetails[0]=="G"){
				$floor="Ground Floor";
			}
			else if($SeatNoDetails[0]=="B1"){
				$floor="1st Floor Balcony";
			}
			else if($SeatNoDetails[0]=="B2"){
				$floor="2nd Floor Balcony";
			}
			$seatNoforPrinting.="\n\t".($x+1).") ".$floor." - ".$SeatArrReserved[$x];
		} 
		
		if($totalPurchasedPrice>0){
			echo "Dear $empName ($epfNo),\n\n You have successfully reserved following seats for the Amayuru Swara 2018.".$seatNoforPrinting."\n\n LKR ".number_format($totalPurchasedPrice)."/- the total amount applicable for your ticket purchases will be \n deducted from account number $staffAcc according to the terms & \n conditions set out by NDBSRC.\n\nThank You.\nNDBSRC";
		}
		else{
			echo "Booking Unsuccessfull. Please Try Again.";
		}
	}
	else{
		echo "Some of the seats that you have selected are already reserved. Those will be de-selected automatically. Please Try Again.";
	}
		
	}
	
	else{
		echo "Invalid EPFNo. Please Try Again.";
	}
	
	
	
	mysqli_close($conn);
?>