<?php

if (isset($_POST['seatID'])) {
    $seatID = $_POST['seatID'];

    include 'check_admin_privilages.php';

    if ($isValidAdmin) {
        include 'utilities/enccon/mql/connection.php';
        $sql0 = "SELECT price FROM seat where res_status='Reserved' and seatNo='$seatID'";
        $result = mysqli_query($conn, $sql0);
        if ($row = mysqli_fetch_assoc($result)) {
            $price = $row["price"];
            $sql1 = "update seat set res_status='Available', purchasedPrice=null,res_nic=null,res_name=null,res_contact=null,res_email=null,card_no=null, res_datetime=null where seatNo='$seatID' and res_status='reserved'";
            mysqli_query($conn, $sql1);

            echo "You have successfully canceled the reservation of seatNo = $seatID \nfor the Event.\n\nThank You.\nNDB Card Center";
        } else {
            echo "Invalid Reserved SeatNo. Please Try Again.";
        }
        mysqli_close($conn);
        
        if ($sendEmail) {
        require_once "PHPMailer/PHPMailerAutoload.php";
        $msgToCardCenter = "Dear Card Center,\n\n Following reservation has been cancled by the Admin.\n\n"
                . "Seat No : $seatID \n\nThank You.";

        $toMail = $cardCenterEmail_1;
        $toName = $cardCenterName_1;
        $emailsubject = "NDB Bank - Arsikland - Cancelation of Reservation";
        $message = $msgToCardCenter;

        //send to Cards
        $cc1Mail = $cardCenterEmail_2;
        $cc1Name = $cardCenterName_2;
        $cc2Mail = $cardCenterEmail_3;
        $cc2Name = $cardCenterName_3;
        $cc3Mail = $cardCenterEmail_4;
        $cc3Name = $cardCenterName_4;
        $cc4Mail = $cardCenterEmail_5;
        $cc4Name = $cardCenterName_5;

        $mail2 = new PHPMailer;
        //loading from connection file
        $mail2->SMTPDebug = $smtpDebug;
        $mail2->isSMTP();
        $mail2->Host = $smtpHost;
        $mail2->SMTPAuth = $SMTPAuth;
        $mail2->Username = $MailUsername;
        $mail2->Password = $MailPassword;
        $mail2->SMTPSecure = $SMTPSecure;
        $mail2->Port = $TCPPort;
        $mail2->From = $EmailFrom;
        $mail2->FromName = $EmailFromName;
        $mail2->isHTML($isHTML);

        //loading from this file
        $mail2->AddCC($cc1Mail, $cc1Name);
        $mail2->AddCC($cc2Mail, $cc2Name);
        $mail2->AddCC($cc3Mail, $cc3Name);
        $mail2->AddCC($cc4Mail, $cc4Name);
        $mail2->addAddress($toMail, $toName);
        $mail2->Subject = $emailsubject;
        $mail2->Body = $message;
        $mail2->AltBody = $message;

        if (!$mail2->send()) {
            echo "Mailer Error: " . $mail2->ErrorInfo;
        } else {
//                    echo "Message has been sent successfully";
        }
    }
    } else {
        echo "Invalid User Credential. Please Try Again.";
    }
}
?>