<?php

$isValidAdmin = false;

if (isset($_POST['user']) && $_POST['pwd']) {
    $user = $_POST['user'];
    $pwd = $_POST['pwd'];

    if (strcmp($user, "LWEvent@2019") == 0 && strcmp($pwd, "LW2019#NDB_CARDS") == 0) {
        $isValidAdmin = true;
    }
}
?>