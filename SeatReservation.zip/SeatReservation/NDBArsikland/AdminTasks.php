<html>
    <head>
        <script src="js/jquery.min.js"></script>
        <script src="js/jspdf.min.js"></script>	
        <title>Arsikland - NDB Bank - Admin Tasks</title>
        
        <style>
            body {
                background-color: black;
            }
        </style>
        <script>
            $(document).ready(function () {
                $('#reservation').hide();
                $('#allSeats').hide();                

                $('#cancelReservation').click(function () {
                    var username = $('#username').val();
                    var password = $('#password').val();
                    var seatID = $('#cancelSeatID').val();

                    if (username !== "" && password !== "" && seatID !== "") {
                        var values = "&user=" + username + "&pwd=" + password + "&seatID=" + seatID+ "&functionName=cancel_reservation";
                        $.ajax({
                            type: "POST",
                            url: "controller.php",
                            data: values,
                            dataType: "text",
                            success: function (data) {
                                if (data.includes("Please Try Again")) {
                                    alert(data);
                                }
                                else {
                                    var pdf = new jsPDF();
                                    pdf.text(10, 25, data);
                                    pdf.save();
                                    alert(data);
                                }


                            }
                        });
                    }
                    else {
                        alert('Please enter all the details');
                    }
                });

                $('#checkName').click(function () {
                    $('#reservation').show();
                    var res_name = $('#res_name').val();
                    $("#data td").parent().remove();
                     var username = $('#username').val();
                    var password = $('#password').val();

                    if (res_name !== "") {
                        var values = "&user=" + username + "&pwd=" + password + "&$res_name=" + res_name + "&searchBy=name"+ "&functionName=check_reservation";
                        $.ajax({
                            type: "POST",
                            url: "controller.php",
                            data: values,
                            dataType: "json",
                            success: function (data) {
                                if (data.includes("Please Try Again")) {
                                    alert(data);
                                }
                                else {
                                    for (var i = 0; i < data.length; i++) {
                                        $('#data tr:last').after('<tr><td><span>' + data[i].seatNo + '</span></td><td><span>' + data[i].price + '</span></td><td><span>' + data[i].res_status + '</span></td><td><span>' + data[i].res_nic + '</span></td><td><span>' + data[i].res_name + '</span></td><td><span>' + data[i].res_contact + '</span></td><td><span>' + data[i].res_email + '</span></td><td><span>' + data[i].card_no + '</span></td><td><span>' + data[i].res_datetime + '</span></td></tr>');
                                    }
                                }
                            }
                        });
                    }
                    else {
                        alert('Please enter Name');
                    }
                });

                $('#viewSeats').click(function () {
                 var username = $('#username').val();
                    var password = $('#password').val();
                    $('#allSeats').show();
                    $("#seatData td").parent().remove();
                    $.ajax({
                        type: "POST",
                        url: "controller.php",
                        data: "&user=" + username + "&pwd=" + password+ "&functionName=seat_data",
                        dataType: "json",
                        success: function (data) { 
                            for (var i = 0; i < data.length; i++) {
                                $('#seatData tr:last').after('<tr><td><span>' + data[i].seatNo + '</span></td><td><span>' + data[i].price + '</span></td><td><span>' + data[i].res_status + '</span></td><td><span>' + data[i].res_nic + '</span></td><td><span>' + data[i].res_name + '</span></td><td><span>' + data[i].res_contact + '</span></td><td><span>' + data[i].res_email + '</span></td><td><span>' + data[i].card_no + '</span></td><td><span>' + data[i].res_datetime + '</span></td></tr>');
                            }
                        }
                    });
                });
                
                $('#viewNoCardList').click(function () {
                 var username = $('#username').val();
                    var password = $('#password').val();
                    $('#noCCList').show();
                    $("#noCCData td").parent().remove();
                    $.ajax({
                        type: "POST",
                        url: "controller.php",
                        data: "&user=" + username + "&pwd=" + password+ "&functionName=no_cc_data",
                        dataType: "json",
                        success: function (data) { 
                            for (var i = 0; i < data.length; i++) {
                                $('#noCCData tr:last').after('<tr><td><span>' + data[i].listID + '</span></td><td><span>' + data[i].contactName + '</span></td><td><span>' + data[i].contactNo + '</span></td><td><span>' + data[i].contactEmail + '</span></td><td><span>' + data[i].contactNIC + '</span></td><td><span>' + data[i].currentDateTime + '</span></td></tr>');
                            }
                        }
                    });
                });
            });
            
            function fillReport(){                
                $('#usernameReport').val($('#username').val());
                $('#passwordReport').val($('#password').val());       
                
                return true;
            }
            
            function fillReportNoCC(){                
                $('#usernameReportNoCC').val($('#username').val());
                $('#passwordReportNoCC').val($('#password').val());  
                return true;
            }

        </script>
    </head>

    <body style="color:  white">
        <h1>Admin Tasks</h1>
        <table>
            <tr><td>Username: </td><td><input type="text" name="username" id="username"  class="form-control"/><br/></td></tr>
            <tr><td>Password: </td><td><input type="password" name="password" id="password"  class="form-control"/><br/></td></tr>            
        </table>     
        <hr/>
        <h2>Cancel Reservation</h2>
        <table>         
            <tr><td>Seat No: </td><td><input type="text" name="cancelSeatID" id="cancelSeatID"  class="form-control"/><br/></td><td><input type="button" id="cancelReservation" value="Cancel Reservation"/></td></tr>
        </table> 
        <hr/>
        <h2>Reservation Search By Name</h2>
        <table>
            <tr><td>Name : </td><td><input type="text" name="res_name" id="res_name"  class="form-control"/><br/></td><td><input type="button" id="checkName" value="Check"/></td></tr>
        </table>
        <div id="reservation" style="display:none">
            <table border='1' id="data" >
                <thead>
                <th>Seat No</th>
                <th>Price</th>
                <th>Status</th>
                <th>NIC</th>
                <th>Name</th>
                <th>Contact</th>
                <th>Email</th>
                <th>NDB Card No</th>
                <th>Reserved Timestamp</th>
                </thead>			
            </table>
        </div>
        <br/>
        <hr/>

        <h2>All Seats</h2>

        <form action="controller.php" onsubmit="return fillReport()" method="POST">
            <input type="hidden" id="usernameReport" name="user">
            <input type="hidden" id="passwordReport" name="pwd">
            <input type="hidden" name="functionName" value="report">
            <input type="button" value="View" id="viewSeats"/>
            <input type="submit" value="Download as Excel">
        </form>
        <div id="allSeats" style="display:none">
            <table border='1' id="seatData"  >
                <thead>
                <th>Seat No</th>
                <th>Price</th>
                <th>Status</th>
                <th>NIC</th>
                <th>Name</th>
                <th>Contact</th>
                <th>Email</th>
                <th>NDB Card No</th>
                <th>Reserved Timestamp</th>
                </thead>			
            </table>
        </div>
        <hr/>
        
        <h2>Non NDB Credit Card Customer Details</h2>

        <form action="controller.php" onsubmit="return fillReportNoCC()" method="POST">
             <input type="hidden" id="usernameReportNoCC" name="user">
            <input type="hidden" id="passwordReportNoCC" name="pwd">
            <input type="hidden" name="functionName" value="report_no_cc">
            <input type="button" value="View" id="viewNoCardList"/>
            <input type="submit" value="Download as Excel">
        </form>
        <div id="noCCList" style="display:none">
            <table border='1' id="noCCData"  >
                <thead>
                <th>Record ID</th>
                <th>Contact Name</th>
                <th>Contact No</th>
                <th>Contact Email</th>
                <th>Contact NIC</th>                
                <th>Checked Timestamp</th>
                </thead>			
            </table>
        </div>
        <hr/>

    </body>
</html>