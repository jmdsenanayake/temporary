/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.PointsHandling.DAO.Impl;

import gcsm.PointsHandling.DAO.CalculatePointsDAO;
import gcsm.Utitlities.Impl.Auditing;
import gcsm.Utitlities.Impl.DatabaseConnection;
import gcsm.Utitlities.Impl.JSONObjects;
import gcsm.Utitlities.Model.ResponceHandler;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Janaka_5977
 */
public class CalculatePointsDAOImpl implements CalculatePointsDAO {

    static Logger log = LogManager.getLogger(CalculatePointsDAOImpl.class.getName());
    private ResponceHandler responceHandler;
    static DatabaseConnection databaseConnection;
    static Connection currentConnection = null;
    private PreparedStatement preparedStatement = null;
    private ResultSet resultSet = null;
    private JSONObjects jsonObejcts;
    private JSONArray jsArr;

    @Override
    public void calculateAndStorePointDetails(String relatedUser, String targetValue, String setupUser) {
        String currentYearMonthDetails[] = getCurrentYearMonthDetails();
        String year_month_from = currentYearMonthDetails[0];
        String year_month_to = currentYearMonthDetails[1];

        String related_user = relatedUser;
        double target_value = Double.parseDouble(targetValue);

        double achivement_value = getPortfolioValuesForSpecificUser(relatedUser, year_month_from, year_month_to);
        double target_achivement_percentage = (achivement_value / target_value) * 100;
        String point_value = getPointValue(target_achivement_percentage);

        int point_detail_status = 0;
        String setup_user = setupUser;

        responceHandler = new ResponceHandler();
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        jsonObejcts = new JSONObjects();

        //Audit Trail        
        Auditing auditing = new Auditing();
        String auditType = "INSERT";
        String related_table = "gcsm_point_details";
        String record_pk = "";
        String old_value = "##Empty##";

        try {

            String insertPointValuesQuery
                    = "INSERT INTO gcsm_point_details ("
                    + "related_user, " //1
                    + "target_value, " //2
                    + "achivement_value, " //3
                    + "target_achivement_percentage, " //4
                    + "point_value, " //5
                    + "year_month_from," //6
                    + "year_month_to, " //7
                    + "point_detail_status," //8
                    + "setup_user," //9
                    + "setup_timestamp) "
                    + "values (?,?,?,?,?,?,?,?,?,now())";

            preparedStatement = currentConnection.prepareStatement(insertPointValuesQuery, Statement.RETURN_GENERATED_KEYS);
            preparedStatement.setString(1, related_user);
            preparedStatement.setDouble(2, target_value);
            preparedStatement.setDouble(3, achivement_value);
            preparedStatement.setDouble(4, target_achivement_percentage);
            preparedStatement.setString(5, point_value);
            preparedStatement.setString(6, year_month_from);
            preparedStatement.setString(7, year_month_to);
            preparedStatement.setInt(8, point_detail_status);
            preparedStatement.setString(9, setup_user);

            preparedStatement.executeUpdate();

            //Audit Trail
            resultSet = preparedStatement.getGeneratedKeys();
            resultSet.next();
            record_pk = "" + (resultSet.getInt(1));

            databaseConnection.end_Connection(currentConnection);

            //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            auditing.saveAuditRecord(setup_user, related_table, auditType, record_pk, old_value, new_value);

        } catch (SQLException ex) {
            ex.printStackTrace();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public JSONArray viewPointDetails(JSONObject jasonobj) {

        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();
        try {
            String queryViewPointValues = "SELECT * from gcsm_point_details order by point_detail_id desc";

            preparedStatement = currentConnection.prepareStatement(queryViewPointValues);

            log.info(preparedStatement);

            resultSet = preparedStatement.executeQuery();
            int i = 0;
            while (resultSet.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("point_detail_id", resultSet.getInt("point_detail_id"));
                m_jsObj.put("related_user", resultSet.getString("related_user"));
                m_jsObj.put("target_value", resultSet.getDouble("target_value"));
                m_jsObj.put("achivement_value", resultSet.getDouble("achivement_value"));
                m_jsObj.put("target_achivement_percentage", resultSet.getDouble("target_achivement_percentage"));
                m_jsObj.put("point_value", resultSet.getString("point_value"));
                m_jsObj.put("point_detail_status", resultSet.getString("point_detail_status"));
                m_jsObj.put("year_month_from", resultSet.getString("year_month_from"));
                m_jsObj.put("year_month_to", resultSet.getString("year_month_to"));
                m_jsObj.put("setup_user", resultSet.getString("setup_user"));
                m_jsObj.put("setup_timestamp", resultSet.getString("setup_timestamp"));
                m_jsObj.put("approved_user", resultSet.getString("approved_user"));
                m_jsObj.put("approved_timestamp", resultSet.getString("approved_timestamp"));
                m_jsObj.put("approval_comment", resultSet.getString("approval_comment"));
                jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {
            e.printStackTrace();

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {

                responceHandler.setResponceModule("View_PointDetails");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return jsArr;
    }

    private double getPortfolioValuesForSpecificUser(String relatedUser, String yearMonthFrom, String yearMonthTo) {
        double portfolioValue = 0;

        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {

            String sql = "SELECT sum(portfolio_value) as total_achivement FROM gcsm_reward_details where reward_related_user=? and reward_yearmonth_from=? and reward_yearmonth_to=?";

            preparedStatement = currentConnection.prepareStatement(sql);
            preparedStatement.setString(1, relatedUser);
            preparedStatement.setString(2, yearMonthFrom);
            preparedStatement.setString(3, yearMonthTo);

            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                portfolioValue = resultSet.getDouble("total_achivement");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return portfolioValue;
    }

    private String getPointValue(double targetAchivementPercentage) {
        String pointValue = "";

        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {

            String sql = "SELECT * FROM gcsm_point_values where point_value_status=1 order by point_value_approve_reject_timestamp desc limit 1";

            double point_A_upper_value = 0;
            double point_A_lower_value = 0;
            double point_B_upper_value = 0;
            double point_B_lower_value = 0;
            double point_C_upper_value = 0;
            double point_C_lower_value = 0;
            double point_D_upper_value = 0;
            double point_D_lower_value = 0;

            preparedStatement = currentConnection.prepareStatement(sql);

            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                point_A_upper_value = resultSet.getDouble("point_A_upper_value");
                point_A_lower_value = resultSet.getDouble("point_A_lower_value");
                point_B_upper_value = resultSet.getDouble("point_B_upper_value");
                point_B_lower_value = resultSet.getDouble("point_B_lower_value");
                point_C_upper_value = resultSet.getDouble("point_C_upper_value");
                point_C_lower_value = resultSet.getDouble("point_C_lower_value");
                point_D_upper_value = resultSet.getDouble("point_D_upper_value");
                point_D_lower_value = resultSet.getDouble("point_D_lower_value");
            }

            if (targetAchivementPercentage < point_A_upper_value && targetAchivementPercentage >= point_A_lower_value) {
                pointValue = "A";
            } else if (targetAchivementPercentage < point_B_upper_value && targetAchivementPercentage >= point_B_lower_value) {
                pointValue = "B";
            } else if (targetAchivementPercentage < point_C_upper_value && targetAchivementPercentage >= point_C_lower_value) {
                pointValue = "C";
            } else if (targetAchivementPercentage < point_D_upper_value && targetAchivementPercentage >= point_D_lower_value) {
                pointValue = "D";
            }

        } catch (Exception e) {
            e.printStackTrace();

        }

        return pointValue;
    }

    @Override
    public ResponceHandler initiatePointCalculationStatus(JSONObject jasonobj) {
        responceHandler = new ResponceHandler();
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        jsonObejcts = new JSONObjects();
        Auditing auditing = new Auditing();
        String auditType = "INSERT";
        String related_table = "gcsm_point_detail_status";
        String record_pk = "";
        String old_value = "##Empty##";
        try {
            String pointCalculationRecordAvailable = "SELECT * FROM gcsm_point_detail_status where year_month_from=? and year_month_to=?";
            if (!databaseConnection.start_Connection(currentConnection)) {

                responceHandler.setResponceModule("initiatePointCalculationStatus");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("00001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection establishing problem.");

                log.error("Uh oh! An error occurred, database connection establishing problem.");
                throw new Exception("An error occurred, database connection establishing problem.");
            }

            preparedStatement = currentConnection.prepareStatement(pointCalculationRecordAvailable);
            preparedStatement.setString(1, jasonobj.getString("year_month_from"));
            preparedStatement.setString(2, jasonobj.getString("year_month_to"));
            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {

                responceHandler.setResponceModule("initiatePointCalculationStatus");
                responceHandler.setResponceType("AlreadyCalculated");
                responceHandler.setResponceCode("0000");
                responceHandler.setResponceDescription("AlreadyCalculated");

            } else {
                 //Audit Trail        

                String pointsInitialConfigureQuery
                        = "INSERT INTO gcsm_point_detail_status ("
                        + "calculation_status, " //1
                        + "year_month_from, " //2
                        + "year_month_to) " //15
                        + "values (?,?,?)";

                preparedStatement = currentConnection.prepareStatement(pointsInitialConfigureQuery, Statement.RETURN_GENERATED_KEYS);
                preparedStatement.setInt(1, 1);
                preparedStatement.setString(2, jasonobj.getString("year_month_from"));
                preparedStatement.setString(3, jasonobj.getString("year_month_to"));

                if (preparedStatement.executeUpdate() <= 0) {

                    responceHandler.setResponceModule("initiatePointCalculationStatus");
                    responceHandler.setResponceType("error");
                    responceHandler.setResponceCode("0001");
                    responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");

                }

                responceHandler.setResponceModule("initiatePointCalculationStatus");
                responceHandler.setResponceType("success");
                responceHandler.setResponceCode("0000");
                responceHandler.setResponceDescription("Awesome! You were successful.");

                //Audit Trail
                resultSet = preparedStatement.getGeneratedKeys();
                resultSet.next();
                record_pk = "" + (resultSet.getInt(1));

            }

            if (!databaseConnection.end_Connection(currentConnection)) {

                responceHandler.setResponceModule("modifyPointCalculationStatus");
                responceHandler.setResponceType("error");;
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("Uh oh! An error occurred, database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }

            //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            auditing.saveAuditRecord(jasonobj.getString("user_username"), related_table, auditType, record_pk, old_value, new_value);

        } catch (SQLException ex) {
            ex.printStackTrace();

        } catch (Exception ex) {
            ex.printStackTrace();    
        }

        return responceHandler;
    }

    private String[] getCurrentYearMonthDetails() {
        String[] currentYearMonthDetails = new String[2];
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {

            String sql = "select * from gcsm_point_detail_status where calculation_status=1 order by point_detail_status_id desc limit 1";

            preparedStatement = currentConnection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                currentYearMonthDetails[0] = resultSet.getString("year_month_from");
                currentYearMonthDetails[1] = resultSet.getString("year_month_to");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return currentYearMonthDetails;
    }

    @Override
    public void updatePointsCalculationStatus(int status,String session_user) {

        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        preparedStatement = null;
        resultSet = null;
        
         //Audit Trail
        Auditing auditing = new Auditing();
        String auditType = "UPDATE";
        String related_table = "gcsm_point_detail_status";
        String record_pk = "";
        String old_value = "";
        
        int latestStatusID=getLatestPointDetailsStatusID();

        try {

            if (!databaseConnection.start_Connection(currentConnection)) {

            } else {
                System.out.println("#######################"+status);
                String sql = "update gcsm_point_detail_status "
                        + "set calculation_status=? where point_detail_status_id=?";

                preparedStatement = currentConnection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                preparedStatement.setInt(1, status);      
                preparedStatement.setInt(2, latestStatusID);  
                    
                int executeUpdate = preparedStatement.executeUpdate();
                System.out.println("executeupdate : " + executeUpdate);
                resultSet = preparedStatement.getGeneratedKeys();
            }

            
                //Audit Trail 
                record_pk = "" + latestStatusID;
                old_value = auditing.getAllRecords(record_pk, related_table).toString();
            

            if (!databaseConnection.end_Connection(currentConnection)) {
                log.error("Uh oh! An error occurred, database connection terminating problem.");
            }
            
             //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            auditing.saveAuditRecord(session_user, related_table, auditType, record_pk, old_value, new_value);

        } catch (Exception e) {
            e.printStackTrace();

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }
    
    private int getLatestPointDetailsStatusID() {
        int statusID=0;
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {

            String sql = "select point_detail_status_id from gcsm_point_detail_status ORDER BY point_detail_status_id DESC LIMIT 1";

            preparedStatement = currentConnection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                statusID = resultSet.getInt("point_detail_status_id");
            }

        } catch (Exception e) {
            e.printStackTrace();

        }
        return statusID;
    }

    @Override
    public JSONArray checkInitiationStatus(JSONObject jasonobj) {
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();
        try {
            String queryInitiationStatusCheck = "SELECT calculation_status FROM gcsm_point_detail_status order by point_detail_status_id desc limit 1";

            log.info(queryInitiationStatusCheck);

            preparedStatement = currentConnection.prepareStatement(queryInitiationStatusCheck);
            resultSet = preparedStatement.executeQuery();
            int i = 0;
            while (resultSet.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("calculation_status", resultSet.getInt("calculation_status"));
                jsArr.put(i, m_jsObj);
                i++;

            }
            //If no reward calculation initiated
            if (i == 0) {
                m_jsObj = new JSONObject();
                m_jsObj.put("calculation_status", 0);
                jsArr.put(i, m_jsObj);
            }

        } catch (Exception e) {
            e.printStackTrace();

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {

                responceHandler.setResponceModule("View_RewardValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return jsArr;
    }

    @Override
    public ResponceHandler verifyPointsDetails(JSONObject jasonobj, int approveReject) {
        responceHandler = new ResponceHandler();
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        jsonObejcts = new JSONObjects();
        
        //Audit Trail
        Auditing auditing = new Auditing();
        String auditType = "UPDATE";
        String related_table = "gcsm_point_details";
        String record_pk = "";
        String old_value = "";

        try {
            if (!databaseConnection.start_Connection(currentConnection)) {

            } else {
                
                //Audit Trail 
                record_pk = "" + jasonobj.getString("point_detail_id").trim();
                old_value = auditing.getAllRecords(record_pk, related_table).toString();
                
                String pointValuesVerifyQuery
                        = "UPDATE gcsm_point_details "
                        + "set point_detail_status=" + approveReject + ", "
                        + "approved_user=?,"//1
                        + "approval_comment=?, " //2
                        + "approved_timestamp=now() "
                        + "where point_detail_id=?";              //3

                preparedStatement = currentConnection.prepareStatement(pointValuesVerifyQuery,Statement.RETURN_GENERATED_KEYS);
                preparedStatement.setString(1, jasonobj.get("user_username").toString());
                preparedStatement.setString(2, jasonobj.get("approval_comment").toString());
                preparedStatement.setInt(3, Integer.parseInt(jasonobj.getString("point_detail_id").trim()));
                System.out.println(preparedStatement);
                if (preparedStatement.executeUpdate() <= 0) {

                    responceHandler.setResponceModule("verify_Points_Details");
                    responceHandler.setResponceType("error");
                    responceHandler.setResponceCode("0001");
                    responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");

                }                              

                responceHandler.setResponceModule("verify_Points_Details");
                responceHandler.setResponceType("success");
                responceHandler.setResponceCode("0000");
                responceHandler.setResponceDescription((approveReject == 1) ? "Succefully Approved" : "Successfully Rejected");
            }
            if (!databaseConnection.end_Connection(currentConnection)) {

                responceHandler.setResponceModule("verify_Points_Details");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("Uh oh! An error occurred, database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }
            
              //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            auditing.saveAuditRecord(jasonobj.get("user_username").toString(), related_table, auditType, record_pk, old_value, new_value);


        } catch (SQLException ex) {
            ex.printStackTrace();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {

            try {
                if (isAllPointsApproved()) {
                    updatePointsCalculationStatus(2,jasonobj.getString("user_username"));
                }

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

                
            } catch (Exception e) {

                responceHandler.setResponceModule("verify_Reward_Details");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");
            }

        }

        return responceHandler;
    }

    private boolean isAllPointsApproved() {
        boolean flag = false;

        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {
            if (!databaseConnection.start_Connection(currentConnection)) {

            } else {
                String sql = "select count(*) as pendingApprovalCount from gcsm_point_details where point_detail_status=0";

                preparedStatement = currentConnection.prepareStatement(sql);

                resultSet = preparedStatement.executeQuery();

                while (resultSet.next()) {
                    flag = resultSet.getInt("pendingApprovalCount") == 0;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return flag;
    }

}
