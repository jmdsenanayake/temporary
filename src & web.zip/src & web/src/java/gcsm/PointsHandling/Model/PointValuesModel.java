/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.PointsHandling.Model;

/**
 *
 * @author Janaka_5977
 */
public class PointValuesModel {
    private int point_value_id;
    private double point_A_upper_value;
    private double point_A_lower_value;
    private double point_B_upper_value;
    private double point_B_lower_value;
    private double point_C_upper_value;
    private double point_C_lower_value;
    private double point_D_upper_value;
    private double point_D_lower_value;
    private int point_value_status;
    private String point_value_approve_reject_comment;

    /**
     * @return the point_value_id
     */
    public int getPoint_value_id() {
        return point_value_id;
    }

    /**
     * @param point_value_id the point_value_id to set
     */
    public void setPoint_value_id(int point_value_id) {
        this.point_value_id = point_value_id;
    }

    /**
     * @return the point_A_upper_value
     */
    public double getPoint_A_upper_value() {
        return point_A_upper_value;
    }

    /**
     * @param point_A_upper_value the point_A_upper_value to set
     */
    public void setPoint_A_upper_value(double point_A_upper_value) {
        this.point_A_upper_value = point_A_upper_value;
    }

    /**
     * @return the point_A_lower_value
     */
    public double getPoint_A_lower_value() {
        return point_A_lower_value;
    }

    /**
     * @param point_A_lower_value the point_A_lower_value to set
     */
    public void setPoint_A_lower_value(double point_A_lower_value) {
        this.point_A_lower_value = point_A_lower_value;
    }

    /**
     * @return the point_B_upper_value
     */
    public double getPoint_B_upper_value() {
        return point_B_upper_value;
    }

    /**
     * @param point_B_upper_value the point_B_upper_value to set
     */
    public void setPoint_B_upper_value(double point_B_upper_value) {
        this.point_B_upper_value = point_B_upper_value;
    }

    /**
     * @return the point_B_lower_value
     */
    public double getPoint_B_lower_value() {
        return point_B_lower_value;
    }

    /**
     * @param point_B_lower_value the point_B_lower_value to set
     */
    public void setPoint_B_lower_value(double point_B_lower_value) {
        this.point_B_lower_value = point_B_lower_value;
    }

    /**
     * @return the point_C_upper_value
     */
    public double getPoint_C_upper_value() {
        return point_C_upper_value;
    }

    /**
     * @param point_C_upper_value the point_C_upper_value to set
     */
    public void setPoint_C_upper_value(double point_C_upper_value) {
        this.point_C_upper_value = point_C_upper_value;
    }

    /**
     * @return the point_C_lower_value
     */
    public double getPoint_C_lower_value() {
        return point_C_lower_value;
    }

    /**
     * @param point_C_lower_value the point_C_lower_value to set
     */
    public void setPoint_C_lower_value(double point_C_lower_value) {
        this.point_C_lower_value = point_C_lower_value;
    }

    /**
     * @return the point_D_upper_value
     */
    public double getPoint_D_upper_value() {
        return point_D_upper_value;
    }

    /**
     * @param point_D_upper_value the point_D_upper_value to set
     */
    public void setPoint_D_upper_value(double point_D_upper_value) {
        this.point_D_upper_value = point_D_upper_value;
    }

    /**
     * @return the point_D_lower_value
     */
    public double getPoint_D_lower_value() {
        return point_D_lower_value;
    }

    /**
     * @param point_D_lower_value the point_D_lower_value to set
     */
    public void setPoint_D_lower_value(double point_D_lower_value) {
        this.point_D_lower_value = point_D_lower_value;
    }

    /**
     * @return the point_value_status
     */
    public int getPoint_value_status() {
        return point_value_status;
    }

    /**
     * @param point_value_status the point_value_status to set
     */
    public void setPoint_value_status(int point_value_status) {
        this.point_value_status = point_value_status;
    }

    /**
     * @return the point_value_approve_reject_comment
     */
    public String getPoint_value_approve_reject_comment() {
        return point_value_approve_reject_comment;
    }

    /**
     * @param point_value_approve_reject_comment the point_value_approve_reject_comment to set
     */
    public void setPoint_value_approve_reject_comment(String point_value_approve_reject_comment) {
        this.point_value_approve_reject_comment = point_value_approve_reject_comment;
    }
}
