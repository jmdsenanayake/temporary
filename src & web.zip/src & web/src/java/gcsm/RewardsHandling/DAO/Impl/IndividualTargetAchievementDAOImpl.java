/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.RewardsHandling.DAO.Impl;

import gcsm.RewardsHandling.DAO.IndividualTargetAchievementDAO;
import gcsm.RewardsHandling.Model.IndividualTargetAchievementModel;
import gcsm.Utitlities.Impl.Auditing;
import gcsm.Utitlities.Impl.DatabaseConnection;
import gcsm.Utitlities.Impl.JSONObjects;
import gcsm.Utitlities.Model.ResponceHandler;
import gcsm.Utitlities.Model.RoleTypes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Janaka_5977
 */
public class IndividualTargetAchievementDAOImpl implements IndividualTargetAchievementDAO {

    static Logger log = LogManager.getLogger(IndividualTargetAchievementDAOImpl.class.getName());
    private ResponceHandler responceHandler;
    static DatabaseConnection databaseConnection;
    static Connection currentConnection = null;
    private PreparedStatement preparedStatement = null;
    private ResultSet resultSet = null;
    private JSONObjects jsonObejcts;
    private JSONArray jsArr;

    @Override
    public JSONArray viewAchievementValues(JSONObject jasonobj) {
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        String roleType = jasonobj.get("session_role_type").toString();
        String username = jasonobj.get("user_username").toString();
        jsArr = new JSONArray();
        try {
            String queryViewIndividualTargertQuery = "";
            if (roleType.equals(RoleTypes.INPUTER)) {
                queryViewIndividualTargertQuery = "select achievement_id, asset_achievement, liabilities_achievement, cs_asset_achievement, cs_liabilities_achievement, period_from_yearmonth, period_to_yearmonth, target_achivement_status, related_to, setup_user, setup_time, ifnull(approved_rejected_user,'--') as approved_rejected_user, ifnull(approved_rejected_time,'--') as approved_rejected_time, ifnull(approval_reject_comment,'--') as approval_reject_comment from gcsm_individual_target_achievements where setup_user='" + username + "' order by setup_time desc";
            } else if (roleType.equals(RoleTypes.AUTHORIZER)) {
                queryViewIndividualTargertQuery = "select achievement_id, asset_achievement, liabilities_achievement, cs_asset_achievement, cs_liabilities_achievement, period_from_yearmonth, period_to_yearmonth, target_achivement_status, related_to, setup_user, setup_time, ifnull(approved_rejected_user,'--') as approved_rejected_user, ifnull(approved_rejected_time,'--') as approved_rejected_time, ifnull(approval_reject_comment,'--') as approval_reject_comment from gcsm_individual_target_achievements where setup_user in (select user_username from gcsm_user where user_businessline in (select user_businessline from gcsm_user where user_username='" + username + "')) order by setup_time desc";
            } else if (roleType.equals(RoleTypes.FINANCE_ADMINISTRATOR)) {
                queryViewIndividualTargertQuery = "select achievement_id, asset_achievement, liabilities_achievement, cs_asset_achievement, cs_liabilities_achievement, period_from_yearmonth, period_to_yearmonth, target_achivement_status, related_to, setup_user, setup_time, ifnull(approved_rejected_user,'--') as approved_rejected_user, ifnull(approved_rejected_time,'--') as approved_rejected_time, ifnull(approval_reject_comment,'--') as approval_reject_comment from gcsm_individual_target_achievements order by setup_time desc";
            } 
            log.info(queryViewIndividualTargertQuery);

            preparedStatement = currentConnection.prepareStatement(queryViewIndividualTargertQuery);
            resultSet = preparedStatement.executeQuery();
            int i = 0;
            while (resultSet.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("achievement_id", resultSet.getInt("achievement_id"));
                m_jsObj.put("asset_achievement", resultSet.getString("asset_achievement"));
                m_jsObj.put("liabilities_achievement", resultSet.getString("liabilities_achievement"));
                m_jsObj.put("cs_asset_achievement", resultSet.getString("cs_asset_achievement"));
                m_jsObj.put("cs_liabilities_achievement", resultSet.getString("cs_liabilities_achievement"));
                m_jsObj.put("period_from_yearmonth", resultSet.getString("period_from_yearmonth"));
                m_jsObj.put("period_to_yearmonth", resultSet.getString("period_to_yearmonth"));
                m_jsObj.put("target_achivement_status", resultSet.getString("target_achivement_status"));
                m_jsObj.put("related_to", resultSet.getString("related_to"));
                m_jsObj.put("setup_user", resultSet.getString("setup_user"));
                m_jsObj.put("setup_time", resultSet.getString("setup_time"));
                m_jsObj.put("approved_rejected_user", resultSet.getString("approved_rejected_user"));
                m_jsObj.put("approved_rejected_time", resultSet.getString("approved_rejected_time"));
                m_jsObj.put("approval_reject_comment", resultSet.getString("approval_reject_comment"));
                jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {
            e.printStackTrace();

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {

                responceHandler.setResponceModule("View_RewardValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return jsArr;
    }

    @Override
    public ResponceHandler insertAchievementValues(JSONObject jasonobj) {
        responceHandler = new ResponceHandler();
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        jsonObejcts = new JSONObjects();
        IndividualTargetAchievementModel individualTargetAchievementModel;
        double csShadowTotalForAssets = 0;
        double csShadowTotalForLiabilities = 0;

        //Audit Trail        
        Auditing auditing = new Auditing();
        String auditType = "INSERT";
        String related_table = "gcsm_individual_target_achievements";
        String record_pk = "";
        String old_value = "##Empty##";

        try {
            individualTargetAchievementModel = jsonObejcts.convertIndividualTargetAchievementModelToJSON(jasonobj.toString());
            csShadowTotalForAssets = calculateCSAchievementValues("Asset", individualTargetAchievementModel.getPeriod_from_yearmonth(), individualTargetAchievementModel.getPeriod_to_yearmonth());
            csShadowTotalForLiabilities = calculateCSAchievementValues("Liability", individualTargetAchievementModel.getPeriod_from_yearmonth(), individualTargetAchievementModel.getPeriod_to_yearmonth());
            individualTargetAchievementModel.setCs_asset_achievement(csShadowTotalForAssets);
            individualTargetAchievementModel.setCs_liabilities_achievement(csShadowTotalForLiabilities);

            String insertIndividualTargetQuery
                    = "INSERT INTO gcsm_individual_target_achievements ("
                    + "asset_achievement, " //1
                    + "liabilities_achievement, " //2
                    + "cs_asset_achievement, " //3
                    + "cs_liabilities_achievement, " //4
                    + "period_from_yearmonth, " //5
                    + "period_to_yearmonth," //6
                    + "target_achivement_status, " //7
                    + "related_to," //8
                    + "setup_user," //9
                    + "setup_time) "
                    + "values (?,?,?,?,?,?,?,?,?,now())";

            preparedStatement = currentConnection.prepareStatement(insertIndividualTargetQuery, Statement.RETURN_GENERATED_KEYS);
            preparedStatement.setDouble(1, individualTargetAchievementModel.getAsset_achievement());
            preparedStatement.setDouble(2, individualTargetAchievementModel.getLiabilities_achievement());
            preparedStatement.setDouble(3, individualTargetAchievementModel.getCs_asset_achievement());
            preparedStatement.setDouble(4, individualTargetAchievementModel.getCs_liabilities_achievement());
            preparedStatement.setString(5, individualTargetAchievementModel.getPeriod_from_yearmonth());
            preparedStatement.setString(6, individualTargetAchievementModel.getPeriod_to_yearmonth());
            preparedStatement.setInt(7, 0);
            preparedStatement.setString(8, individualTargetAchievementModel.getRelated_to());
            preparedStatement.setString(9, jasonobj.get("user_username").toString());

            if (preparedStatement.executeUpdate() <= 0) {

                responceHandler.setResponceModule("insertPointValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");

            }

            responceHandler.setResponceModule("insertPointValues");
            responceHandler.setResponceType("success");
            responceHandler.setResponceCode("0000");
            responceHandler.setResponceDescription("Awesome! You were successful.");

            //Audit Trail
            resultSet = preparedStatement.getGeneratedKeys();
            resultSet.next();
            record_pk = "" + (resultSet.getInt(1));

            if (!databaseConnection.end_Connection(currentConnection)) {

                responceHandler.setResponceModule("insertPointValues");
                responceHandler.setResponceType("error");;
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("Uh oh! An error occurred, database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }

            //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            auditing.saveAuditRecord(jasonobj.get("user_username").toString(), related_table, auditType, record_pk, old_value, new_value);

        } catch (SQLException ex) {
            ex.printStackTrace();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {

                responceHandler.setResponceModule("insertPointValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert Point Value");

            }

        }

        return responceHandler;

    }

    @Override
    public ResponceHandler verifyAchievementValues(JSONObject jasonobj, int approveReject) {
        responceHandler = new ResponceHandler();
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        jsonObejcts = new JSONObjects();
        IndividualTargetAchievementModel individualTargetAchievementModel;

        //Audit Trail
        Auditing auditing = new Auditing();
        String auditType = "UPDATE";
        String related_table = "gcsm_individual_target_achievements";
        String record_pk = "";
        String old_value = "";

        try {
            individualTargetAchievementModel = jsonObejcts.convertIndividualTargetAchievementModelToJSON(jasonobj.toString());
            String pointValuesVerifyQuery
                    = "UPDATE gcsm_individual_target_achievements "
                    + "set target_achivement_status=" + approveReject + ", "
                    + "approval_reject_comment=?, " //1
                    + "approved_rejected_user=?, " //2
                    + "approved_rejected_time=now() "
                    + "where achievement_id=?";              //3

            preparedStatement = currentConnection.prepareStatement(pointValuesVerifyQuery);
            preparedStatement.setString(1, individualTargetAchievementModel.getApproval_reject_comment());
            preparedStatement.setString(2, jasonobj.get("user_username").toString());
            preparedStatement.setInt(3, individualTargetAchievementModel.getAchievement_id());

            //Audit Trail 
            record_pk = "" + individualTargetAchievementModel.getAchievement_id();
            old_value = auditing.getAllRecords(record_pk, related_table).toString();

            if (preparedStatement.executeUpdate() <= 0) {

                responceHandler.setResponceModule("verify_Point_Values_Details");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");

            }

            responceHandler.setResponceModule("verify_Point_Values_Details");
            responceHandler.setResponceType("success");
            responceHandler.setResponceCode("0000");
            responceHandler.setResponceDescription((approveReject == 1) ? "Succefully Approved" : "Successfully Rejected");

            if (!databaseConnection.end_Connection(currentConnection)) {

                responceHandler.setResponceModule("verify_Point_Values_Details");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("Uh oh! An error occurred, database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }

            //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            auditing.saveAuditRecord(jasonobj.get("user_username").toString(), related_table, auditType, record_pk, old_value, new_value);

        } catch (SQLException ex) {
            ex.printStackTrace();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {

                responceHandler.setResponceModule("verify_Point_Values_Details");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return responceHandler;
    }

    private double calculateCSAchievementValues(String product_type, String periodFrom, String periodTo) {
        double crossSellingAchievementValue = 0;

        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        preparedStatement = null;
        resultSet = null;
        try {

            String sql = "select sum(shadow_revenue_value) as Total_Shadow_Income from gcsm_shadow_revenue,gcsm_cross_selling_details,gcsm_product where shadow_cs_contract_no = cs_contract_no and cs_product=product_id and product_type=? and shadow_year_month between ? and ?";

            preparedStatement = currentConnection.prepareStatement(sql);
            preparedStatement.setString(1, product_type);
            preparedStatement.setString(2, periodFrom.replace("-", ""));
            preparedStatement.setString(3, periodTo.replace("-", ""));
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                crossSellingAchievementValue = Double.parseDouble(String.format("%.2f", resultSet.getDouble("Total_Shadow_Income")));
            }

        } catch (Exception e) {
            e.printStackTrace();

        }

        return crossSellingAchievementValue;
    }

    @Override
    public JSONArray viewAchievementValuesForSelected(JSONObject jasonobj) {
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();
        try {
            String queryViewIndividualTargertQueryForSelected = "select * from gcsm_individual_target_achievements where achievement_id=" + jasonobj.getString("achievement_id");

            log.info(queryViewIndividualTargertQueryForSelected);

            preparedStatement = currentConnection.prepareStatement(queryViewIndividualTargertQueryForSelected);
            resultSet = preparedStatement.executeQuery();
            int i = 0;
            while (resultSet.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("achievement_id", resultSet.getInt("achievement_id"));
                m_jsObj.put("asset_achievement", resultSet.getString("asset_achievement"));
                m_jsObj.put("liabilities_achievement", resultSet.getString("liabilities_achievement"));
                m_jsObj.put("cs_asset_achievement", resultSet.getString("cs_asset_achievement"));
                m_jsObj.put("cs_liabilities_achievement", resultSet.getString("cs_liabilities_achievement"));
                m_jsObj.put("period_from_yearmonth", resultSet.getString("period_from_yearmonth"));
                m_jsObj.put("period_to_yearmonth", resultSet.getString("period_to_yearmonth"));
                m_jsObj.put("target_achivement_status", resultSet.getString("target_achivement_status"));
                m_jsObj.put("related_to", resultSet.getString("related_to"));
                m_jsObj.put("setup_user", resultSet.getString("setup_user"));
                m_jsObj.put("setup_time", resultSet.getString("setup_time"));
                m_jsObj.put("approved_rejected_user", resultSet.getString("approved_rejected_user"));
                m_jsObj.put("approved_rejected_time", resultSet.getString("approved_rejected_time"));
                m_jsObj.put("approval_reject_comment", resultSet.getString("approval_reject_comment"));
                jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {
            e.printStackTrace();

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {

                responceHandler.setResponceModule("View_RewardValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return jsArr;
    }

    @Override
    public ResponceHandler modifyAchievementValues(JSONObject jasonobj) {
        responceHandler = new ResponceHandler();
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        jsonObejcts = new JSONObjects();
        IndividualTargetAchievementModel individualTargetAchievementModel;

        //Audit Trail
        Auditing auditing = new Auditing();
        String auditType = "UPDATE";
        String related_table = "gcsm_individual_target_achievements";
        String record_pk = "";
        String old_value = "";

        try {
            individualTargetAchievementModel = jsonObejcts.convertIndividualTargetAchievementModelToJSON(jasonobj.toString());

            individualTargetAchievementModel.setCs_asset_achievement(calculateCSAchievementValues("Asset", individualTargetAchievementModel.getPeriod_from_yearmonth(), individualTargetAchievementModel.getPeriod_to_yearmonth()));
            individualTargetAchievementModel.setCs_liabilities_achievement(calculateCSAchievementValues("Liability", individualTargetAchievementModel.getPeriod_from_yearmonth(), individualTargetAchievementModel.getPeriod_to_yearmonth()));
            String individualTargetAchievementQuery
                    = "UPDATE gcsm_individual_target_achievements "
                    + "set asset_achievement=?, " //1
                    + "liabilities_achievement=?, " //2
                    + "cs_asset_achievement=?, " //3
                    + "cs_liabilities_achievement=?, " //4                    
                    + "setup_user=?, " //5
                    + "related_to=?, " //6
                    + "setup_time=now() "
                    + "where achievement_id=?";     //7

            preparedStatement = currentConnection.prepareStatement(individualTargetAchievementQuery);
            preparedStatement.setDouble(1, individualTargetAchievementModel.getAsset_achievement());
            preparedStatement.setDouble(2, individualTargetAchievementModel.getLiabilities_achievement());
            preparedStatement.setDouble(3, individualTargetAchievementModel.getCs_asset_achievement());
            preparedStatement.setDouble(4, individualTargetAchievementModel.getCs_liabilities_achievement());
            preparedStatement.setString(5, jasonobj.get("user_username").toString());
            preparedStatement.setString(6, individualTargetAchievementModel.getRelated_to());
            preparedStatement.setInt(7, individualTargetAchievementModel.getAchievement_id());

            //Audit Trail 
            record_pk = "" + individualTargetAchievementModel.getAchievement_id();
            old_value = auditing.getAllRecords(record_pk, related_table).toString();

            if (preparedStatement.executeUpdate() <= 0) {

                responceHandler.setResponceModule("modifyAchievementValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");

            }

            responceHandler.setResponceModule("modifyAchievementValues");
            responceHandler.setResponceType("success");
            responceHandler.setResponceCode("0000");
            responceHandler.setResponceDescription("Successfully Modified");

            if (!databaseConnection.end_Connection(currentConnection)) {

                responceHandler.setResponceModule("modifyAchievementValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("Uh oh! An error occurred, database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }

            //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            auditing.saveAuditRecord(jasonobj.get("user_username").toString(), related_table, auditType, record_pk, old_value, new_value);

        } catch (SQLException ex) {
            ex.printStackTrace();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {

                responceHandler.setResponceModule("verify_Point_Values_Details");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return responceHandler;
    }

    @Override
    public JSONArray getCSPerfomedUsers(JSONObject data) {
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();
        try {
            String queryGetCSPerfomedUsers = "";
            if (data.getString("actionType").equals("insert")) {
                queryGetCSPerfomedUsers = "select cs_emp_id as performed_user from gcsm_cross_selling_details where cs_emp_id!=''  and cs_emp_id not in (select related_to from gcsm_individual_target_achievements where target_achivement_status=0) union select cs_units_sold_by as performed_user from gcsm_cross_selling_details where cs_units_sold_by!=''  and cs_units_sold_by not in (select related_to from gcsm_individual_target_achievements where target_achivement_status=0)";
            } else if (data.getString("actionType").equals("modify")) {
                queryGetCSPerfomedUsers = "select cs_emp_id as performed_user from gcsm_cross_selling_details where cs_emp_id!='' union select cs_units_sold_by as performed_user from gcsm_cross_selling_details where cs_units_sold_by!=''";
            }

            log.info(queryGetCSPerfomedUsers);

            preparedStatement = currentConnection.prepareStatement(queryGetCSPerfomedUsers);
            resultSet = preparedStatement.executeQuery();
            int i = 0;
            while (resultSet.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("performed_user", resultSet.getString("performed_user"));
                jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {
            e.printStackTrace();

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {

                responceHandler.setResponceModule("getCSPerfomedUsers");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return jsArr;
    }

}
