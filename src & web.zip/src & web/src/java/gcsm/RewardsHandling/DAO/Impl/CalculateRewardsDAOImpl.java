/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.RewardsHandling.DAO.Impl;

import gcsm.RewardsHandling.DAO.CalculateRewardsDAO;
import gcsm.Utitlities.Impl.Auditing;
import gcsm.Utitlities.Impl.DatabaseConnection;
import gcsm.Utitlities.Impl.JSONObjects;
import gcsm.Utitlities.Impl.SQLServerDatabaseConnection;
import gcsm.Utitlities.Model.ResponceHandler;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Janaka_5977
 */
public class CalculateRewardsDAOImpl implements CalculateRewardsDAO {

    static Logger log = LogManager.getLogger(CalculateRewardsDAOImpl.class.getName());
    private ResponceHandler responceHandler;
    static DatabaseConnection databaseConnection;
    static Connection currentConnection = null;
    private PreparedStatement preparedStatement = null;
    private ResultSet resultSet = null;
    private JSONObjects jsonObejcts;
    private JSONArray jsArr;  

    @Override
    public JSONArray checkInitiationStatus(JSONObject jasonobj) {
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();
        try {
            String queryInitiationStatusCheck = "SELECT status,period_from_yearmonth,period_to_yearmonth FROM gcsm_reward_calculation_status order by status_id desc limit 1";

            log.info(queryInitiationStatusCheck);

            preparedStatement = currentConnection.prepareStatement(queryInitiationStatusCheck);
            resultSet = preparedStatement.executeQuery();
            int i = 0;
            while (resultSet.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("intiation_status", resultSet.getInt("status"));
                m_jsObj.put("period_from_yearmonth", resultSet.getString("period_from_yearmonth"));
                m_jsObj.put("period_to_yearmonth", resultSet.getString("period_to_yearmonth"));
                jsArr.put(i, m_jsObj);
                i++;

            }
            //If no reward calculation initiated
            if (i == 0) {
                m_jsObj = new JSONObject();
                m_jsObj.put("intiation_status", 0);
                jsArr.put(i, m_jsObj);
            }

        } catch (Exception e) {
            e.printStackTrace();

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {

                responceHandler.setResponceModule("View_RewardValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return jsArr;
    }

    @Override
    public JSONArray getCalculatedRewardValues(JSONObject jasonobj) {
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();
        try {
            String queryToGetRewardDetails = "SELECT * FROM gcsm_reward_details order by reward_setup_timestamp desc";

            preparedStatement = currentConnection.prepareStatement(queryToGetRewardDetails);
            resultSet = preparedStatement.executeQuery();
            int i = 0;
            while (resultSet.next()) {
                m_jsObj = new JSONObject();
                m_jsObj.put("reward_detail_id", resultSet.getInt("reward_detail_id"));
                m_jsObj.put("reward_related_user", resultSet.getString("reward_related_user"));
                m_jsObj.put("reward_contract_no", resultSet.getString("reward_contract_no"));
                m_jsObj.put("total_reward_amount", resultSet.getDouble("total_reward_amount"));
                m_jsObj.put("reward_yearmonth_from", resultSet.getString("reward_yearmonth_from"));
                m_jsObj.put("reward_yearmonth_to", resultSet.getString("reward_yearmonth_to"));
                m_jsObj.put("reward_setup_timestamp", resultSet.getString("reward_setup_timestamp"));
                m_jsObj.put("reward_approval_status", resultSet.getString("reward_approval_status"));
                jsArr.put(i, m_jsObj);
                i++;
            }
        } catch (Exception e) {
            e.printStackTrace();

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {

                responceHandler.setResponceModule("View_RewardValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return jsArr;
    }

    @Override
    public void startRewardCalculation(JSONObject jasonobj) {
        String fromYearMonth = jasonobj.getString("fromYearMonth");
        String toYearMonth = jasonobj.getString("toYearMonth");
        calculateRewardAmount(fromYearMonth, toYearMonth);
    }

    private List getPerformedContractNosForTargetAchievedUsers(String yearMonthFrom,String yearMonthTo) {
        List contractNos = new ArrayList<String>();
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {

            String sql = "select cs_contract_no from gcsm_cross_selling_details where cs_emp_id in (select related_to from gcsm_individual_target_achievements where target_achivement_status=1 and related_to!='' and period_from_yearmonth=? and period_to_yearmonth=?) or cs_units_sold_by in (select related_to from gcsm_individual_target_achievements where target_achivement_status=1 and related_to!='' and period_from_yearmonth=? and period_to_yearmonth=?)";

            preparedStatement = currentConnection.prepareStatement(sql);
            preparedStatement.setString(1, yearMonthFrom);
            preparedStatement.setString(2, yearMonthTo);
            preparedStatement.setString(3, yearMonthFrom);
            preparedStatement.setString(4, yearMonthTo);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                contractNos.add(resultSet.getString("cs_contract_no"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return contractNos;
    }

    private Map getRewardValueDetails(String contract_no) {
        Map rewardValues = new HashMap<String, String>();
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {

            String sql = "select reward_product_id, reward_level, tier1_reward_calc_method, tier1_reward_value_or_percentage, ifnull(tier2_reward_calc_method,'') as tier2_reward_calc_method, ifnull(tier2_reward_value_or_percentage,0) as tier2_reward_value_or_percentage, reward_cap_value, reward_1_year_less_method, reward_1_year_less_percentage, reward_1_2_year_method, reward_1_2_year_percentage from gcsm_reward_values where reward_product_id in (select  cs_product from gcsm_cross_selling_details where cs_contract_no=?)";

            preparedStatement = currentConnection.prepareStatement(sql);
            preparedStatement.setString(1, contract_no);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                rewardValues.put("reward_product_id", resultSet.getString("reward_product_id"));
                rewardValues.put("reward_level", resultSet.getString("reward_level"));
                rewardValues.put("tier1_reward_calc_method", resultSet.getString("tier1_reward_calc_method"));
                rewardValues.put("tier1_reward_value_or_percentage", resultSet.getString("tier1_reward_value_or_percentage"));
                rewardValues.put("tier2_reward_calc_method", resultSet.getString("tier2_reward_calc_method"));
                rewardValues.put("tier2_reward_value_or_percentage", resultSet.getString("tier2_reward_value_or_percentage"));
                rewardValues.put("reward_cap_value", resultSet.getString("reward_cap_value"));
                rewardValues.put("reward_1_year_less_method", resultSet.getString("reward_1_year_less_method"));
                rewardValues.put("reward_1_year_less_percentage", resultSet.getString("reward_1_year_less_percentage"));
                rewardValues.put("reward_1_2_year_method", resultSet.getString("reward_1_2_year_method"));
                rewardValues.put("reward_1_2_year_percentage", resultSet.getString("reward_1_2_year_percentage"));
            }

        } catch (Exception e) {
            e.printStackTrace();

        }
        return rewardValues;
    }

    private String getPerformedUser(String contractNo) {
        String username = "";
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {

            String sql = "select cs_emp_id,cs_units_sold_by from gcsm_cross_selling_details where cs_contract_no=?";

            preparedStatement = currentConnection.prepareStatement(sql);
            preparedStatement.setString(1, contractNo);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                username = resultSet.getString("cs_emp_id");
                username = username.equals("") ? resultSet.getString("cs_units_sold_by") : username;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return username;
    }

    private String getProductStatus(String contractNo) {
        String productStatus = "";
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {

            String sql = "select cs_product_status from gcsm_cross_selling_details where cs_contract_no=?";

            preparedStatement = currentConnection.prepareStatement(sql);
            preparedStatement.setString(1, contractNo);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                productStatus = resultSet.getString("cs_product_status");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return productStatus;
    }

    private double getPortfolioValue(String contractNo, String yearMonthFrom, String yearMonthTo, String type) {
        yearMonthFrom=yearMonthFrom.replace("-", "");
        yearMonthTo=yearMonthTo.replace("-", "");
        SQLServerDatabaseConnection sqlserver_databaseConnection = SQLServerDatabaseConnection.getInstance();;
        Connection sqlserver_currentConnection = sqlserver_databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        double portfolioValue = 0;
        try {
            if (!sqlserver_databaseConnection.start_Connection(sqlserver_currentConnection)) {

            } else {
                String sql = "";
                if (type.equals("AVG_6_MONTHS")) {
                    sql = "select (sum(PORT_AMT)/6) AS PORT_AMT from SEG_PROFITABILITY_MAS where CON_REF_NO=? and UP_DT_KY>=? and UP_DT_KY<=? ";
                } else if (type.equals("TOTAL")) {
                    sql = "select TOP 1 PORT_AMT from SEG_PROFITABILITY_MAS where CON_REF_NO=? and UP_DT_KY>=? and UP_DT_KY<=? and PORT_AMT!=0 order by UP_DT_KY ";
                }
                preparedStatement = sqlserver_currentConnection.prepareStatement(sql);

                preparedStatement.setString(1, contractNo);
                preparedStatement.setString(2, yearMonthFrom);
                preparedStatement.setString(3, yearMonthTo);

                resultSet = preparedStatement.executeQuery();
                while (resultSet.next()) {
                    portfolioValue = resultSet.getDouble("PORT_AMT");
                }
            }
            sqlserver_databaseConnection.end_Connection(sqlserver_currentConnection);

        } catch (Exception e) {
            e.printStackTrace();

        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (sqlserver_currentConnection != null) {
                    sqlserver_currentConnection.close();
                }
            } catch (Exception e) {
                e.printStackTrace();

            }
        }
        return portfolioValue;
    }

    private double getInitialYearRewardedAmount(String contractNo, String type) {
        //this will get the Intitial year rewarded amounth
        double initialYearRewardedAmount = 0;

        //perfom a mysql query to get all the previous year details
        double initialYearTotalRewardedAmount = 0;

        double intitalYearTier2RewardedAmount = 0;

        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {

            String sql = "select  tier2_reward_amount_for_new,total_reward_amount_for_new from gcsm_reward_details where reward_contract_no=? order by reward_approved_timestamp desc limit 1";

            preparedStatement = currentConnection.prepareStatement(sql);
            preparedStatement.setString(1, contractNo);

            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                initialYearTotalRewardedAmount = resultSet.getDouble("total_reward_amount_for_new");
                intitalYearTier2RewardedAmount = resultSet.getDouble("tier2_reward_amount_for_new");
            }

            if (type.equals("Total")) {
                initialYearRewardedAmount = initialYearTotalRewardedAmount;

            } else if (type.equals("Tier2")) {
                initialYearRewardedAmount = intitalYearTier2RewardedAmount;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return initialYearRewardedAmount;
    }

    private void calculateRewardAmount(String yearMonthFrom, String yearMonthTo) {

        List<String> contractNos = getPerformedContractNosForTargetAchievedUsers(yearMonthFrom,yearMonthTo);
        
        List<String> RewardEligibleContractNos=getRewardEligibleContractList(contractNos, yearMonthTo);
        
        contractNos.retainAll(RewardEligibleContractNos);

        for (String contractNo : contractNos) {

            double tier1RewardAmountForNew = 0;
            double tier2RewardAmountForNew = 0;

            double totalRewardAmountForNew = 0;

            double rewardAmountRenewal1YearLess = 0;
            double rewardAmountRenewal1To2Year = 0;

            double totalRewardAmountForRenewal = 0;

            double totalRewardAmount = 0;

            String perfomedUser = getPerformedUser(contractNo);

            String productStatus = getProductStatus(contractNo);
            Map rewardValueDetails = getRewardValueDetails(contractNo);

            int rewardLevel = Integer.parseInt(rewardValueDetails.get("reward_level").toString());

            String tier1RewardCalcMethod = rewardValueDetails.get("tier1_reward_calc_method").toString();
            double tier1RewardCalcValOrPercentage = Double.parseDouble(rewardValueDetails.get("tier1_reward_value_or_percentage").toString());

            String tier2RewardCalcMethod = rewardValueDetails.get("tier2_reward_calc_method").toString();
            double tier2RewardCalcValOrPercentage = Double.parseDouble(rewardValueDetails.get("tier2_reward_value_or_percentage").toString());

            double rewardCapValue = Double.parseDouble(rewardValueDetails.get("reward_cap_value").toString());

            String reward1YearLessMethod = rewardValueDetails.get("reward_1_year_less_method").toString();
            double reward1YearLessPercentage = Double.parseDouble(rewardValueDetails.get("reward_1_year_less_percentage").toString());

            String reward1to2YearMethod = rewardValueDetails.get("reward_1_2_year_method").toString();
            double reward1to2YearPercentage = Double.parseDouble(rewardValueDetails.get("reward_1_2_year_percentage").toString());

            String type = (tier1RewardCalcMethod.equals("Percentage on Average 6 Months Balance") || tier2RewardCalcMethod.equals("Percentage on Average 6 Months Balance")) ? "AVG_6_MONTHS" : "TOTAL";

            double portfolioValue = getPortfolioValue(contractNo, yearMonthFrom, yearMonthTo, type);

            if (productStatus.equalsIgnoreCase("New")) {
                //if (portfolioValue >= rewardCapValue) {   //// not using the cap value
                    if (rewardLevel == 1) {

                        switch (tier1RewardCalcMethod) {
                            case "Value":
                                tier1RewardAmountForNew = tier1RewardCalcValOrPercentage;
                                break;
                            case "Percentage on Total Value":
                                tier1RewardAmountForNew = portfolioValue * (tier1RewardCalcValOrPercentage) / 100;
                                break;
                            case "Percentage on Disbursed Value":
                                tier1RewardAmountForNew = portfolioValue * (tier1RewardCalcValOrPercentage / 100);
                                break;
                            case "Percentage on Average 6 Months Balance":
                                tier1RewardAmountForNew = portfolioValue * (tier1RewardCalcValOrPercentage / 100);
                                break;
                        }

                        totalRewardAmountForNew = tier1RewardAmountForNew;

                    } else if (rewardLevel == 2) {

                        switch (tier1RewardCalcMethod) {
                            case "Value":
                                tier1RewardAmountForNew = tier1RewardCalcValOrPercentage;
                                break;
                            case "Percentage on Total Value":
                                tier1RewardAmountForNew = portfolioValue * (tier1RewardCalcValOrPercentage / 100);
                                break;
                            case "Percentage on Disbursed Value":
                                tier1RewardAmountForNew = portfolioValue * (tier1RewardCalcValOrPercentage / 100);
                                break;
                            case "Percentage on Average 6 Months Balance":
                                tier1RewardAmountForNew = portfolioValue * (tier1RewardCalcValOrPercentage / 100);
                                break;
                        }

                        switch (tier2RewardCalcMethod) {
                            case "Value":
                                tier2RewardAmountForNew = tier2RewardCalcValOrPercentage;
                                break;
                            case "Percentage on Total Value":
                                tier2RewardAmountForNew = portfolioValue * (tier2RewardCalcValOrPercentage / 100);
                                break;
                            case "Percentage on Disbursed Value":
                                tier2RewardAmountForNew = portfolioValue * (tier2RewardCalcValOrPercentage / 100);
                                break;
                            case "Percentage on Average 6 Months Balance":
                                tier2RewardAmountForNew = portfolioValue * (tier2RewardCalcValOrPercentage / 100);
                                break;
                        }

                        totalRewardAmountForNew = tier1RewardAmountForNew + tier2RewardAmountForNew;
                    }
                //}

            } else {
                double initialYearRewardedAmount = getInitialYearRewardedAmount(contractNo, "Total");
                double initialYearTier2RewardedAmount = getInitialYearRewardedAmount(contractNo, "Tier2");
                if (productStatus.equals("Top-Up-1-Less")) {
                    switch (reward1YearLessMethod) {
                        case "Percentage over the rewarded amount at Tier II level":
                            rewardAmountRenewal1YearLess = initialYearTier2RewardedAmount * (reward1YearLessPercentage / 100);
                            break;
                        case "Percentage over the rewarded amount":
                            rewardAmountRenewal1YearLess = initialYearRewardedAmount * (reward1YearLessPercentage / 100);
                            break;
                    }
                } else if (productStatus.equals("Top-Up-1-2")) {
                    switch (reward1to2YearMethod) {
                        case "Percentage over the rewarded amount at Tier II level":
                            rewardAmountRenewal1To2Year = initialYearTier2RewardedAmount * (reward1to2YearPercentage / 100);
                            break;
                        case "Percentage over the rewarded amount":
                            rewardAmountRenewal1To2Year = initialYearRewardedAmount * (reward1to2YearPercentage / 100);
                            break;
                    }
                }

                //either rewardAmountRenewal1YearLess==0 or rewardAmountRenewal1To2Year==0
                totalRewardAmountForRenewal = rewardAmountRenewal1YearLess + rewardAmountRenewal1To2Year;

            }
            //either totalRewardAmountForNew==0 or totalRewardAmountForRenewal==0
            totalRewardAmount = totalRewardAmountForNew + totalRewardAmountForRenewal;

            Object[] rewardAmountDetails = {
                tier1RewardAmountForNew,
                tier2RewardAmountForNew,
                totalRewardAmountForNew,
                rewardAmountRenewal1YearLess,
                rewardAmountRenewal1To2Year,
                totalRewardAmountForRenewal,
                totalRewardAmount,
                perfomedUser,
                contractNo,
                yearMonthFrom,
                yearMonthTo,
                portfolioValue

            };

            storeRewardDetails(rewardAmountDetails);

        }

    }

    private boolean checkForRewardAlreadyCalculated(String contractNo, String yearMonthFrom, String yearMonthTo) {
        boolean isNotCalculated = true;

        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {

            String sql = "select count(*) as NoOfRecords from gcsm_reward_details where reward_contract_no=? and reward_yearmonth_from=? and reward_yearmonth_to=?";

            preparedStatement = currentConnection.prepareStatement(sql);
            preparedStatement.setString(1, contractNo);
            preparedStatement.setString(2, yearMonthFrom);
            preparedStatement.setString(3, yearMonthTo);

            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                if (resultSet.getInt("NoOfRecords") > 0) {
                    isNotCalculated = false;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();

        }
        return isNotCalculated;
    }

    private boolean storeRewardDetails(Object[] rewardAmountDetails) {
        boolean isStored = false;

        double tier1RewardAmountForNew = (double) rewardAmountDetails[0];
        double tier2RewardAmountForNew = (double) rewardAmountDetails[1];
        double totalRewardAmountForNew = (double) rewardAmountDetails[2];
        double rewardAmountRenewal1YearLess = (double) rewardAmountDetails[3];
        double rewardAmountRenewal1To2Year = (double) rewardAmountDetails[4];
        double totalRewardAmountForRenewal = (double) rewardAmountDetails[5];
        double totalRewardAmount = (double) rewardAmountDetails[6];
        String perfomedUser = (String) rewardAmountDetails[7];
        String contractNo = (String) rewardAmountDetails[8];
        String yearMonthFrom = (String) rewardAmountDetails[9];
        String yearMonthTo = (String) rewardAmountDetails[10];
        double portfolioValue = (double) rewardAmountDetails[11];

        if (checkForRewardAlreadyCalculated(contractNo, yearMonthFrom, yearMonthTo)) {
            databaseConnection = DatabaseConnection.getInstance();
            currentConnection = databaseConnection.get_JDBC_Connection();
            preparedStatement = null;
            resultSet = null;

            //Audit Trail        
            Auditing auditing = new Auditing();
            String auditType = "INSERT";
            String related_table = "gcsm_reward_details";
            String record_pk = "";
            String old_value = "##Empty##";

            try {

                if (!databaseConnection.start_Connection(currentConnection)) {

                } else {
                    String sql
                            = "INSERT INTO gcsm_reward_details("
                            + "reward_contract_no,"//1
                            + "portfolio_value," //2
                            + "tier1_reward_amount_for_new," //3
                            + "tier2_reward_amount_for_new," //4
                            + "total_reward_amount_for_new," //5
                            + "reward_amount_renewal1_year_less," //6
                            + "reward_amount_renewal1_to_2_year," //7
                            + "total_reward_amount_for_renewal," //8
                            + "total_reward_amount," //9
                            + "reward_related_user," //10                        
                            + "reward_yearmonth_from," //11
                            + "reward_yearmonth_to," //12
                            + "reward_setup_timestamp,"
                            + "reward_approval_status)"
                            + " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,now(),0)";

                    preparedStatement = currentConnection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                    preparedStatement.setString(1, contractNo);
                    preparedStatement.setDouble(2, portfolioValue);
                    preparedStatement.setDouble(3, tier1RewardAmountForNew);
                    preparedStatement.setDouble(4, tier2RewardAmountForNew);
                    preparedStatement.setDouble(5, totalRewardAmountForNew);
                    preparedStatement.setDouble(6, rewardAmountRenewal1YearLess);
                    preparedStatement.setDouble(7, rewardAmountRenewal1To2Year);
                    preparedStatement.setDouble(8, totalRewardAmountForRenewal);
                    preparedStatement.setDouble(9, totalRewardAmount);
                    preparedStatement.setString(10, perfomedUser);
                    preparedStatement.setString(11, yearMonthFrom);
                    preparedStatement.setString(12, yearMonthTo);
                    int executeUpdate = preparedStatement.executeUpdate();
                    System.out.println("executeupdate : " + executeUpdate);
                    resultSet = preparedStatement.getGeneratedKeys();
                }

                while (resultSet.next()) {
                    //Audit Trail
                    record_pk = "" + (resultSet.getInt(1));
                }

                if (!databaseConnection.end_Connection(currentConnection)) {

                    log.error("Uh oh! An error occurred, database connection terminating problem.");

                }

                //Audit Trail
                String new_value = auditing.getAllRecords(record_pk, related_table).toString();
                auditing.saveAuditRecord(perfomedUser, related_table, auditType, record_pk, old_value, new_value);

            } catch (Exception e) {
                e.printStackTrace();

            }
        }
        return isStored;
    }

    @Override
    public void updateRewardCalculationStatus(JSONObject jasonobj, int status) {

        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        preparedStatement = null;
        resultSet = null;

        //Audit Trail
        Auditing auditing = new Auditing();
        String auditType = "";
        String related_table = "gcsm_reward_calculation_status";
        String record_pk = "";
        String old_value = "##Empty##";

        try {
            int latestStatusID = getLatestRewardCalculationStatusID();
            if (!databaseConnection.start_Connection(currentConnection)) {

            } else {

                String sql = "";
                if (status == 0) {
                    sql = "INSERT INTO gcsm_reward_calculation_status("
                            + "status," //1
                            + "initiated_user," //2
                            + "initiated_timestamp,"
                            + "period_from_yearmonth," //3
                            + "period_to_yearmonth)" //4
                            + " VALUES(?,?,now(),?,?)";
                    //Audit Trail
                    auditType = "INSERT";

                } else if (status == 1) {
                    sql = "update gcsm_reward_calculation_status "
                            + "set status=?, calculated_user=?,calculated_timestamp=now() where status_id=" + latestStatusID + "";

                    //Audit Trail
                    auditType = "UPDATE";

                } else if (status == 2) {
                    sql = "update gcsm_reward_calculation_status "
                            + "set status=?, closed_user=?,closed_timestamp=now() where status_id=" + latestStatusID + "";

                    //Audit Trail
                    auditType = "UPDATE";

                } else if (status-- == 10) {
                    sql = "update gcsm_reward_calculation_status "
                            + "set status=? where status_id=" + latestStatusID + "";

                    //Audit Trail
                    auditType = "UPDATE";

                }

                System.out.println(sql);
                preparedStatement = currentConnection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                preparedStatement.setInt(1, status + 1);

                if (status != 9) {
                    preparedStatement.setString(2, jasonobj.getString("user_username"));
                }
                if (status == 0) {
                    preparedStatement.setString(3, jasonobj.getString("period_from_yearmonth"));
                    preparedStatement.setString(4, jasonobj.getString("period_to_yearmonth"));
                }

                int executeUpdate = preparedStatement.executeUpdate();
                System.out.println("executeupdate : " + executeUpdate);
                resultSet = preparedStatement.getGeneratedKeys();
            }

            if (resultSet.first()) {
                record_pk = "" + resultSet.getInt(1);
            } else {
                record_pk = "" + latestStatusID;
            }
            if(status!=0){
                old_value = auditing.getAllRecords(record_pk, related_table).toString();
            }

            if (!databaseConnection.end_Connection(currentConnection)) {
                log.error("Uh oh! An error occurred, database connection terminating problem.");
            }

            //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            auditing.saveAuditRecord(jasonobj.get("user_username").toString(), related_table, auditType, record_pk, old_value, new_value);

        } catch (Exception e) {
            e.printStackTrace();

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    @Override
    public ResponceHandler verifyRewardDetails(JSONObject jasonobj, int approveReject) {
        responceHandler = new ResponceHandler();
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        jsonObejcts = new JSONObjects();

        //Audit Trail
        Auditing auditing = new Auditing();
        String auditType = "UPDATE";
        String related_table = "gcsm_reward_details";
        String record_pk = "";
        String old_value = "";

        try {
            if (!databaseConnection.start_Connection(currentConnection)) {

            } else {
                String pointValuesVerifyQuery
                        = "UPDATE gcsm_reward_details "
                        + "set reward_approval_status=" + approveReject + ", "
                        + "reward_approved_user=?,"//1
                        + "reward_approval_comment=?, " //2
                        + "reward_approved_timestamp=now() "
                        + "where reward_detail_id=?";              //3

                preparedStatement = currentConnection.prepareStatement(pointValuesVerifyQuery);
                preparedStatement.setString(1, jasonobj.get("user_username").toString());
                preparedStatement.setString(2, jasonobj.get("reward_approval_comment").toString());
                preparedStatement.setInt(3, Integer.parseInt(jasonobj.getString("reward_detail_id").trim()));
                System.out.println(preparedStatement);

                //Audit Trail 
                record_pk = "" + Integer.parseInt(jasonobj.getString("reward_detail_id").trim());
                old_value = auditing.getAllRecords(record_pk, related_table).toString();

                if (preparedStatement.executeUpdate() <= 0) {

                    responceHandler.setResponceModule("verify_Reward_Details");
                    responceHandler.setResponceType("error");
                    responceHandler.setResponceCode("0001");
                    responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");

                }

                responceHandler.setResponceModule("verify_Reward_Details");
                responceHandler.setResponceType("success");
                responceHandler.setResponceCode("0000");
                responceHandler.setResponceDescription((approveReject == 1) ? "Succefully Approved" : "Successfully Rejected");
            }
            if (!databaseConnection.end_Connection(currentConnection)) {

                responceHandler.setResponceModule("verify_Reward_Details");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("Uh oh! An error occurred, database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }

            //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            auditing.saveAuditRecord(jasonobj.get("user_username").toString(), related_table, auditType, record_pk, old_value, new_value);

        } catch (SQLException ex) {
            ex.printStackTrace();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

                if (isAllRewardsApproved()) {
                    updateRewardCalculationStatus(jasonobj, 2);
                }
            } catch (Exception e) {

                responceHandler.setResponceModule("verify_Reward_Details");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");
            }

        }

        return responceHandler;
    }

    private boolean isAllRewardsApproved() {
        boolean flag = false;

        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {
            if (!databaseConnection.start_Connection(currentConnection)) {

            } else {
                String sql = "select count(*) as pendingApprovalCount from gcsm_reward_details where reward_approval_status=0";

                preparedStatement = currentConnection.prepareStatement(sql);

                resultSet = preparedStatement.executeQuery();

                while (resultSet.next()) {
                    flag = resultSet.getInt("pendingApprovalCount") == 0;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();

        }
        return flag;
    }

    @Override
    public JSONArray checkForAlreadyCalculations(JSONObject jasonobj) {
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();
        try {
            String queryToGetRewardDetailsAlreadyExist = "select count(*) as NoOfRecords from gcsm_reward_calculation_status where period_from_yearmonth=? and period_to_yearmonth=?";

            preparedStatement = currentConnection.prepareStatement(queryToGetRewardDetailsAlreadyExist);
            preparedStatement.setString(1, jasonobj.getString("yearMonthFrom"));
            preparedStatement.setString(2, jasonobj.getString("yearMonthTo"));
            resultSet = preparedStatement.executeQuery();

            int i = 0;
            while (resultSet.next()) {
                m_jsObj = new JSONObject();
                m_jsObj.put("NoOfRecords", resultSet.getInt("NoOfRecords"));
                jsArr.put(i, m_jsObj);
                i++;
            }
        } catch (Exception e) {
            e.printStackTrace();

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {

                responceHandler.setResponceModule("View_RewardValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");
            }
        }

        return jsArr;
    }

    private int getLatestRewardCalculationStatusID() {
        int statusID = 0;
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {

            String sql = "select status_id from gcsm_reward_calculation_status ORDER BY status_id DESC LIMIT 1";

            preparedStatement = currentConnection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                statusID = resultSet.getInt("status_id");
            }

        } catch (Exception e) {
            e.printStackTrace();

        }
        return statusID;
    }
    
    private double getTPRateforContract(String contractNo, String yearMonth) {        
        SQLServerDatabaseConnection sqlserver_databaseConnection = SQLServerDatabaseConnection.getInstance();;
        Connection sqlserver_currentConnection = sqlserver_databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        double TPRate = 0;
        try {
            if (!sqlserver_databaseConnection.start_Connection(sqlserver_currentConnection)) {

            } else {
                String sql = "select TP_RATE from PROFITABILITY_MAS where CON_REF_NO=? and UP_DT_KY=?";
                preparedStatement = sqlserver_currentConnection.prepareStatement(sql);
                preparedStatement.setString(1, contractNo);
                preparedStatement.setString(2, yearMonth);

                resultSet = preparedStatement.executeQuery();
                while (resultSet.next()) {
                    TPRate = resultSet.getDouble("TP_RATE");
                }
            }
            sqlserver_databaseConnection.end_Connection(sqlserver_currentConnection);

        } catch (Exception e) {
            e.printStackTrace();

        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (sqlserver_currentConnection != null) {
                    sqlserver_currentConnection.close();
                }
            } catch (Exception e) {
                e.printStackTrace();

            }

        }
        return TPRate;
    }
    
    private Object[] getALCOApprovedTPRates(String contractNo){  
        Object[] typeRate=new Object[2];
        
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {

            String sql = "select product_type,product_alco_approved_tp_rate from gcsm_product where product_id in (select cs_product from gcsm_cross_selling_details where cs_contract_no=?)";

            preparedStatement = currentConnection.prepareStatement(sql);
            preparedStatement.setString(1, contractNo);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
               typeRate[0]=resultSet.getString("product_type");
               typeRate[1]=resultSet.getDouble("product_alco_approved_tp_rate");                
            }        
            
        } catch (Exception e) {
            e.printStackTrace();

        }   
        return typeRate;
    }
    
    private List<String> getRewardEligibleContractList(List<String> contractNos,String yearMonth){
        yearMonth=yearMonth.replace("-", "");
        List<String> rewardEligibleContractList=new ArrayList<>();
        
        for(String contractNo:contractNos){
            Object[] typeRate=getALCOApprovedTPRates(contractNo);
            
            String productType=(String) typeRate[0];
            double ALCOApprovedTPRate=(Double) typeRate[1];
            
            double TPRate=getTPRateforContract(contractNo, yearMonth);
            
            if(productType.equals("Asset")){
                if(ALCOApprovedTPRate<=TPRate){
                    rewardEligibleContractList.add(contractNo);
                }
            }
            
            else if(productType.equals("Liability")){
                if(ALCOApprovedTPRate>=TPRate){
                    rewardEligibleContractList.add(contractNo);
                }
            }
        }      
        return rewardEligibleContractList;
    }     

    @Override
    public boolean checkForProductRewardValuesConfiguration() {
        boolean isAllRewardValuesConfigured=false;
        
        int allProducts=getAllProductsCount();
        
        int getConfiguredProductsCount=getRewardValuesConfiguredProductsCount();
        
        isAllRewardValuesConfigured=(allProducts==getConfiguredProductsCount);
        
        return isAllRewardValuesConfigured;      
    }
    
    private int getAllProductsCount(){
        int count=0;
        
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {

            String sql = "select count(product_id) as allProducts from gcsm_product;";

            preparedStatement = currentConnection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
               count=resultSet.getInt("allProducts");              
            }        
            
        } catch (Exception e) {
            e.printStackTrace();

        }   
        
        return count;
    }
    
    private int getRewardValuesConfiguredProductsCount(){
        int count=0;
        
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {

            String sql = "select count(reward_product_id) as rewardConfiguredCount from gcsm_reward_values where reward_value_status=2;";

            preparedStatement = currentConnection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
               count=resultSet.getInt("rewardConfiguredCount");              
            }        
            
        } catch (Exception e) {
            e.printStackTrace();

        }   
        
        return count;
    }
}
