/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.RewardsHandling.DAO;

import gcsm.Utitlities.Model.ResponceHandler;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Janaka_5977
 */
public interface IndividualTargetAchievementDAO {
    public JSONArray viewAchievementValues(JSONObject jasonobj);
     
     public ResponceHandler insertAchievementValues(JSONObject jasonobj);
     
     public ResponceHandler verifyAchievementValues(JSONObject jasonobj,int approveReject);
     
     public JSONArray viewAchievementValuesForSelected(JSONObject jasonobj);
     
     public ResponceHandler modifyAchievementValues(JSONObject jasonobj);

     public JSONArray getCSPerfomedUsers(JSONObject data);
}
