/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.RewardsHandling.DAO;

import gcsm.Utitlities.Model.ResponceHandler;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Janaka_5977
 */
public interface CalculateRewardsDAO {
     public JSONArray checkInitiationStatus(JSONObject jasonobj);    
     
     public void startRewardCalculation(JSONObject jasonobj);    
     
     public JSONArray getCalculatedRewardValues(JSONObject jasonobj);    
     
     public void updateRewardCalculationStatus(JSONObject jasonobj, int status);    
     
     public ResponceHandler verifyRewardDetails(JSONObject jasonobj, int approveReject);
     
     public JSONArray checkForAlreadyCalculations(JSONObject jasonobj);
     
     public boolean checkForProductRewardValuesConfiguration();
}
