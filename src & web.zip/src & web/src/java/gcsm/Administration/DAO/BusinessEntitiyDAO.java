/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Administration.DAO;


import gcsm.Utitlities.Model.ResponceHandler;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Randika_10992
 */
public interface BusinessEntitiyDAO {
    
    public ResponceHandler saveBusinessLine(JSONObject jasonobj);
    
    public JSONArray getTableBusinessLine(JSONObject jasonobj);
    
    public JSONArray getInfoBusinessLine(JSONObject jasonobj);  
    
    public JSONArray getOwnCompany(JSONObject jasonobj);
        
}
