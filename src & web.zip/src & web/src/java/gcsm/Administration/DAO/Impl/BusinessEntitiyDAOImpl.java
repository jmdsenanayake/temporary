/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Administration.DAO.Impl;

import gcsm.Utitlities.Impl.DatabaseConnection;
import gcsm.Administration.DAO.BusinessEntitiyDAO;
import gcsm.Utitlities.Impl.JSONObjects;
import gcsm.Administration.Model.BusinessEntityModel;
import gcsm.Utitlities.Impl.Auditing;
import gcsm.Utitlities.Model.ResponceHandler;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Randika_10992
 */
public class BusinessEntitiyDAOImpl extends DatabaseConnection implements BusinessEntitiyDAO {

    static Logger log = LogManager.getLogger(BusinessEntitiyDAOImpl.class.getName());

    static DatabaseConnection database_Connection;
    static Connection _currentCon = null;
    private Statement _statement = null;
    private PreparedStatement _prep_statement_1 = null;
    private PreparedStatement _prep_statement_2 = null;
    private ResultSet _rs = null;
    private Exception _exception;
    private ResponceHandler gcsm_responceHandler;
    private JSONObjects gcsm_Jason;
    private JSONArray _jsArr;

    @Override
    public ResponceHandler saveBusinessLine(JSONObject jasonobj) {

        String session_username = jasonobj.get("session_username").toString();

        //Audit Trail
        String auditType = "";
        Auditing auditing = new Auditing();
        String related_table = "gcsm_businessline";
        String record_pk = "";
        String old_value = "##Empty##";

        gcsm_responceHandler = new ResponceHandler();
        database_Connection = DatabaseConnection.getInstance();
        _currentCon = database_Connection.get_JDBC_Connection();
        gcsm_Jason = new JSONObjects();
        BusinessEntityModel newBusinessEntityModel;
        BusinessEntityModel renewBusinessEntityModel;
        String main_AdministrationQry;

        boolean isDataAvailabile = false;

        try {

            newBusinessEntityModel = new BusinessEntityModel();
            newBusinessEntityModel = gcsm_Jason.convertBusinessEntityModelToJSON(jasonobj.toString());
            renewBusinessEntityModel = new BusinessEntityModel();

            // check database connection problem 
            if (!start_Connection(_currentCon)) {

                gcsm_responceHandler.setResponceModule("save_BusinessLine");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("00001");
                gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, database connection establishing problem.");

                log.error("database connection establishing problem.");
                throw new Exception("An error occurred, database connection establishing problem.");

            }

            // Check Record Already Exists
            if (newBusinessEntityModel.getBl_id() == 0) {

                main_AdministrationQry = "SELECT * FROM gcsm_businessline WHERE bl_name=? AND bl_head=?";

                _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry);
                _prep_statement_1.setString(1, newBusinessEntityModel.getBl_name());
                _prep_statement_1.setString(2, newBusinessEntityModel.getBl_head());
                _rs = _prep_statement_1.executeQuery();

                if (_rs.next()) {

                    gcsm_responceHandler.setResponceModule("save_BusinessLine");
                    gcsm_responceHandler.setResponceType("error");;
                    gcsm_responceHandler.setResponceCode("00001");
                    gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, record already exists in the databse.");

                    log.error("record already exists in the databse.");
                    throw new Exception("An error occurred, record already exists in the databse.");

                }

            }

            main_AdministrationQry = "SELECT * FROM gcsm_businessline WHERE bl_id=?";

            _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry);
            _prep_statement_1.setInt(1, newBusinessEntityModel.getBl_id());

            _rs = _prep_statement_1.executeQuery();

            if (_rs.next()) {

                renewBusinessEntityModel.setBl_name(_rs.getString("bl_name"));
                renewBusinessEntityModel.setBl_description(_rs.getString("bl_description"));
                renewBusinessEntityModel.setBl_head(_rs.getString("bl_head"));
                renewBusinessEntityModel.setBl_status_flag(_rs.getInt("bl_status_flag"));

                isDataAvailabile = true;

            }

            if (isDataAvailabile) { //if data availabile, going to execute update query.  

                //Audit Trail
                record_pk = "" + newBusinessEntityModel.getBl_id();
                old_value = auditing.getAllRecords(record_pk, related_table).toString();

                main_AdministrationQry
                        = "UPDATE gcsm_businessline SET \n"
                        + "bl_name=?,"
                        + "bl_description=?,"
                        + "bl_head=?,"
                        + "bl_status_flag=?,"
                        + "bl_composed_user=?,"
                        + "bl_composed_timestamp=now() "
                        + "WHERE bl_id=?";

                _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry);
                _prep_statement_1.setString(1, newBusinessEntityModel.getBl_name());
                _prep_statement_1.setString(2, newBusinessEntityModel.getBl_description());
                _prep_statement_1.setString(3, newBusinessEntityModel.getBl_head());
                _prep_statement_1.setInt(4, newBusinessEntityModel.getBl_status_flag());
                _prep_statement_1.setString(5, session_username);
                _prep_statement_1.setInt(6, newBusinessEntityModel.getBl_id());

                if (_prep_statement_1.executeUpdate() <= 0) {

                    gcsm_responceHandler.setResponceModule("save_BusinessLine");
                    gcsm_responceHandler.setResponceType("error");
                    gcsm_responceHandler.setResponceCode("0001");
                    gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");
                    log.error("unable to update this record.");

                }

                gcsm_responceHandler.setResponceModule("save_BusinessLine");
                gcsm_responceHandler.setResponceType("success");
                gcsm_responceHandler.setResponceCode("0000");
                gcsm_responceHandler.setResponceDescription("Awesome! You were successful.");
                log.info("update successful.");
                
                //Audit Trail
                auditType = "UPDATE";

            } else { //if data not availabile, going to execute insert query.

                main_AdministrationQry
                        = "INSERT INTO gcsm_businessline("
                        + "bl_id,"
                        + "bl_name,"
                        + "bl_description,"
                        + "bl_head,"
                        + "bl_status_flag,"
                        + "bl_setup_user,"
                        + "bl_composed_user,"
                        + "bl_setup_timestamp,"
                        + "bl_composed_timestamp)"
                        + " VALUES(?,?,?,?,?,?,?,now(),now())";

                _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry, Statement.RETURN_GENERATED_KEYS);
                _prep_statement_1.setInt(1, newBusinessEntityModel.getBl_id());
                _prep_statement_1.setString(2, newBusinessEntityModel.getBl_name());
                _prep_statement_1.setString(3, newBusinessEntityModel.getBl_description());
                _prep_statement_1.setString(4, newBusinessEntityModel.getBl_head());
                _prep_statement_1.setInt(5, newBusinessEntityModel.getBl_status_flag());
                _prep_statement_1.setString(6, session_username);
                _prep_statement_1.setString(7, session_username);

                if (_prep_statement_1.executeUpdate() <= 0) {

                    gcsm_responceHandler.setResponceModule("save_BusinessLine");
                    gcsm_responceHandler.setResponceType("error");
                    gcsm_responceHandler.setResponceCode("0001");
                    gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to insert this record.");
                    log.error("unable to insert this record.");

                }

                if (!isDataAvailabile) {
                    _rs = _prep_statement_1.getGeneratedKeys();
                }

                gcsm_responceHandler.setResponceModule("save_BusinessLine");
                gcsm_responceHandler.setResponceType("success");
                gcsm_responceHandler.setResponceCode("0000");
                gcsm_responceHandler.setResponceDescription("Awesome! You were successful.");
                log.info("insert successful.");
                
                //Audit Trail
                auditType = "INSERT";
                //record_pk = "" + (_rs.getInt(1));

            }

            if (!end_Connection(_currentCon)) {

                gcsm_responceHandler.setResponceModule("save_BusinessLine");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("0001");
                gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }

            //Audit Trail
           // String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            switch (auditType) {
                case "INSERT":
                    {                        
                        //auditing.saveAuditRecord(session_username, related_table, auditType, record_pk, old_value, new_value);
                        break;
                    }
                case "UPDATE":
                    {                        
                       // auditing.saveAuditRecord(session_username, related_table, auditType, record_pk, old_value, new_value);
                        break;
                    }
            }
        } catch (Exception e) {

            gcsm_responceHandler.setResponceModule("save_BusinessLine");
            gcsm_responceHandler.setResponceType("error");
            gcsm_responceHandler.setResponceCode("00002");
            gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to insert this record.\n" + e);
            log.error("unable to insert this record : " + e);

        } finally {

            try {

                if (_rs != null) {
                    _rs.close();
                }

                if (_prep_statement_1 != null) {
                    _prep_statement_1.close();
                }

                if (_currentCon != null) {
                    _currentCon.close();
                }

            } catch (Exception e) {

                gcsm_responceHandler.setResponceModule("save_BusinessLine");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("0001");
                gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to insert this record.\n" + e);
                log.error("unable to insert this record : " + e);

            }

        }

        return gcsm_responceHandler;
    }

    @Override
    public JSONArray getTableBusinessLine(JSONObject jasonobj) {

        database_Connection = DatabaseConnection.getInstance();
        _currentCon = database_Connection.get_JDBC_Connection();
        String main_AdministrationQry = "";
        JSONObject m_jsObj;
        _jsArr = new JSONArray();

        int i = 0;

        try {

            main_AdministrationQry
                    = "SELECT * ,\n"
                    + "(SELECT COUNT(*) FROM gcsm_businessline where bl_name!='root') as RowsCount \n"
                    + "FROM\n"
                    + "gcsm_businessline where bl_name!='root' ORDER BY bl_id ;";

            System.out.println(main_AdministrationQry);
            _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry);
            _rs = _prep_statement_1.executeQuery();

            while (_rs.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("bl_id", _rs.getInt("bl_id"));
                m_jsObj.put("bl_name", _rs.getString("bl_name"));
                m_jsObj.put("bl_description", _rs.getString("bl_description"));
                m_jsObj.put("bl_head", _rs.getString("bl_head"));
                m_jsObj.put("bl_status_flag", _rs.getInt("bl_status_flag"));
                m_jsObj.put("bl_setup_user", _rs.getString("bl_setup_user"));
                m_jsObj.put("RowsCount", _rs.getInt("RowsCount"));
                _jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {

            log.error(e);

        } finally {

            try {

                if (_rs != null) {
                    _rs.close();
                }

                if (_prep_statement_1 != null) {
                    _prep_statement_1.close();
                }

                if (_currentCon != null) {
                    _currentCon.close();
                }

            } catch (Exception e) {

                gcsm_responceHandler.setResponceModule("get_Table_BusinessLine");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("0001");
                gcsm_responceHandler.setResponceDescription("Error occured.!\n" + e);
                log.error(e);

            }

        }

        return _jsArr;
    }

    @Override
    public JSONArray getInfoBusinessLine(JSONObject jasonobj) {

        database_Connection = DatabaseConnection.getInstance();
        _currentCon = database_Connection.get_JDBC_Connection();
        String main_AdministrationQry = "";
        JSONObject m_jsObj;
        _jsArr = new JSONArray();

        int i = 0;

        try {

            main_AdministrationQry
                    = "SELECT * \n"
                    + "FROM\n"
                    + "gcsm_businessline\n"
                    + "WHERE bl_id='" + jasonobj.get("bl_id") + "'";

            System.out.println(main_AdministrationQry);
            _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry);
            _rs = _prep_statement_1.executeQuery();

            while (_rs.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("bl_id", _rs.getInt("bl_id"));
                m_jsObj.put("bl_name", _rs.getString("bl_name"));
                m_jsObj.put("bl_description", _rs.getString("bl_description"));
                m_jsObj.put("bl_head", _rs.getString("bl_head"));
                m_jsObj.put("bl_status_flag", _rs.getInt("bl_status_flag"));
                m_jsObj.put("bl_setup_user", _rs.getString("bl_setup_user"));

                _jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {

            log.error(e);

        } finally {

            try {

                if (_rs != null) {
                    _rs.close();
                }

                if (_prep_statement_1 != null) {
                    _prep_statement_1.close();
                }

                if (_currentCon != null) {
                    _currentCon.close();
                }

            } catch (Exception e) {
                gcsm_responceHandler.setResponceModule("get_Info_BusinessLine");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("0001");
                gcsm_responceHandler.setResponceDescription("Error occured.!\n" + e);
                log.error(e);

            }

        }

        return _jsArr;
    }

    @Override
    public JSONArray getOwnCompany(JSONObject jasonobj) {

        database_Connection = DatabaseConnection.getInstance();
        _currentCon = database_Connection.get_JDBC_Connection();
        String main_AdministrationQry = "";
        JSONObject m_jsObj;
        _jsArr = new JSONArray();

        int i = 0;

        try {

            main_AdministrationQry
                    = "SELECT * \n"
                    + "FROM\n"
                    + "gcsm_businessline\n"
                    + "WHERE bl_id in (SELECT user_businessline from gcsm_user where user_username='" + jasonobj.get("username") + "')";

            System.out.println(main_AdministrationQry);
            _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry);
            _rs = _prep_statement_1.executeQuery();

            while (_rs.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("bl_id", _rs.getInt("bl_id"));
                m_jsObj.put("bl_name", _rs.getString("bl_name"));
                m_jsObj.put("bl_description", _rs.getString("bl_description"));
                m_jsObj.put("bl_head", _rs.getString("bl_head"));
                m_jsObj.put("bl_status_flag", _rs.getInt("bl_status_flag"));
                m_jsObj.put("bl_setup_user", _rs.getString("bl_setup_user"));

                _jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {

            log.error(e);

        } finally {

            try {

                if (_rs != null) {
                    _rs.close();
                }

                if (_prep_statement_1 != null) {
                    _prep_statement_1.close();
                }

                if (_currentCon != null) {
                    _currentCon.close();
                }

            } catch (Exception e) {
                gcsm_responceHandler.setResponceModule("get_Info_BusinessLine");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("0001");
                gcsm_responceHandler.setResponceDescription("Error occured.!\n" + e);
                log.error(e);

            }

        }

        return _jsArr;
    }

}
