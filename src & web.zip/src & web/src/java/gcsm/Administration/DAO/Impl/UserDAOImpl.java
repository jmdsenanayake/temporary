/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Administration.DAO.Impl;

import static gcsm.Administration.DAO.Impl.BusinessEntitiyDAOImpl.database_Connection;
import gcsm.Administration.DAO.UserDAO;
import gcsm.Administration.Model.BusinessEntityModel;
import gcsm.Administration.Model.UserModel;
import gcsm.Utitlities.Impl.Auditing;
import gcsm.Utitlities.Impl.DatabaseConnection;
import gcsm.Utitlities.Impl.Encryption;
import gcsm.Utitlities.Impl.JSONObjects;
import gcsm.Utitlities.Model.JSPPages;
import gcsm.Utitlities.Model.ResponceHandler;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Randika_10992
 */
public class UserDAOImpl extends DatabaseConnection implements UserDAO {

    static Logger log = LogManager.getLogger(UserDAOImpl.class.getName());

    //Audit Trail
    String auditType = "";
    Auditing auditing = new Auditing();
    String related_table = "gcsm_product";
    String record_pk = "";
    String old_value = "##Empty##";

    static DatabaseConnection database_Connection;
    static Connection _currentCon = null;
    private Statement _statement = null;
    private PreparedStatement _prep_statement_1 = null;
    private PreparedStatement _prep_statement_2 = null;
    private ResultSet _rs = null;
    private Exception _exception;
    private ResponceHandler gcsm_responceHandler;
    private JSONObjects gcsm_Jason;
    private JSONArray _jsArr;
    private Encryption encryption;

    @Override
    public ResponceHandler saveUsers(JSONObject jasonobj) {

        String session_username = jasonobj.get("session_username").toString();

        gcsm_responceHandler = new ResponceHandler();
        database_Connection = DatabaseConnection.getInstance();
        _currentCon = database_Connection.get_JDBC_Connection();
        gcsm_Jason = new JSONObjects();
        UserModel newUserModel;
        UserModel renewUserModel;
        String main_AdministrationQry;

        boolean isDataAvailabile = false;

        try {

            newUserModel = new UserModel();
            newUserModel = gcsm_Jason.convertUserModelToJSON(jasonobj.toString());
            renewUserModel = new UserModel();

            // check database connection problem 
            if (!start_Connection(_currentCon)) {

                gcsm_responceHandler.setResponceModule("save_User");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("00001");
                gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, database connection establishing problem.");

                log.error("database connection establishing problem.");
                throw new Exception("An error occurred, database connection establishing problem.");

            }

            // Check Record Already Exists
            if (newUserModel.getUser_id() == 0) {

                main_AdministrationQry = "SELECT * FROM gcsm_user WHERE user_NIC=? AND user_EPF=?";

                _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry);
                _prep_statement_1.setString(1, newUserModel.getUser_NIC());
                _prep_statement_1.setInt(2, newUserModel.getUser_EPF());
                _rs = _prep_statement_1.executeQuery();

                if (_rs.next()) {

                    gcsm_responceHandler.setResponceModule("save_User");
                    gcsm_responceHandler.setResponceType("error");;
                    gcsm_responceHandler.setResponceCode("00001");
                    gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, record already exists in the databse.");

                    log.error("record already exists in the databse.");
                    throw new Exception("An error occurred, record already exists in the databse.");

                }

            }

            main_AdministrationQry = "SELECT * FROM gcsm_user WHERE user_id=?";

            _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry);
            _prep_statement_1.setInt(1, newUserModel.getUser_id());

            _rs = _prep_statement_1.executeQuery();

            if (_rs.next()) {

                renewUserModel.setUser_businessline(_rs.getInt("user_businessline"));
                renewUserModel.setUser_name_first(_rs.getString("user_name_first"));
                renewUserModel.setUser_name_last(_rs.getString("user_name_last"));
                renewUserModel.setUser_NIC(_rs.getString("user_NIC"));
                renewUserModel.setUser_EPF(_rs.getInt("user_EPF"));
                renewUserModel.setUser_designation(_rs.getString("user_designation"));
                renewUserModel.setUser_username(_rs.getString("user_username"));
                renewUserModel.setUser_password(_rs.getString("user_password"));
                renewUserModel.setUser_status_flag(_rs.getInt("user_status_flag"));

                isDataAvailabile = true;

            }

            if (isDataAvailabile) { //if data availabile, going to execute update query.   

                //Audit Trail
                record_pk = "" + newUserModel.getUser_id();
                old_value = auditing.getAllRecords(record_pk, related_table).toString();

                main_AdministrationQry
                        = "UPDATE gcsm_user SET \n"
                        + "user_businessline=?,"
                        + "user_name_first=?,"
                        + "user_name_last=?,"
                        + "user_NIC=?,"
                        + "user_EPF=?,"
                        + "user_designation=?,"
                        + "user_username=?,"
                        + "user_password=?,"
                        + "user_status_flag=?,"
                        + "user_composed_user=?,"
                        + "user_composed_timestamp=now() "
                        + "WHERE user_id=?";

                _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry);
                _prep_statement_1.setInt(1, newUserModel.getUser_businessline());
                _prep_statement_1.setString(2, newUserModel.getUser_name_first());
                _prep_statement_1.setString(3, newUserModel.getUser_name_last());
                _prep_statement_1.setString(4, newUserModel.getUser_NIC());
                _prep_statement_1.setInt(5, newUserModel.getUser_EPF());
                _prep_statement_1.setString(6, newUserModel.getUser_designation());
                _prep_statement_1.setString(7, newUserModel.getUser_username());

                encryption = new Encryption();
                String pass = newUserModel.getUser_password();
                System.out.println(pass);
                _prep_statement_1.setString(8, encryption.encrypt(pass));

                _prep_statement_1.setInt(9, newUserModel.getUser_status_flag());
                _prep_statement_1.setString(10, session_username);
                _prep_statement_1.setInt(11, newUserModel.getUser_id());

                if (_prep_statement_1.executeUpdate() <= 0) {

                    gcsm_responceHandler.setResponceModule("save_User");
                    gcsm_responceHandler.setResponceType("error");
                    gcsm_responceHandler.setResponceCode("0001");
                    gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");
                    log.error("unable to update this record.");

                }

                gcsm_responceHandler.setResponceModule("save_User");
                gcsm_responceHandler.setResponceType("success");
                gcsm_responceHandler.setResponceCode("0000");
                gcsm_responceHandler.setResponceDescription("Awesome! You were successful.");
                log.info("update successful.");

                //Audit Trail
                auditType = "UPDATE";

            } else { //if data not availabile, going to execute insert query.

                main_AdministrationQry
                        = "INSERT INTO gcsm_user("
                        + "user_id,"
                        + "user_businessline,"
                        + "user_name_first,"
                        + "user_name_last,"
                        + "user_username,"
                        + "user_password,"
                        + "user_NIC,"
                        + "user_EPF,"
                        + "user_designation,"
                        + "user_status_flag,"
                        + "user_setup_user,"
                        + "user_composed_user,"
                        + "user_auth_user,"
                        + "user_setup_timestamp,"
                        + "user_composed_timestamp,"
                        + "user_auth_timestamp"
                        + ")"
                        + " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,now(),now(),?)";

                _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry, Statement.RETURN_GENERATED_KEYS);
                _prep_statement_1.setInt(1, newUserModel.getUser_id());
                _prep_statement_1.setInt(2, newUserModel.getUser_businessline());
                _prep_statement_1.setString(3, newUserModel.getUser_name_first());
                _prep_statement_1.setString(4, newUserModel.getUser_name_last());
                _prep_statement_1.setString(5, newUserModel.getUser_username());

                encryption = new Encryption();
                String pass = newUserModel.getUser_password();
                _prep_statement_1.setString(6, encryption.encrypt(pass));

                _prep_statement_1.setString(7, newUserModel.getUser_NIC());
                _prep_statement_1.setInt(8, newUserModel.getUser_EPF());
                _prep_statement_1.setString(9, newUserModel.getUser_designation());
                _prep_statement_1.setInt(10, newUserModel.getUser_status_flag());
                _prep_statement_1.setString(11, session_username);
                _prep_statement_1.setString(12, session_username);
                _prep_statement_1.setString(13, "N/A");
                _prep_statement_1.setString(14, "N/A");

                if (_prep_statement_1.executeUpdate() <= 0) {

                    gcsm_responceHandler.setResponceModule("save_User");
                    gcsm_responceHandler.setResponceType("error");
                    gcsm_responceHandler.setResponceCode("0001");
                    gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to insert this record.");
                    log.error("unable to insert this record.");

                }

                //insert userprivilages for selected privilages
                String[] pageNames = JSPPages.PAGES;
                for (String pageName : pageNames) {
                    main_AdministrationQry
                            = "INSERT INTO gcsm_user_page_privilages (user_name,page,authorization_status) \n"
                            + "values (?,?,0)";

                    _prep_statement_2 = _currentCon.prepareStatement(main_AdministrationQry);
                    _prep_statement_2.setString(1, newUserModel.getUser_username());
                    _prep_statement_2.setString(2, pageName);
                    System.out.println(_prep_statement_2);

                    if (_prep_statement_2.executeUpdate() <= 0) {

                        gcsm_responceHandler.setResponceModule("save_userPrivileges");
                        gcsm_responceHandler.setResponceType("error");
                        gcsm_responceHandler.setResponceCode("0001");
                        gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");
                        log.error("unable to update this record.");
                    }
                }

                if (!isDataAvailabile) {
                    _rs = _prep_statement_1.getGeneratedKeys();
                }

                gcsm_responceHandler.setResponceModule("save_User");
                gcsm_responceHandler.setResponceType("success");
                gcsm_responceHandler.setResponceCode("0000");
                gcsm_responceHandler.setResponceDescription("Awesome! You were successful.");
                log.info("update successful.");

                  //Audit Trail
//                auditType = "INSERT";
//                record_pk = "" + (_rs.getInt(1));
            }

            if (!end_Connection(_currentCon)) {

                gcsm_responceHandler.setResponceModule("save_User");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("0001");
                gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }

             //Audit Trail
//            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
//            switch (auditType) {
//                case "INSERT":
//                    {                        
//                        auditing.saveAuditRecord(session_username, related_table, auditType, record_pk, old_value, new_value);
//                        break;
//                    }
//                case "UPDATE":
//                    {                        
//                        auditing.saveAuditRecord(session_username, related_table, auditType, record_pk, old_value, new_value);
//                        break;
//                    }
//            }
        } catch (Exception e) {

            gcsm_responceHandler.setResponceModule("save_User");
            gcsm_responceHandler.setResponceType("error");
            gcsm_responceHandler.setResponceCode("00002");
            gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to insert this record.\n" + e);
            log.error("unable to insert this record : " + e);

        } finally {

            try {

                if (_rs != null) {
                    _rs.close();
                }

                if (_prep_statement_1 != null) {
                    _prep_statement_1.close();
                }
                if (_prep_statement_2 != null) {
                    _prep_statement_2.close();
                }

                if (_currentCon != null) {
                    _currentCon.close();
                }

            } catch (Exception e) {

                gcsm_responceHandler.setResponceModule("save_User");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("0001");
                gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to insert this record.\n" + e);
                log.error("unable to insert this record : " + e);

            }

        }

        return gcsm_responceHandler;

    }

    @Override
    public JSONArray getTableUsers(JSONObject jasonobj) {

        database_Connection = DatabaseConnection.getInstance();
        _currentCon = database_Connection.get_JDBC_Connection();
        String main_AdministrationQry = "";
        JSONObject m_jsObj;
        _jsArr = new JSONArray();

        int i = 0;

        try {

            main_AdministrationQry
                    = "SELECT * ,\n"
                    + "(SELECT COUNT(*) FROM gcsm_user , gcsm_businessline bl WHERE usr.user_businessline = bl.bl_id ) as RowsCount ,\n"
                    + "bl.bl_name as user_businessline_name\n"
                    + "FROM\n"
                    + "gcsm_user usr, gcsm_businessline bl\n"
                    + "WHERE\n"
                    + "usr.user_businessline = bl.bl_id "
                    + "AND usr.user_username !='root' ORDER BY user_id ;";

            System.out.println(main_AdministrationQry);
            _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry);
            _rs = _prep_statement_1.executeQuery();

            while (_rs.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("user_id", _rs.getInt("user_id"));
                m_jsObj.put("user_businessline", _rs.getInt("user_businessline"));
                m_jsObj.put("user_name_first", _rs.getString("user_name_first"));
                m_jsObj.put("user_name_last", _rs.getString("user_name_last"));
                m_jsObj.put("user_username", _rs.getString("user_username"));
                m_jsObj.put("user_password", _rs.getString("user_password"));
                m_jsObj.put("user_NIC", _rs.getString("user_NIC"));
                m_jsObj.put("user_EPF", _rs.getInt("user_EPF"));
                m_jsObj.put("user_designation", _rs.getString("user_designation"));
                m_jsObj.put("user_status_flag", _rs.getInt("user_status_flag"));
                m_jsObj.put("user_setup_user", _rs.getString("user_setup_user"));
                m_jsObj.put("user_auth_user", _rs.getString("user_auth_user"));
                m_jsObj.put("user_signin_flag", _rs.getInt("user_signin_flag"));
                m_jsObj.put("user_businessline_name", _rs.getString("user_businessline_name"));
                m_jsObj.put("RowsCount", _rs.getInt("RowsCount"));
                _jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {

            log.error(e);

        } finally {

            try {

                if (_rs != null) {
                    _rs.close();
                }

                if (_prep_statement_1 != null) {
                    _prep_statement_1.close();
                }

                if (_currentCon != null) {
                    _currentCon.close();
                }

            } catch (Exception e) {

                gcsm_responceHandler.setResponceModule("get_Table_Users");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("0001");
                gcsm_responceHandler.setResponceDescription("Error occured.!\n" + e);
                log.error(e);

            }

        }

        return _jsArr;

    }

    @Override
    public JSONArray getInfoUsers(JSONObject jasonobj) {

        database_Connection = DatabaseConnection.getInstance();
        _currentCon = database_Connection.get_JDBC_Connection();
        String main_AdministrationQry = "";
        JSONObject m_jsObj;
        _jsArr = new JSONArray();

        int i = 0;

        try {

            main_AdministrationQry
                    = "SELECT * ,\n"
                    + "bl.bl_name as user_businessline_name\n"
                    + "FROM\n"
                    + "gcsm_user usr, gcsm_businessline bl\n"
                    + "WHERE\n"
                    + "usr.user_businessline = bl.bl_id AND user_id = '" + jasonobj.get("user_id") + "' ORDER BY user_id ;";

            System.out.println(main_AdministrationQry);
            _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry);
            _rs = _prep_statement_1.executeQuery();

            while (_rs.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("user_id", _rs.getInt("user_id"));
                m_jsObj.put("user_businessline", _rs.getInt("user_businessline"));
                m_jsObj.put("user_name_first", _rs.getString("user_name_first"));
                m_jsObj.put("user_name_last", _rs.getString("user_name_last"));
                m_jsObj.put("user_username", _rs.getString("user_username"));

                encryption = new Encryption();
                String de_pass = encryption.decrypt(_rs.getString("user_password"));

                m_jsObj.put("user_password", de_pass);
                m_jsObj.put("user_NIC", _rs.getString("user_NIC"));
                m_jsObj.put("user_EPF", _rs.getInt("user_EPF"));
                m_jsObj.put("user_designation", _rs.getString("user_designation"));
                m_jsObj.put("user_status_flag", _rs.getInt("user_status_flag"));
                m_jsObj.put("user_setup_user", _rs.getString("user_setup_user"));
                m_jsObj.put("user_auth_user", _rs.getString("user_auth_user"));
                m_jsObj.put("user_signin_flag", _rs.getInt("user_signin_flag"));
                m_jsObj.put("user_businessline_name", _rs.getString("user_businessline_name"));

                _jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {

            log.error(e);

        } finally {

            try {

                if (_rs != null) {
                    _rs.close();
                }

                if (_prep_statement_1 != null) {
                    _prep_statement_1.close();
                }

                if (_currentCon != null) {
                    _currentCon.close();
                }

            } catch (Exception e) {

                gcsm_responceHandler.setResponceModule("get_Info_Users");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("0001");
                gcsm_responceHandler.setResponceDescription("Error occured.!\n" + e);
                log.error(e);

            }

        }

        return _jsArr;

    }

    @Override
    public ResponceHandler checkPasswordForPasswordChange(JSONObject jasonobj) {
        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        JSONObject m_jsObj;
        JSONArray jsArr = new JSONArray();
        String username = jasonobj.get("username").toString();
        String password = jasonobj.get("current_password").toString();
        gcsm_responceHandler = new ResponceHandler();

        encryption = new Encryption();
        String en_password = encryption.encrypt(String.valueOf(password));

        try {
            String queryCheckPassword = "SELECT user_id FROM gcsm_user where user_username=? and user_password=?";

            preparedStatement = currentConnection.prepareStatement(queryCheckPassword);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, en_password);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.first()) {
                gcsm_responceHandler.setResponceModule("user_id");
                gcsm_responceHandler.setResponceType("success");
                gcsm_responceHandler.setResponceCode("0000");
                gcsm_responceHandler.setResponceDescription("User_id exitsts");

            } else {
                gcsm_responceHandler.setResponceModule("user_id");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("0001");
                gcsm_responceHandler.setResponceDescription("Current Password is incorrect.");
            }

        } catch (Exception e) {
            e.printStackTrace();

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                gcsm_responceHandler.setResponceModule("user_id");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("0001");
                gcsm_responceHandler.setResponceDescription("Error occured in user_id retrieving");
            }

        }

        return gcsm_responceHandler;
    }

    @Override
    public ResponceHandler changePassword(JSONObject jasonobj) {
        ResponceHandler responceHandler = new ResponceHandler();
        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        JSONObjects jsonObejcts = new JSONObjects();
        String username = jasonobj.get("username").toString();
        String password = jasonobj.get("new_password").toString();
        
        encryption = new Encryption();
        String en_password = encryption.encrypt(String.valueOf(password));
        System.out.println("hio");
        try {

            String shadowOtherAmountsUpdateSuery
                    = "UPDATE gcsm_user "
                    + "set user_password=? " //1                     
                    + "where user_username=?";        //2

            preparedStatement = currentConnection.prepareStatement(shadowOtherAmountsUpdateSuery);
            preparedStatement.setString(1, en_password);
            preparedStatement.setString(2, username);

           

            if (preparedStatement.executeUpdate() <= 0) {

                responceHandler.setResponceModule("changePassword");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");

            }

            responceHandler.setResponceModule("changePassword");
            responceHandler.setResponceType("success");
            responceHandler.setResponceCode("0000");
            responceHandler.setResponceDescription("Success");

            if (!databaseConnection.end_Connection(currentConnection)) {

                responceHandler.setResponceModule("changePassword");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("Uh oh! An error occurred, database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }

            

        } catch (SQLException ex) {
            ex.printStackTrace();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {

            try {

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {

                responceHandler.setResponceModule("modifyOtherContractvalue");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in modifyOtherContractvalue");

            }
        }
        return responceHandler;
    }

}
