/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Administration.Model;

/**
 *
 * @author Randika_10992
 */
public class BusinessEntityModel { 
    
    private int bl_id;
    private String bl_name;
    private String bl_description;
    private String bl_head;
    private int bl_status_flag;
    private String session_username;

    /**
     * @return the bl_id
     */
    public int getBl_id() {
        return bl_id;
    }

    /**
     * @param bl_id the bl_id to set
     */
    public void setBl_id(int bl_id) {
        this.bl_id = bl_id;
    }

    /**
     * @return the bl_name
     */
    public String getBl_name() {
        return bl_name;
    }

    /**
     * @param bl_name the bl_name to set
     */
    public void setBl_name(String bl_name) {
        this.bl_name = bl_name;
    }

    /**
     * @return the bl_description
     */
    public String getBl_description() {
        return bl_description;
    }

    /**
     * @param bl_description the bl_description to set
     */
    public void setBl_description(String bl_description) {
        this.bl_description = bl_description;
    }

    /**
     * @return the bl_head
     */
    public String getBl_head() {
        return bl_head;
    }

    /**
     * @param bl_head the bl_head to set
     */
    public void setBl_head(String bl_head) {
        this.bl_head = bl_head;
    }

    /**
     * @return the bl_status_flag
     */
    public int getBl_status_flag() {
        return bl_status_flag;
    }

    /**
     * @param bl_status_flag the bl_status_flag to set
     */
    public void setBl_status_flag(int bl_status_flag) {
        this.bl_status_flag = bl_status_flag;
    }

    /**
     * @return the session_username
     */
    public String getSession_username() {
        return session_username;
    }

    /**
     * @param session_username the session_username to set
     */
    public void setSession_username(String session_username) {
        this.session_username = session_username;
    }

    public void info(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
  
    
}
