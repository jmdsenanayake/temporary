/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Administration.Controller;

import gcsm.Administration.DAO.BusinessEntitiyDAO;
import gcsm.Administration.DAO.Impl.BusinessEntitiyDAOImpl;
import gcsm.Administration.DAO.Impl.UserDAOImpl;
import gcsm.Administration.DAO.UserDAO;
import gcsm.Utitlities.Model.ResponceHandler;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Randika_10992
 */
public class UsersController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        HttpSession session = request.getSession(false);
        JSONObject result = new JSONObject();
        JSONObject data = new JSONObject();
        String m_strfunction = "";
        PrintWriter out = response.getWriter();
        ResponceHandler responceHandler;
        JSONArray jsArr = null;
        String username=session.getAttribute("session_username").toString();

        try {

            m_strfunction = request.getParameter("functionName");
            UserDAO userDAO = new UserDAOImpl();
          
            if (m_strfunction.equalsIgnoreCase("get_Table_Users")) {
                jsArr = userDAO.getTableUsers(data);
                log(jsArr.toString());
                out.print(jsArr);
            }
            
            else if (m_strfunction.equalsIgnoreCase("get_Info_Users")) {                
                data.put("user_id", request.getParameter("user_id"));
                jsArr = userDAO.getInfoUsers(data);    
                out.print(jsArr);
            }
            
            else if (m_strfunction.equalsIgnoreCase("checkPasswordForPasswordChange")) {
                data.put("username", username);
                data.put("current_password", request.getParameter("current_password"));
                responceHandler = userDAO.checkPasswordForPasswordChange(data);                
                if (responceHandler.getResponceType().equals("success")) {
                    result.put(responceHandler.getResponceType().trim(), responceHandler.getResponceDescription().trim());
                    out.print(result);
                } else {
                    result.put(responceHandler.getResponceType().trim(), responceHandler.getResponceDescription().trim());
                    out.print(result);
                }
            }
            
            else if (m_strfunction.equalsIgnoreCase("changePassword")) {
                data.put("username", username);
                data.put("new_password", request.getParameter("new_password"));
                responceHandler = userDAO.changePassword(data);                
                if (responceHandler.getResponceType().equals("success")) {                   
                    result.put(responceHandler.getResponceType().trim(), responceHandler.getResponceDescription().trim());
                    out.print(result);
                } else {
                    result.put(responceHandler.getResponceType().trim(), responceHandler.getResponceDescription().trim());
                    out.print(result);
                }
            }
            
            else if (m_strfunction.equalsIgnoreCase("resetPassword")) {
                data.put("username", request.getParameter("user_username"));
                data.put("new_password", request.getParameter("user_username"));
                responceHandler = userDAO.changePassword(data);                
                if (responceHandler.getResponceType().equals("success")) {                   
                    result.put(responceHandler.getResponceType().trim(), responceHandler.getResponceDescription().trim());
                    out.print(result);
                } else {
                    result.put(responceHandler.getResponceType().trim(), responceHandler.getResponceDescription().trim());
                    out.print(result);
                }
            }

        } catch (Exception e) {

        }

        

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        response.setContentType("text/html;charset=UTF-8");
        JSONObject result = new JSONObject();
        JSONObject data = new JSONObject();
        String m_strfunction = "";
        PrintWriter out = response.getWriter();
        ResponceHandler gcsm_responceHandler;

        try {

            Enumeration enumeration = request.getParameterNames();
            while (enumeration.hasMoreElements()) {

                String parameterName = (String) enumeration.nextElement();
                if (parameterName.equalsIgnoreCase("functionName")) {
                    m_strfunction = request.getParameter(parameterName);
                } else {
                    data.put(parameterName, request.getParameter(parameterName));
                }
            }

            UserDAOImpl user = new UserDAOImpl();

            if (m_strfunction.equalsIgnoreCase("save_User")) {

                System.out.println(data);
                
                data.put("session_username", session.getAttribute("session_username"));
                gcsm_responceHandler = user.saveUsers(data);
                
                if (gcsm_responceHandler.getResponceType().equals("success")) {

                    result.put(gcsm_responceHandler.getResponceType().trim(), gcsm_responceHandler.getResponceDescription().trim());
                    out.print(result);

                } else {

                    result.put(gcsm_responceHandler.getResponceType().trim(), gcsm_responceHandler.getResponceDescription().trim());
                    out.print(result);
                }
            }

        } catch (Exception e) {

        }

        out.flush();

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
