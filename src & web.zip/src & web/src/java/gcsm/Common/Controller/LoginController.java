/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Common.Controller;

import gcsm.Common.DAO.Impl.LoginDAOImpl;
import gcsm.Administration.DAO.Impl.UserDAOImpl;
import gcsm.Common.DAO.LoginDAO;
import gcsm.Administration.DAO.UserDAO;
import gcsm.Utitlities.Model.ResponceHandler;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Randika_10992
 */
public class LoginController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        HttpSession session = request.getSession(false);
        JSONObject result = new JSONObject();
        JSONObject data = new JSONObject();
        String m_strfunction = "";
        PrintWriter out = response.getWriter();
        ResponceHandler responceHandler;
        JSONArray jsArr = null;

        try {

            m_strfunction = request.getParameter("functionName");
            LoginDAO loginDAO = new LoginDAOImpl();

            if (m_strfunction.equalsIgnoreCase("authentication")) {
                data.put("user_username", request.getParameter("user_username"));
                data.put("user_password", request.getParameter("user_password"));
                jsArr = loginDAO.authentication(data);
            }

            if (m_strfunction.equalsIgnoreCase("redirect")) {
                session.setAttribute("session_username", request.getParameter("session_username"));
                session.setAttribute("session_firstname", request.getParameter("session_firstname"));
                session.setAttribute("session_lastname", request.getParameter("session_lastname"));
                session.setAttribute("session_role_type", request.getParameter("session_role_type"));
                session.setAttribute("auth_type", request.getParameter("auth_type"));
            }

            if (m_strfunction.equalsIgnoreCase("logout")) {
                
                final Logger logger = LogManager.getLogger(LoginController.class.getName());
                logger.info("Logging out : " + session.getAttribute("session_username"));
                session.invalidate();

            }

        } catch (Exception e) {

        }

        out.print(jsArr);

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
