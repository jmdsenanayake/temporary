/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Common.DAO.Impl;

import gcsm.Administration.DAO.Impl.BusinessEntitiyDAOImpl;
import gcsm.Common.DAO.LoginDAO;
import gcsm.Utitlities.Impl.DatabaseConnection;
import gcsm.Utitlities.Impl.Encryption;
import gcsm.Utitlities.Impl.JSONObjects;
import gcsm.Utitlities.Model.ResponceHandler;
import gcsm.Utitlities.Model.RoleTypes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Randika_10992
 */
public class LoginDAOImpl extends DatabaseConnection implements LoginDAO {

    static Logger log = LogManager.getLogger(LoginDAOImpl.class.getName());

    static DatabaseConnection database_Connection;
    static Connection _currentCon = null;
    private Statement _statement = null;
    private PreparedStatement _prep_statement_1 = null;
    private PreparedStatement _prep_statement_2 = null;
    private ResultSet _rs = null;
    private Exception _exception;
    private ResponceHandler gcsm_responceHandler;
    private JSONObjects gcsm_Jason;
    private JSONArray _jsArr;
    private Encryption encryption;

    @Override
    public JSONArray authentication(JSONObject jasonobj) {

        database_Connection = DatabaseConnection.getInstance();
        _currentCon = database_Connection.get_JDBC_Connection();
        String main_AdministrationQry = "";
        JSONObject m_jsObj;
        _jsArr = new JSONArray();

        int i = 0;

        encryption = new Encryption();
        String en_pass = encryption.encrypt(String.valueOf(jasonobj.get("user_password")));

        try {

            main_AdministrationQry
                    = "SELECT usr_role.* ,\n"
                    + "usr.user_EPF as user_EPF,\n"
                    + "usr.user_name_first as user_firstname,\n"
                    + "usr.user_name_last as user_lastname,\n"
                    + "usr.user_NIC as user_NIC,\n"
                    + "usr.user_username as user_username\n"
                    + "FROM\n"
                    + "gcsm_user_has_role usr_role , gcsm_user usr\n"
                    + "WHERE\n"
                    + "usr_role.user_has_role_user = usr.user_id AND  usr.user_status_flag !=0 AND usr_role.user_has_role_status_flag !=0  AND usr.user_username = '" + jasonobj.get("user_username") + "' AND usr.user_password = '" + en_pass + "' \n"
                    + "ORDER BY \n"
                    + "usr_role.user_has_role_id \n"
                    + "LIMIT 1;";

            log.info("logging attemp : " + jasonobj.get("user_username"));

            _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry);
            _rs = _prep_statement_1.executeQuery();

            int usr_role_type = 0;
            String user_has_role_type = "";

            while (_rs.next()) {

                m_jsObj = new JSONObject();

                usr_role_type = _rs.getInt("user_has_role_type");
                user_has_role_type = "";

                if (usr_role_type == 0) {
                    user_has_role_type = RoleTypes.ROOT;
                }
                else if (usr_role_type == 1) {
                    user_has_role_type = RoleTypes.ADMINISTRATOR;
                } else if (usr_role_type == 2) {
                    user_has_role_type = RoleTypes.FINANCE_ADMINISTRATOR;
                } else if (usr_role_type == 3) {
                    user_has_role_type = RoleTypes.INPUTER;
                } else if (usr_role_type == 4) {
                    user_has_role_type = RoleTypes.AUTHORIZER;
                }else if (usr_role_type == 5) {
                    user_has_role_type = RoleTypes.FINANCE_AUTHORIZER;
                }

                m_jsObj.put("user_has_role_id", _rs.getInt("user_has_role_id"));
                m_jsObj.put("user_has_role_user", _rs.getInt("user_has_role_user"));
                m_jsObj.put("user_has_role_type_flag", _rs.getInt("user_has_role_type"));
                m_jsObj.put("user_has_role_status_flag", _rs.getInt("user_has_role_status_flag"));
                m_jsObj.put("user_NIC", _rs.getString("user_NIC"));
                m_jsObj.put("user_EPF", _rs.getInt("user_EPF"));
                m_jsObj.put("user_firstname", _rs.getString("user_firstname"));
                m_jsObj.put("user_lastname", _rs.getString("user_lastname"));
                m_jsObj.put("user_has_role_type", user_has_role_type);
                m_jsObj.put("user_username", _rs.getString("user_username"));
                log.info("logging attemp success : " + _rs.getString("user_username"));

                _jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {

            log.error(e);

        } finally {

            try {

                if (_rs != null) {
                    _rs.close();
                }

                if (_prep_statement_1 != null) {
                    _prep_statement_1.close();
                }

                if (_currentCon != null) {
                    _currentCon.close();
                }

            } catch (Exception e) {

                gcsm_responceHandler.setResponceModule("authentication");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("0001");
                gcsm_responceHandler.setResponceDescription("Error occured.!\n" + e);
                log.error(e);

            }

        }

        return _jsArr;

    }

}
