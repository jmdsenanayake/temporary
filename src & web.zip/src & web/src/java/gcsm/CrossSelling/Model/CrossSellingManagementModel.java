/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.CrossSelling.Model;

/**
 *
 * @author Janaka_5977
 */
public class CrossSellingManagementModel {
    private int cs_id;
    private int cs_own_company;
    private int cs_product_owner;
    private int cs_product;
    private String cs_product_status;
    private String cs_customer_name;
    private String cs_customer_nic;
    private String cs_customer_contactNo;
    private String cs_cid;    
    private double cs_fee;
    private String cs_emp_id;
    private String cs_employee_name;
    private String cs_units_sold_by;
    private String cs_date;
    private String cs_contract_no;
    private String cs_comment;
    private String cs_reject_reason;

    /**
     * @return the cs_id
     */
    public int getCs_id() {
        return cs_id;
    }

    /**
     * @param cs_id the cs_id to set
     */
    public void setCs_id(int cs_id) {
        this.cs_id = cs_id;
    }

    /**
     * @return the cs_own_company
     */
    public int getCs_own_company() {
        return cs_own_company;
    }

    /**
     * @param cs_own_company the cs_own_company to set
     */
    public void setCs_own_company(int cs_own_company) {
        this.cs_own_company = cs_own_company;
    }

    /**
     * @return the cs_product_owner
     */
    public int getCs_product_owner() {
        return cs_product_owner;
    }

    /**
     * @param cs_product_owner the cs_product_owner to set
     */
    public void setCs_product_owner(int cs_product_owner) {
        this.cs_product_owner = cs_product_owner;
    }

    /**
     * @return the cs_product
     */
    public int getCs_product() {
        return cs_product;
    }

    /**
     * @param cs_product the cs_product to set
     */
    public void setCs_product(int cs_product) {
        this.cs_product = cs_product;
    }

    /**
     * @return the cs_product_status
     */
    public String getCs_product_status() {
        return cs_product_status;
    }

    /**
     * @param cs_product_status the cs_product_status to set
     */
    public void setCs_product_status(String cs_product_status) {
        this.cs_product_status = cs_product_status;
    }

    /**
     * @return the cs_customer_name
     */
    public String getCs_customer_name() {
        return cs_customer_name;
    }

    /**
     * @param cs_customer_name the cs_customer_name to set
     */
    public void setCs_customer_name(String cs_customer_name) {
        this.cs_customer_name = cs_customer_name;
    }

    /**
     * @return the cs_customer_nic
     */
    public String getCs_customer_nic() {
        return cs_customer_nic;
    }

    /**
     * @param cs_customer_nic the cs_customer_nic to set
     */
    public void setCs_customer_nic(String cs_customer_nic) {
        this.cs_customer_nic = cs_customer_nic;
    }

    /**
     * @return the cs_cid
     */
    public String getCs_cid() {
        return cs_cid;
    }

    /**
     * @param cs_cid the cs_cid to set
     */
    public void setCs_cid(String cs_cid) {
        this.cs_cid = cs_cid;
    }

    /**
     * @return the cs_fee
     */
    public double getCs_fee() {
        return cs_fee;
    }

    /**
     * @param cs_fee the cs_fee to set
     */
    public void setCs_fee(double cs_fee) {
        this.cs_fee = cs_fee;
    }

    /**
     * @return the cs_emp_id
     */
    public String getCs_emp_id() {
        return cs_emp_id;
    }

    /**
     * @param cs_emp_id the cs_emp_id to set
     */
    public void setCs_emp_id(String cs_emp_id) {
        this.cs_emp_id = cs_emp_id;
    }

    /**
     * @return the cs_employee_name
     */
    public String getCs_employee_name() {
        return cs_employee_name;
    }

    /**
     * @param cs_employee_name the cs_employee_name to set
     */
    public void setCs_employee_name(String cs_employee_name) {
        this.cs_employee_name = cs_employee_name;
    }

    /**
     * @return the cs_units_sold_by
     */
    public String getCs_units_sold_by() {
        return cs_units_sold_by;
    }

    /**
     * @param cs_units_sold_by the cs_units_sold_by to set
     */
    public void setCs_units_sold_by(String cs_units_sold_by) {
        this.cs_units_sold_by = cs_units_sold_by;
    }

    /**
     * @return the cs_date
     */
    public String getCs_date() {
        return cs_date;
    }

    /**
     * @param cs_date the cs_date to set
     */
    public void setCs_date(String cs_date) {
        this.cs_date = cs_date;
    }

    /**
     * @return the cs_contract_no
     */
    public String getCs_contract_no() {
        return cs_contract_no;
    }

    /**
     * @param cs_contract_no the cs_contract_no to set
     */
    public void setCs_contract_no(String cs_contract_no) {
        this.cs_contract_no = cs_contract_no;
    }

    /**
     * @return the cs_comment
     */
    public String getCs_comment() {
        return cs_comment;
    }

    /**
     * @param cs_comment the cs_comment to set
     */
    public void setCs_comment(String cs_comment) {
        this.cs_comment = cs_comment;
    }

    /**
     * @return the cs_reject_reason
     */
    public String getCs_reject_reason() {
        return cs_reject_reason;
    }

    /**
     * @param cs_reject_reason the cs_reject_reason to set
     */
    public void setCs_reject_reason(String cs_reject_reason) {
        this.cs_reject_reason = cs_reject_reason;
    }

    /**
     * @return the cs_customer_contactNo
     */
    public String getCs_customer_contactNo() {
        return cs_customer_contactNo;
    }

    /**
     * @param cs_customer_contactNo the cs_customer_contactNo to set
     */
    public void setCs_customer_contactNo(String cs_customer_contactNo) {
        this.cs_customer_contactNo = cs_customer_contactNo;
    }

}
