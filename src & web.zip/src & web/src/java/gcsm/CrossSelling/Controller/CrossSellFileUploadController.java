/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.CrossSelling.Controller;

import gcsm.CrossSelling.DAO.CrossSellingManagementDAO;
import gcsm.CrossSelling.DAO.Impl.CrossSellingManagementDAOImpl;
import gcsm.CrossSelling.Model.CrossSellingManagementModel;
import gcsm.Utitlities.Model.ResponceHandler;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Janaka_5977
 */
public class CrossSellFileUploadController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JSONObject result = new JSONObject();
        String m_strfunction = "";
        PrintWriter out = response.getWriter();
        ResponceHandler responceHandler;
        JSONArray jsArr = null;
        HttpSession session = request.getSession(false);
        String username = session.getAttribute("session_username").toString();
        String roleType = session.getAttribute("session_role_type").toString();
        
        List<String> errorLines=new ArrayList<>();

        try {

            List<String> readLines = performFileReading(request);

            int totalLines = readLines.size();
            int enteredLines = 0;
            
            List<CrossSellingManagementModel> crossSellingManagementModelList=new ArrayList<>();
            for (String line : readLines) {

                CrossSellingManagementDAO crossSellingManagementDAO = new CrossSellingManagementDAOImpl();
                JSONObject data = new JSONObject();

                data.put("user_username", username);
                data.put("session_role_type", roleType);

                String[] lineDetails = line.split(",");
                String ownCompany = lineDetails[0].trim();
                int cs_own_company = crossSellingManagementDAO.getBusinessLineID(ownCompany);

                String prodOwner = lineDetails[1].trim();
                int cs_product_owner = crossSellingManagementDAO.getBusinessLineID(prodOwner);

                String product = lineDetails[2].trim();
                int cs_product = crossSellingManagementDAO.getProductID(product);

                String cs_product_status = lineDetails[3].trim();
                String cs_customer_name = lineDetails[4].trim();
                String cs_customer_nic = lineDetails[5].isEmpty()||lineDetails[5].equals("")?"":lineDetails[5].trim();
                String cs_customer_contactNo = lineDetails[6].isEmpty()||lineDetails[6].equals("")?"":lineDetails[6].trim();
                String cs_cid = lineDetails[7].isEmpty()||lineDetails[7].equals("")?"":lineDetails[7].trim();
                
                String regex = "(?<=[\\d])(,)(?=[\\d])";
                Pattern p = Pattern.compile(regex);       
                String cs_fee_String = (lineDetails[8].isEmpty()||lineDetails[8].equals("")?"0":lineDetails[8].trim());
                Matcher m = p.matcher(cs_fee_String);
                cs_fee_String = m.replaceAll("");                
                double cs_fee = Double.parseDouble(cs_fee_String);
                
                String cs_emp_id = lineDetails[9].isEmpty()||lineDetails[9].equals("")?"":lineDetails[9].trim();
                String cs_employee_name = lineDetails[10].isEmpty()||lineDetails[10].equals("")?"":lineDetails[10].trim();
                String cs_units_sold_by = lineDetails[11].isEmpty()||lineDetails[1].equals("")?"":lineDetails[11].trim();
                String cs_date = lineDetails[12].trim();
                String cs_contract_no = lineDetails[13].isEmpty()||lineDetails[13].equals("")?"":lineDetails[13].trim();
                //solving comment field not reading since blank
                String cs_comment = lineDetails.length==14?"":lineDetails[14].trim();

                data.put("cs_own_company", cs_own_company);
                data.put("cs_product_owner", cs_product_owner);
                data.put("cs_product", cs_product);
                data.put("cs_product_status", cs_product_status);
                data.put("cs_customer_name", cs_customer_name);
                data.put("cs_customer_nic", cs_customer_nic);
                data.put("cs_customer_contactNo", cs_customer_contactNo);
                data.put("cs_cid", cs_cid);
                data.put("cs_fee", cs_fee);
                data.put("cs_emp_id", cs_emp_id);
                data.put("cs_employee_name", cs_employee_name);
                data.put("cs_units_sold_by", cs_units_sold_by);
                data.put("cs_date", cs_date);
                data.put("cs_contract_no", cs_contract_no);
                data.put("cs_comment", cs_comment);

                responceHandler=crossSellingManagementDAO.saveCrossSellingData(data);
                
                if (responceHandler.getResponceType().equals("success")) {
                    enteredLines++;
                } else {
                    errorLines.add(line);                    
                }    
//                CrossSellingManagementModel crossSellingManagementModel=new CrossSellingManagementModel();
//                crossSellingManagementModel.setCs_own_company(cs_own_company);
//                crossSellingManagementModel.setCs_own_company(cs_product_owner);
//                crossSellingManagementModel.setCs_own_company(cs_product);
//                crossSellingManagementModel.setCs_product_status(cs_product_status);
//                crossSellingManagementModel.setCs_customer_name(cs_customer_name);
//                crossSellingManagementModel.setCs_customer_nic(cs_customer_nic);
//                crossSellingManagementModel.setCs_customer_contactNo(cs_customer_contactNo);
//                crossSellingManagementModel.setCs_cid(cs_cid);
//                crossSellingManagementModel.setCs_fee(cs_fee);
//                crossSellingManagementModel.setCs_emp_id(cs_emp_id);
//                crossSellingManagementModel.setCs_employee_name(cs_employee_name);
//                crossSellingManagementModel.setCs_units_sold_by(cs_units_sold_by);
//                crossSellingManagementModel.setCs_date(cs_date);
//                crossSellingManagementModel.setCs_contract_no(cs_contract_no);
//                crossSellingManagementModel.setCs_comment(cs_comment);
//                
//                crossSellingManagementModelList.add(crossSellingManagementModel);
//                
            }
//            
//            CrossSellingManagementDAO crossSellingManagementDAO = new CrossSellingManagementDAOImpl();
//            crossSellingManagementDAO.saveCrossSellingBulkData(crossSellingManagementModelList,username);
            
            if (errorLines.isEmpty()) {
                    result.put("success", "Awesome! You were successful. "+enteredLines+" records uploaded");
                    out.print(result);
                } else {
                StringBuilder allErrorLines=new StringBuilder();
                    for(String errorLineString:errorLines){
                        allErrorLines.append(errorLineString).append("\n");
                    }
                    result.put("error", enteredLines+" out of "+ totalLines+" uploaded. Error Occured When Entering Following Lines\n"+allErrorLines);
                    out.print(result);
                }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private List<String> performFileReading(HttpServletRequest request) {
        List<String> readLines = new ArrayList<>();

        try {

            String contentType = request.getContentType();
            DataInputStream in = new DataInputStream(request.getInputStream());
            int formDataLength = request.getContentLength();
            byte dataBytes[] = new byte[formDataLength];
            int byteRead = 0;
            int totalBytesRead = 0;

            while (totalBytesRead < formDataLength) {
                byteRead = in.read(dataBytes, totalBytesRead, formDataLength);
                totalBytesRead += byteRead;
            }

            String file = new String(dataBytes);
            System.out.println("#################");
            System.out.println(file);
            String saveFile = file.substring(file.indexOf("filename=\"") + 10);
            saveFile = saveFile.substring(saveFile.lastIndexOf("\\") + 1, saveFile.indexOf("\""));
            saveFile = file.substring(file.indexOf("filename=\"") + 10);
            saveFile = saveFile.substring(0, saveFile.indexOf("\n"));
            saveFile = saveFile.substring(saveFile.lastIndexOf("\\") + 1, saveFile.indexOf("\""));
            int lastIndex = contentType.lastIndexOf("=");
            String boundary = contentType.substring(lastIndex + 1, contentType.length());
            int pos;

            pos = file.indexOf("filename=\"");
            pos = file.indexOf("\n", pos) + 1;
            pos = file.indexOf("\n", pos) + 1;
            pos = file.indexOf("\n", pos) + 1;
            int boundaryLocation = file.indexOf(boundary, pos) - 4;
            int startPos = ((file.substring(0, pos)).getBytes()).length;
            int endPos = ((file.substring(0, boundaryLocation)).getBytes()).length;

            FileOutputStream fileOut = new FileOutputStream(saveFile);
            fileOut.write(dataBytes, startPos, (endPos - startPos));
            String line = null;
            try {
                BufferedReader input = new BufferedReader(new FileReader(saveFile));
                while ((line = input.readLine()) != null) {
                    if (!(line.toLowerCase().contains("own"))) {
                        readLines.add(line);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return readLines;

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
