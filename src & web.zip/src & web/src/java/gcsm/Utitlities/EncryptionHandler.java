/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Utitlities;

/**
 *
 * @author Randika_10992
 */
public interface EncryptionHandler {

    public abstract String encrypt(String inputText);

    public abstract String decrypt(String inputText);

    public abstract byte[] func_encrypt(int cipherMode, String key, String inputText);

    public abstract String func_decrypt(int cipherMode, String key, byte[] inputBytes);

}
