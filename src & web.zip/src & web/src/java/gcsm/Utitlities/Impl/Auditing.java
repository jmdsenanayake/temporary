/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Utitlities.Impl;

import gcsm.Utitlities.Model.Specification;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Janaka_5977
 */
public class Auditing {

    static DatabaseConnection databaseConnection;
    static Connection currentConnection = null;
    private PreparedStatement preparedStatement = null;    
    
    public Map<String,String> getAllRecords(String id,String table){
        
        String primaryKey=getPrimaryKeyNameOfTable(table);
        List<String> columnNames=getAllColumnNames(table);
        Map<String,String> keyValue=new LinkedHashMap<>();
        
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        
        ResultSet resultSet = null;

        try {
            if (!databaseConnection.start_Connection(currentConnection)) {

            } else {
                String sql = "SELECT * from "+table+" where "+primaryKey+"='"+id+"'";
                
                System.out.println(sql);
                
                preparedStatement = currentConnection.prepareStatement(sql);
              
                resultSet = preparedStatement.executeQuery();

                while (resultSet.next()) {
                    for(String columnName:columnNames){
                        keyValue.put(columnName, resultSet.getString(columnName));
                    }
                    
                }
            }

            databaseConnection.end_Connection(currentConnection);

        } catch (Exception e) {
            e.printStackTrace();

        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
//                if (preparedStatement != null) {
//                    preparedStatement.close();
//                }
//                if (currentConnection != null) {
//                    currentConnection.close();
//                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
        return keyValue;       
    }
    
    /**
     *
     * @param current_user
     * @param related_table
     * @param dml_type
     * @param record_pk
     * @param previous_value
     * @param new_value
     */
    public void saveAuditRecord(String current_user,String related_table, String dml_type, String record_pk, String previous_value, String new_value){
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {
            if (databaseConnection.start_Connection(currentConnection)) {
                String queryInsertRecord
                        = "INSERT INTO gcsm_auditing("
                        + "`current_timestamp`,"
                        + "`current_user`," //1
                        + "related_table," //2
                        + "dml_type," //3
                        + "record_pk," //4                        
                        + "previous_value," //5
                        + "new_value)" //6
                        + " VALUES(now(),?,?,?,?,?,?)";

                preparedStatement = currentConnection.prepareStatement(queryInsertRecord);

                preparedStatement.setString(1, current_user);
                preparedStatement.setString(2, related_table);
                preparedStatement.setString(3, dml_type);
                preparedStatement.setString(4, record_pk);
                preparedStatement.setString(5, previous_value);
                preparedStatement.setString(6, new_value);
                System.out.println(preparedStatement);
                int executeUpdate = preparedStatement.executeUpdate();
                System.out.println("executeupdate : " + executeUpdate);                
            }

            databaseConnection.end_Connection(currentConnection);
        } catch (Exception e) {
            e.printStackTrace();         

        } finally {

            try {             

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                e.printStackTrace();            

            }
        }        
        
    }
    
    
    
    private String getPrimaryKeyNameOfTable(String table){
        String primaryKey="";
        
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        
        ResultSet resultSet = null;

        try {
            if (!databaseConnection.start_Connection(currentConnection)) {

            } else {
                String sql = "SELECT `COLUMN_NAME`\n" +
                                "FROM `information_schema`.`COLUMNS`\n" +
                                "WHERE (`TABLE_SCHEMA` = 'gcsm_db_myuat')\n" +
                                "  AND (`TABLE_NAME` = '"+table+"')\n" +
                                "  AND (`COLUMN_KEY` = 'PRI')";
                
                preparedStatement = currentConnection.prepareStatement(sql);
              
                resultSet = preparedStatement.executeQuery();

                while (resultSet.next()) {
                    primaryKey = resultSet.getString("COLUMN_NAME");
                }
            }

            databaseConnection.end_Connection(currentConnection);

        } catch (Exception e) {
            e.printStackTrace();

        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (currentConnection != null) {
                    currentConnection.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
        return primaryKey;
        
    }
    
    private List<String> getAllColumnNames(String table){
        
        List<String> columnNames=new ArrayList<>();
        
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        
        ResultSet resultSet = null;

        try {
            if (!databaseConnection.start_Connection(currentConnection)) {

            } else {
                String sql = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '"+table+"'";
                
                preparedStatement = currentConnection.prepareStatement(sql);
              
                resultSet = preparedStatement.executeQuery();

                while (resultSet.next()) {
                    columnNames.add(resultSet.getString("COLUMN_NAME"));
                }
            }

            databaseConnection.end_Connection(currentConnection);

        } catch (Exception e) {
            e.printStackTrace();

        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (currentConnection != null) {
                    currentConnection.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
        return columnNames;       
    }   

}
