/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Utitlities.Impl;

import gcsm.Utitlities.Model.Specification;
import gcsm.Utitlities.SQLServerDatabaseConnectionHandler;
import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Janaka_5977
 */
public class SQLServerDatabaseConnection implements SQLServerDatabaseConnectionHandler{
    
    private final String sqlserver_db_Driver;
    private final String sqlserver_db_URL;
    private final String sqlserver_db_Server;
    private final String sqlserver_db_Name;
    private final String sqlserver_db_UserName;
    private final String sqlserver_db_Password;
    private final Specification specification;
    private static SQLServerDatabaseConnection sqlServerDatabaseConnection;

    public SQLServerDatabaseConnection() {
        
        specification = Specification.getInstance();

        sqlserver_db_Driver = specification.getSqlserver_db_Driver();
        sqlserver_db_URL = specification.getSqlserver_db_URL();
        sqlserver_db_Server = specification.getSqlserver_db_Server();
        sqlserver_db_Name = specification.getSqlserver_db_Name();
        sqlserver_db_UserName = specification.getSqlserver_db_UserName();
        sqlserver_db_Password = specification.getSqlserver_db_Password();
    }
    
    

    @Override
    public Connection get_JDBC_Connection() {
        Connection connection = null;

        try {

            Class.forName(sqlserver_db_Driver);
            connection = DriverManager.getConnection((new StringBuilder(String.valueOf(sqlserver_db_URL))).append(sqlserver_db_Server).append(sqlserver_db_Name).toString(), sqlserver_db_UserName, sqlserver_db_Password);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return connection;
    }

    @Override
    public boolean start_Connection(Connection con) {
         boolean success = false;

        try {

            if (!con.getAutoCommit()) {
                con.rollback();
                con.setAutoCommit(true);
            }

            con.setAutoCommit(false);
            success = true;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return success;
        
    }

    @Override
    public boolean end_Connection(Connection con) {
        boolean success = false;

        try {
            if (!con.getAutoCommit()) {
                con.commit();
                con.setAutoCommit(true);
            }
            success = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return success;
    }

    @Override
    public boolean restart_Connection(Connection con) {
        boolean success = false;

        try {

            if (!con.getAutoCommit()) {
                con.commit();
                con.setAutoCommit(true);
            }
            if (!con.getAutoCommit()) {

                con.rollback();
                con.setAutoCommit(true);
            }

            con.setAutoCommit(false);
            success = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return success;
    }

    @Override
    public boolean abort_Connection(Connection con) {
        boolean success = false;

        try {
            if (!con.getAutoCommit()) {
                con.rollback();
                con.setAutoCommit(true);
            }
            success = true;
        } catch (Exception e) {

        }

        return success;
    }
    
    public static synchronized SQLServerDatabaseConnection getInstance() {

        if (sqlServerDatabaseConnection == null) {
            sqlServerDatabaseConnection = new SQLServerDatabaseConnection();
        }
        return sqlServerDatabaseConnection;
    }    
}
