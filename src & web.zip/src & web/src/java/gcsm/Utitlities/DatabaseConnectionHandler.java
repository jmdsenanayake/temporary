/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Utitlities;

import java.sql.Connection;

/**
 *
 * @author Randika_10992
 */
public interface DatabaseConnectionHandler {    
    
    public abstract Connection get_JDBC_Connection();

    public abstract boolean start_Connection(Connection con);

    public abstract boolean end_Connection(Connection con);

    public abstract boolean restart_Connection(Connection con);

    public abstract boolean abort_Connection(Connection con);

}
