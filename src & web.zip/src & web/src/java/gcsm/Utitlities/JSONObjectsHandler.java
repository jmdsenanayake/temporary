/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Utitlities;

import gcsm.Administration.Model.BusinessEntityModel;
import gcsm.Administration.Model.ProductModel;
import gcsm.Administration.Model.UserModel;
import gcsm.Administration.Model.UsersRoleModel;
import gcsm.CrossSelling.Model.CrossSellingManagementModel;
import gcsm.CrossSelling.Model.ShadowRevenueModel;
import gcsm.RewardsHandling.Model.IndividualTargetAchievementModel;
import gcsm.PointsHandling.Model.PointValuesModel;
import gcsm.RewardsHandling.Model.RewardsValuesModel;

/**
 *
 * @author Madhawa_4799
 */
public interface JSONObjectsHandler {
   
    public BusinessEntityModel convertBusinessEntityModelToJSON(String jsonStr);     
    public UserModel convertUserModelToJSON(String jsonStr);
    public UsersRoleModel convertUserRoleModelToJSON(String jsonStr);
    public ProductModel convertProductModelToJSON(String jsonStr);
    public CrossSellingManagementModel convertCrossSellingManagementModelToJSON(String jsonStr);    
    public ShadowRevenueModel convertShadowRevenueModelToJSON(String jsonStr); 
    public RewardsValuesModel convertRewardsValuesModelToJSON(String jsonStr);  
    public PointValuesModel convertPointValuesModelToJSON(String jsonStr);  
    public IndividualTargetAchievementModel convertIndividualTargetAchievementModelToJSON(String jsonStr);
   
}
