/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Utitlities.Model;

/**
 *
 * @author Janaka_5977
 */
public class RoleTypes {
    public static final String ROOT="Root";                                     //role_type=0
    public static final String ADMINISTRATOR="Administrator";                   //role_type=1
    public static final String FINANCE_ADMINISTRATOR="Finance Administrator";   //role_type=2
    public static final String INPUTER="Inputer";                               //role_type=3
    public static final String AUTHORIZER="Authorizer";                         //role_type=4
    public static final String FINANCE_AUTHORIZER="Finance Authorizer";         //role_type=5
}