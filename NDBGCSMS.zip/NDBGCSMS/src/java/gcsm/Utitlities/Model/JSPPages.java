/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Utitlities.Model;

/**
 *
 * @author Janaka_5977
 */
public class JSPPages {

    public static final String[] PAGES = {        
        "User Roles",
        "Users",
        "Business Entities",
        "Products",
        "Cross Selling Management",
        "Other Contract Values Upload",
        "Other Shadow Revenue Basis Amounts",
        "Shadow Revenue",
        "Reward Values",
        "Manage Individual Target Achievement",
        "Calculate Rewards",
        "Point Values",      
        "Calculate Points",
        "Reports"
    };
}
