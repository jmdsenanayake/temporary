/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Utitlities.Model;

import gcsm.Utitlities.Impl.Encryption;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ResourceBundle;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 *
 * @author Randika_10992
 */
public class Specification {
    
    static Logger log = LogManager.getLogger(Specification.class.getName());

    private static String db_Driver;
    private static String db_URL;
    private static String db_Server;
    private static String db_Name;
    private static String db_UserNameFilePath;
    private static String db_PasswordFilePath;
    private static String db_UserName;
    private static String db_Password;
    private static String sys_mainDirectory;
    
    private static Specification specification = null;
    private static ResourceBundle resourceBundle;
    private static Encryption gcsm_encryption;
    
    private String sqlserver_db_Driver;
    private String sqlserver_db_URL;
    private String sqlserver_db_Server;
    private String sqlserver_db_Name;
    private String sqlserver_db_UserNameFilePath;
    private String sqlserver_db_PasswordFilePath;
    private String sqlserver_db_UserName;
    private String sqlserver_db_Password;

    /**
     * @return the db_Driver
     */
    public static String getDb_Driver() {
        return db_Driver;
    }

    /**
     * @param aDb_Driver the db_Driver to set
     */
    public static void setDb_Driver(String aDb_Driver) {
        db_Driver = aDb_Driver;
    }

    /**
     * @return the db_URL
     */
    public static String getDb_URL() {
        return db_URL;
    }

    /**
     * @param aDb_URL the db_URL to set
     */
    public static void setDb_URL(String aDb_URL) {
        db_URL = aDb_URL;
    }

    /**
     * @return the db_Server
     */
    public static String getDb_Server() {
        return db_Server;
    }

    /**
     * @param aDb_Server the db_Server to set
     */
    public static void setDb_Server(String aDb_Server) {
        db_Server = aDb_Server;
    }

    /**
     * @return the db_Name
     */
    public static String getDb_Name() {
        return db_Name;
    }

    /**
     * @param aDb_Name the db_Name to set
     */
    public static void setDb_Name(String aDb_Name) {
        db_Name = aDb_Name;
    }

    /**
     * @return the db_UserNameFilePath
     */
    public static String getDb_UserNameFilePath() {
        return db_UserNameFilePath;
    }

    /**
     * @param aDb_UserNameFilePath the db_UserNameFilePath to set
     */
    public static void setDb_UserNameFilePath(String aDb_UserNameFilePath) {
        db_UserNameFilePath = aDb_UserNameFilePath;
    }

    /**
     * @return the db_PasswordFilePath
     */
    public static String getDb_PasswordFilePath() {
        return db_PasswordFilePath;
    }

    /**
     * @param aDb_PasswordFilePath the db_PasswordFilePath to set
     */
    public static void setDb_PasswordFilePath(String aDb_PasswordFilePath) {
        db_PasswordFilePath = aDb_PasswordFilePath;
    }

    /**
     * @return the db_UserName
     */
    public static String getDb_UserName() {
        return db_UserName;
    }

    /**
     * @param aDb_UserName the db_UserName to set
     */
    public static void setDb_UserName(String aDb_UserName) {
        db_UserName = aDb_UserName;
    }

    /**
     * @return the db_Password
     */
    public static String getDb_Password() {
        return db_Password;
    }

    /**
     * @param aDb_Password the db_Password to set
     */
    public static void setDb_Password(String aDb_Password) {
        db_Password = aDb_Password;
    }

    /**
     * @return the sys_mainDirectory
     */
    public static String getSys_mainDirectory() {
        return sys_mainDirectory;
    }

    /**
     * @param aSys_mainDirectory the sys_mainDirectory to set
     */
    public static void setSys_mainDirectory(String aSys_mainDirectory) {
        sys_mainDirectory = aSys_mainDirectory;
    }

    /**
     * @return the resourceBundle
     */
    public static ResourceBundle getResourceBundle() {
        return resourceBundle;
    }

    /**
     * @param aResourceBundle the resourceBundle to set
     */
    public static void setResourceBundle(ResourceBundle aResourceBundle) {
        resourceBundle = aResourceBundle;
    }

    public Specification() {
        
        try {
            
            get_Properties();
            
            String encryptedUsername = "";
            String encryptedPassword = "";
            
            FileInputStream fileInputStream_username = new FileInputStream(new File(db_UserNameFilePath));
            BufferedReader bufferedReader_usrname = new BufferedReader(new InputStreamReader(fileInputStream_username));
            encryptedUsername = bufferedReader_usrname.readLine();
            
            FileInputStream fileInputStream_password = new FileInputStream(new File(db_PasswordFilePath));
            BufferedReader bufferedReader_password = new BufferedReader(new InputStreamReader(fileInputStream_password));
            encryptedPassword = bufferedReader_password.readLine();
            
            gcsm_encryption = new Encryption();
            
            String temp_username = "";
            String temp_password = "";
            
            temp_username = gcsm_encryption.decrypt(encryptedUsername);
            temp_password = gcsm_encryption.decrypt(encryptedPassword);
            
            db_UserName = temp_username;
            db_Password = temp_password;    
            
            
            String sqlserver_encryptedUsername = "";
            String sqlserver_encryptedPassword = "";
            
            FileInputStream fileInputStream_sqlserver_username = new FileInputStream(new File(sqlserver_db_UserNameFilePath));
            BufferedReader bufferedReader_sqlserver_usrname = new BufferedReader(new InputStreamReader(fileInputStream_sqlserver_username));
            sqlserver_encryptedUsername = bufferedReader_sqlserver_usrname.readLine();
            
            FileInputStream fileInputStream_sqlserver_password = new FileInputStream(new File(sqlserver_db_PasswordFilePath));
            BufferedReader bufferedReader_sqlserver_password = new BufferedReader(new InputStreamReader(fileInputStream_sqlserver_password));
            sqlserver_encryptedPassword = bufferedReader_sqlserver_password.readLine();
            
            String temp_sqlserver_username = "";
            String temp_sqlserver_password = "";
            
            temp_sqlserver_username = gcsm_encryption.decrypt(sqlserver_encryptedUsername);
            temp_sqlserver_password = gcsm_encryption.decrypt(sqlserver_encryptedPassword);
            
            sqlserver_db_UserName = temp_sqlserver_username;
            sqlserver_db_Password = temp_sqlserver_password;    
            
        } catch (Exception e) {
            log.error(e.getMessage());
        }

    }

    public boolean get_Properties() {

        try {

            resourceBundle = ResourceBundle.getBundle("gcsm_config");

            db_Driver = resourceBundle.getString("DB_DRIVER").trim();
            db_URL = resourceBundle.getString("DB_URL").trim();
            db_Server = resourceBundle.getString("DB_SERVER").trim();
            db_Name = resourceBundle.getString("DB_NAME").trim();
            
            sys_mainDirectory = resourceBundle.getString("SYS_MAINDIRECTORY").trim();

            db_UserNameFilePath = resourceBundle.getString("DB_USERNAMEFILEPATH").trim();
            db_PasswordFilePath = resourceBundle.getString("DB_PASSWORDFILEPATH").trim();

            db_UserNameFilePath = (new StringBuilder(String.valueOf(sys_mainDirectory))).append(resourceBundle.getString("DB_USERNAMEFILEPATH")).toString();
            db_PasswordFilePath = (new StringBuilder(String.valueOf(sys_mainDirectory))).append(resourceBundle.getString("DB_PASSWORDFILEPATH")).toString();
            
            sqlserver_db_Driver = resourceBundle.getString("SQLSERVER_DB_DRIVER").trim();
            sqlserver_db_URL = resourceBundle.getString("SQLSERVER_DB_URL").trim();
            sqlserver_db_Server = resourceBundle.getString("SQLSERVER_DB_SERVER").trim();
            sqlserver_db_Name = resourceBundle.getString("SQLSERVER_DB_NAME").trim();
            
            sqlserver_db_UserNameFilePath = resourceBundle.getString("SQLSERVER_DB_USERNAMEFILEPATH").trim();
            sqlserver_db_PasswordFilePath = resourceBundle.getString("SQLSERVER_DB_PASSWORDFILEPATH").trim();

            sqlserver_db_UserNameFilePath = (new StringBuilder(String.valueOf(sys_mainDirectory))).append(resourceBundle.getString("SQLSERVER_DB_USERNAMEFILEPATH")).toString();
            sqlserver_db_PasswordFilePath = (new StringBuilder(String.valueOf(sys_mainDirectory))).append(resourceBundle.getString("SQLSERVER_DB_PASSWORDFILEPATH")).toString();

            return true;

        } catch (Exception e) {

            log.error(e.getMessage());
            return false;
        }
        
    }

    public static synchronized Specification getInstance() {

        if (specification == null) {
            specification = new Specification();
        }

        return specification;
    }

    /**
     * @return the sqlserver_db_Driver
     */
    public String getSqlserver_db_Driver() {
        return sqlserver_db_Driver;
    }

    /**
     * @return the sqlserver_db_URL
     */
    public String getSqlserver_db_URL() {
        return sqlserver_db_URL;
    }

    /**
     * @return the sqlserver_db_Server
     */
    public String getSqlserver_db_Server() {
        return sqlserver_db_Server;
    }

    /**
     * @return the sqlserver_db_Name
     */
    public String getSqlserver_db_Name() {
        return sqlserver_db_Name;
    }

    /**
     * @return the sqlserver_db_UserNameFilePath
     */
    public String getSqlserver_db_UserNameFilePath() {
        return sqlserver_db_UserNameFilePath;
    }

    /**
     * @return the sqlserver_db_PasswordFilePath
     */
    public String getSqlserver_db_PasswordFilePath() {
        return sqlserver_db_PasswordFilePath;
    }

    /**
     * @return the sqlserver_db_UserName
     */
    public String getSqlserver_db_UserName() {
        return sqlserver_db_UserName;
    }

    /**
     * @return the sqlserver_db_Password
     */
    public String getSqlserver_db_Password() {
        return sqlserver_db_Password;
    }

}
