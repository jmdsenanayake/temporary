/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Utitlities.Model;

/**
 *
 * @author Randika_10992
 */
public class ResponceHandler {

    private String responceModule;
    private String responceType;
    private String responceCode;
    private String responceDescription;

    /**
     * @return the responceModule
     */
    public String getResponceModule() {
        return responceModule;
    }

    /**
     * @param responceModule the responceModule to set
     */
    public void setResponceModule(String responceModule) {
        this.responceModule = responceModule;
    }

    /**
     * @return the responceType
     */
    public String getResponceType() {
        return responceType;
    }

    /**
     * @param responceType the responceType to set
     */
    public void setResponceType(String responceType) {
        this.responceType = responceType;
    }

    /**
     * @return the responceCode
     */
    public String getResponceCode() {
        return responceCode;
    }

    /**
     * @param responceCode the responceCode to set
     */
    public void setResponceCode(String responceCode) {
        this.responceCode = responceCode;
    }

    /**
     * @return the responceDescription
     */
    public String getResponceDescription() {
        return responceDescription;
    }

    /**
     * @param responceDescription the responceDescription to set
     */
    public void setResponceDescription(String responceDescription) {
        this.responceDescription = responceDescription;
    }
     

}
