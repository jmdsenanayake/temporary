/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Utitlities.Impl;

import gcsm.Utitlities.EncryptionHandler;
import java.security.Key;
import java.util.ResourceBundle;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

/**
 *
 * @author Randika_10992
 */
public class Encryption implements EncryptionHandler {
    static Logger log = LogManager.getLogger(Encryption.class.getName());

    private static ResourceBundle resourceBundle;

    @Override
    public String encrypt(String inputText) {

        String text_encrypt = "";
        try {

            byte[] ecryptedByteArray = func_encrypt(Cipher.ENCRYPT_MODE, get_encryption_key(), inputText);
            text_encrypt = new BASE64Encoder().encode(ecryptedByteArray);

            return text_encrypt;

        } catch (Exception e) {
            log.error(e.getMessage());
        }

        return text_encrypt;
    }

    @Override
    public String decrypt(String inputText) {

        String text_decrypt = "";
        try {

            byte[] BASE64decodedbytearray = (new BASE64Decoder()).decodeBuffer(inputText);
            text_decrypt = func_decrypt(Cipher.DECRYPT_MODE, get_encryption_key(), BASE64decodedbytearray);

        } catch (Exception e) {
            log.error(e.getMessage());
        }

        return text_decrypt;
    }

    @Override
    public byte[] func_encrypt(int cipherMode, String key, String inputText) {

        try {

            Key secretKey = new SecretKeySpec(key.getBytes(), get_encryption_algorithm());
            Cipher cipher = Cipher.getInstance(get_encryption_algorithm());
            cipher.init(cipherMode, secretKey);

            byte[] byteCipherText = cipher.doFinal(inputText.getBytes());
            return byteCipherText;

        } catch (Exception e) {

            log.error(e.getMessage());
        }

        return null;
    }

    @Override
    public String func_decrypt(int cipherMode, String key, byte[] inputBytes) {

        try {

            Key secretKey = new SecretKeySpec(key.getBytes(), get_encryption_algorithm());
            Cipher cipher = Cipher.getInstance(get_encryption_algorithm());
            cipher.init(cipherMode, secretKey);

            byte[] byteCipherText = cipher.doFinal(inputBytes);
            return new String(byteCipherText);

        } catch (Exception e) {

            log.error(e.getMessage());
        }

        return null;
    }

    private String get_encryption_key() {
        
        resourceBundle = ResourceBundle.getBundle("gcsm_config");
        String KEY = resourceBundle.getString("ENCRYPTION_KEY");
        
        return KEY;
    }

    private String get_encryption_algorithm() {

        resourceBundle = ResourceBundle.getBundle("gcsm_config");
        String ALGORITHM = resourceBundle.getString("ENCRYPTION_ALGORITHM");

        return ALGORITHM;
    }

    public static void main(String[] args) {

        Encryption e = new Encryption();

        System.out.println(e.encrypt("1234"));
        System.out.println(e.decrypt("CtFTmRDXIzMgpkVa2SYlVu4i+h88wI357PvSx82VFHs="));

    }

}
