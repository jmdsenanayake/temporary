/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Utitlities.Impl;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import gcsm.Utitlities.JSONObjectsHandler;
import gcsm.Administration.Model.BusinessEntityModel;
import gcsm.Administration.Model.ProductModel;
import gcsm.Administration.Model.UserManagementModel;
import gcsm.Administration.Model.UserModel;
import gcsm.Administration.Model.UsersRoleModel;
import gcsm.CrossSelling.Model.CrossSellingManagementModel;
import gcsm.CrossSelling.Model.ShadowRevenueModel;
import gcsm.RewardsHandling.Model.IndividualTargetAchievementModel;
import gcsm.PointsHandling.Model.PointValuesModel;
import gcsm.RewardsHandling.Model.RewardsValuesModel;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 *
 * @author Randika_10992
 */
public class JSONObjects implements JSONObjectsHandler {
    
    static Logger log = LogManager.getLogger(JSONObjects.class.getName());

    @Override
    public BusinessEntityModel convertBusinessEntityModelToJSON(String jsonStr) {

        BusinessEntityModel businessEntityModel = new BusinessEntityModel();
        try {

            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false); //ignore unrecognized fields in the Json String using ObjectMapper lib
            businessEntityModel = objectMapper.readValue(jsonStr, BusinessEntityModel.class); //Map Json String to pre-defined object

        } catch (Exception e) {
            log.error(e.getMessage());
        }

        return businessEntityModel;
    }

    @Override
    public CrossSellingManagementModel convertCrossSellingManagementModelToJSON(String jsonStr) {
        CrossSellingManagementModel crossSellingManagementModel = new CrossSellingManagementModel();
        try {

            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false); //ignore unrecognized fields in the Json String using ObjectMapper lib
            crossSellingManagementModel = objectMapper.readValue(jsonStr, CrossSellingManagementModel.class); //Map Json String to pre-defined object

        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return crossSellingManagementModel;

    }
    
     @Override
    public ShadowRevenueModel convertShadowRevenueModelToJSON(String jsonStr) {
        ShadowRevenueModel shadowRevenueModel = new ShadowRevenueModel();
        try {

            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false); //ignore unrecognized fields in the Json String using ObjectMapper lib
            shadowRevenueModel = objectMapper.readValue(jsonStr, ShadowRevenueModel.class); //Map Json String to pre-defined object

        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return shadowRevenueModel;

    }

    @Override
    public UserModel convertUserModelToJSON(String jsonStr) {
        UserModel userModel = new UserModel();
        try {

            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false); //ignore unrecognized fields in the Json String using ObjectMapper lib
            userModel = objectMapper.readValue(jsonStr, UserModel.class); //Map Json String to pre-defined object

        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return userModel;

    }

    @Override
    public UsersRoleModel convertUserRoleModelToJSON(String jsonStr) {

        UsersRoleModel userRoleMode = new UsersRoleModel();
        try {

            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false); //ignore unrecognized fields in the Json String using ObjectMapper lib
            userRoleMode = objectMapper.readValue(jsonStr, UsersRoleModel.class); //Map Json String to pre-defined object

        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return userRoleMode;

    }

    @Override
    public ProductModel convertProductModelToJSON(String jsonStr) {
        
        ProductModel productModel = new ProductModel();
        try {

            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false); //ignore unrecognized fields in the Json String using ObjectMapper lib
            productModel = objectMapper.readValue(jsonStr, ProductModel.class); //Map Json String to pre-defined object

        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return productModel;
        
    }
    
    @Override
    public RewardsValuesModel convertRewardsValuesModelToJSON(String jsonStr) {
        RewardsValuesModel rewardsValuesModel = new RewardsValuesModel();
        try {

            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false); //ignore unrecognized fields in the Json String using ObjectMapper lib
            rewardsValuesModel = objectMapper.readValue(jsonStr, RewardsValuesModel.class); //Map Json String to pre-defined object

        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return rewardsValuesModel;

    }

    @Override
    public PointValuesModel convertPointValuesModelToJSON(String jsonStr) {
        PointValuesModel pointValuesModel=new PointValuesModel();
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false); //ignore unrecognized fields in the Json String using ObjectMapper lib
            pointValuesModel = objectMapper.readValue(jsonStr, PointValuesModel.class); //Map Json String to pre-defined object

        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return pointValuesModel;
    }
    
    @Override
    public IndividualTargetAchievementModel convertIndividualTargetAchievementModelToJSON(String jsonStr) {
        IndividualTargetAchievementModel individualTargetAchievementModel=new IndividualTargetAchievementModel();
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false); //ignore unrecognized fields in the Json String using ObjectMapper lib
            individualTargetAchievementModel = objectMapper.readValue(jsonStr, IndividualTargetAchievementModel.class); //Map Json String to pre-defined object

        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return individualTargetAchievementModel;
    }

    public UserManagementModel convertUserManagementModelToJSON(String jsonStr) {
        UserManagementModel userManagementModel = new UserManagementModel();
        try {

            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false); //ignore unrecognized fields in the Json String using ObjectMapper lib
            userManagementModel = objectMapper.readValue(jsonStr, UserManagementModel.class); //Map Json String to pre-defined object

        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return userManagementModel;
    }

}
