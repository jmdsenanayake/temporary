/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Utitlities.Impl;

import gcsm.Utitlities.DatabaseConnectionHandler;
import gcsm.Utitlities.Model.Specification;
import java.sql.Connection;
import java.sql.DriverManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 *
 * @author Randika_10992
 */
public class DatabaseConnection implements DatabaseConnectionHandler {

    private static String db_Driver;
    private static String db_URL;
    private static String db_Server;
    private static String db_Name;
    private static String db_UserName;
    private static String db_Password;
    private static Specification specification;
    private static DatabaseConnection database_Connection;
    
    static Logger log = LogManager.getLogger(DatabaseConnection.class.getName());

    public DatabaseConnection() {

        specification = Specification.getInstance();

        db_Driver = Specification.getDb_Driver();
        db_URL = Specification.getDb_URL();
        db_Server = Specification.getDb_Server();
        db_Name = Specification.getDb_Name();
        db_UserName = Specification.getDb_UserName();
        db_Password = Specification.getDb_Password();

    }

    @Override
    public synchronized Connection get_JDBC_Connection() {

        Connection connection = null;

        try {

            Class.forName(db_Driver);
            connection = DriverManager.getConnection((new StringBuilder(String.valueOf(db_URL))).append(db_Server).append(db_Name).toString() + "?useSSL=false&useUnicode=true&characterEncoding=UTF-8&useServerPrepStmts=false&rewriteBatchedStatements=true&allowPublicKeyRetrieval=true", db_UserName, db_Password);

        } catch (Exception e) {
            log.error(e.getMessage());
        }

        return connection;
    }

    @Override
    public boolean start_Connection(Connection con) {

        boolean success = false;

        try {

            if (!con.getAutoCommit()) {
                con.rollback();
                con.setAutoCommit(true);
            }

            con.setAutoCommit(false);
            success = true;

        } catch (Exception e) {
            log.error(e.getMessage());
        }

        return success;
    }

    @Override
    public boolean end_Connection(Connection con) {

        boolean success = false;

        try {
            if (!con.getAutoCommit()) {
                con.commit();
                con.setAutoCommit(true);
            }
            success = true;
        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return success;
    }

    @Override
    public boolean restart_Connection(Connection con) {

        boolean success = false;

        try {

            if (!con.getAutoCommit()) {
                con.commit();
                con.setAutoCommit(true);
            }
            if (!con.getAutoCommit()) {

                con.rollback();
                con.setAutoCommit(true);
            }

            con.setAutoCommit(false);
            success = true;
        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return success;
    }

    @Override
    public boolean abort_Connection(Connection con) {

        boolean success = false;

        try {
            if (!con.getAutoCommit()) {
                con.rollback();
                con.setAutoCommit(true);
            }
            success = true;
        } catch (Exception e) {
            log.error(e.getMessage());
        }

        return success;
    }

    public static synchronized DatabaseConnection getInstance() {

        if (database_Connection == null) {
            database_Connection = new DatabaseConnection();
        }
        return database_Connection;
    }

    public static void main(String[] args) { 
        
         try {
            DatabaseConnection co = new DatabaseConnection();
            Connection con = co.get_JDBC_Connection();

        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

}
