/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Common.DAO.Impl;

import gcsm.Administration.DAO.Impl.BusinessEntitiyDAOImpl;
import gcsm.Common.DAO.LoginDAO;
import gcsm.Utitlities.Impl.DatabaseConnection;
import gcsm.Utitlities.Impl.Encryption;
import gcsm.Utitlities.Impl.JSONObjects;
import gcsm.Utitlities.Model.ResponceHandler;
import gcsm.Utitlities.Model.RoleTypes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Randika_10992
 */
public class LoginDAOImpl extends DatabaseConnection implements LoginDAO {

    static Logger log = LogManager.getLogger(LoginDAOImpl.class.getName());

    static DatabaseConnection database_Connection;
    static Connection _currentCon = null;
    private Statement _statement = null;
    private PreparedStatement _prep_statement_1 = null;
    private PreparedStatement _prep_statement_2 = null;
    private ResultSet _rs = null;
    private Exception _exception;
    private ResponceHandler gcsm_responceHandler;
    private JSONObjects gcsm_Jason;
    private JSONArray _jsArr;
    private Encryption encryption;

    @Override
    public JSONArray authentication(JSONObject jasonobj) {

        database_Connection = DatabaseConnection.getInstance();
        _currentCon = database_Connection.get_JDBC_Connection();
        String main_AdministrationQry = "";
        JSONObject m_jsObj;
        _jsArr = new JSONArray();

        int i = 0;

        encryption = new Encryption();
        String en_pass = encryption.encrypt(String.valueOf(jasonobj.get("user_password")));

        try {

            main_AdministrationQry = "select * from gcsm_user,gcsm_businessline where user_username = ? AND user_password = ? and user_status_flag =1 and record_auth_status=1 and user_businessline=bl_id;";

            log.info("logging attemp : " + jasonobj.get("user_username"));

            _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry);
            _prep_statement_1.setString(1, (String) jasonobj.get("user_username"));
            _prep_statement_1.setString(2, en_pass);
            _rs = _prep_statement_1.executeQuery();

//            int usr_role_type = 0;
            String user_has_role_type = "";

            while (_rs.next()) {

                m_jsObj = new JSONObject();

                user_has_role_type = _rs.getString("user_role");
//                user_has_role_type = "";

//                if (usr_role_type == 0) {
//                    user_has_role_type = RoleTypes.ROOT;
//                }
//                else if (usr_role_type == 1) {
//                    user_has_role_type = RoleTypes.ADMINISTRATOR;
//                } else if (usr_role_type == 2) {
//                    user_has_role_type = RoleTypes.FINANCE_ADMINISTRATOR;
//                } else if (usr_role_type == 3) {
//                    user_has_role_type = RoleTypes.INPUTER;
//                } else if (usr_role_type == 4) {
//                    user_has_role_type = RoleTypes.AUTHORIZER;
//                }else if (usr_role_type == 5) {
//                    user_has_role_type = RoleTypes.FINANCE_AUTHORIZER;
//                }else if (usr_role_type == 6) {
//                    user_has_role_type = RoleTypes.OTHER_LINE_ADMINISTRATOR;
//                }
//                m_jsObj.put("user_has_role_id", _rs.getInt("user_has_role_id"));
//                m_jsObj.put("user_has_role_user", _rs.getInt("user_has_role_user"));
//                m_jsObj.put("user_has_role_type_flag", _rs.getInt("user_has_role_type"));
//                m_jsObj.put("user_has_role_status_flag", _rs.getInt("user_has_role_status_flag"));
//                m_jsObj.put("user_NIC", _rs.getString("user_NIC"));
//                m_jsObj.put("user_EPF", _rs.getInt("user_EPF"));
                m_jsObj.put("user_firstname", _rs.getString("user_name_first"));
                m_jsObj.put("user_lastname", _rs.getString("user_name_last"));
                m_jsObj.put("user_has_role_type", user_has_role_type);
                m_jsObj.put("user_username", _rs.getString("user_username"));
                m_jsObj.put("bl_name", _rs.getString("bl_name"));
                log.info("logging attemp success : " + _rs.getString("user_username"));

                _jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {

            log.error(e.getMessage());

        } finally {

            try {

                if (_rs != null) {
                    _rs.close();
                }

                if (_prep_statement_1 != null) {
                    _prep_statement_1.close();
                }

                if (_currentCon != null) {
                    _currentCon.close();
                }

            } catch (Exception e) {

                gcsm_responceHandler.setResponceModule("authentication");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("0001");
                gcsm_responceHandler.setResponceDescription("Error occured.!\n" + e);
                log.error(e.getMessage());

            }

        }

        return _jsArr;

    }

    @Override
    public int loginTrailRecordAdd(String username) {
        int login_trail_id = 0;
        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;

        try {
            if (databaseConnection.start_Connection(currentConnection)) {
                String queryInsertRecord
                        = "INSERT INTO gcsm_user_login_trail("
                        + "login_username,"
                        + "login_timestamp)" //1
                        + " VALUES(?,now())";

                preparedStatement = currentConnection.prepareStatement(queryInsertRecord, Statement.RETURN_GENERATED_KEYS);

                preparedStatement.setString(1, username);
                int executeUpdate = preparedStatement.executeUpdate();

                rs = preparedStatement.getGeneratedKeys();

                if (rs.first()) {
                    login_trail_id = rs.getInt(1);
                }
            }
            databaseConnection.end_Connection(currentConnection);

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (rs != null) {
                    rs.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());

            }
        }
        return login_trail_id;

    }

    @Override
    public void loginTrailRecordLogout(int login_trail_id) {

        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;

        try {
            if (databaseConnection.start_Connection(currentConnection)) {
                String queryInsertRecord
                        = "UPDATE gcsm_user_login_trail "
                        + "set logout_timestamp=now() "
                        + "where login_trail_id=?"; //1

                preparedStatement = currentConnection.prepareStatement(queryInsertRecord);

                preparedStatement.setInt(1, login_trail_id);
                int executeUpdate = preparedStatement.executeUpdate();
            }
            databaseConnection.end_Connection(currentConnection);

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());

            }
        }

    }
    @Override
    public void deactivateAllInactiveUsers() {
        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            String query = "select login_username, max(login_timestamp) from gcsm_user_login_trail group by login_username having DATEDIFF(now(), max(login_timestamp))>90;";

           

            preparedStatement = currentConnection.prepareStatement(query);

            resultSet = preparedStatement.executeQuery();
            System.out.println(preparedStatement);
            List<String> toBeDeactivatedUserNames = new ArrayList();

            while (resultSet.next()) {
                toBeDeactivatedUserNames.add(resultSet.getString("login_username"));

            }

            for (String username : toBeDeactivatedUserNames) {
                deactivateUser(username);
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
            }
        }

    }

    @Override
    public void deactivateUser(String username) {
        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();

        PreparedStatement preparedStatement = null;
        try {
            String query2 = "update gcsm_user set user_status_flag=0 where user_username=?";
            preparedStatement = currentConnection.prepareStatement(query2);
            preparedStatement.setString(1, username);
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
            preparedStatement.close();
        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
            }
        }
    }
}
