/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Common.DAO;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Randika_10992
 */
public interface LoginDAO {  
    
    public JSONArray authentication(JSONObject jasonobj);
    
    public void loginTrailRecordLogout(int login_trail_id);
    
    public int loginTrailRecordAdd(String username);
    
    public void deactivateUser(String username);
    
    public void deactivateAllInactiveUsers();
  
}
