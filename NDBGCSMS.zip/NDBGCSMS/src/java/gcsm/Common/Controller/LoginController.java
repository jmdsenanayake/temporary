/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Common.Controller;

import gcsm.Common.DAO.Impl.LoginDAOImpl;
import gcsm.Common.DAO.LoginDAO;
import gcsm.Utitlities.Model.ResponceHandler;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Randika_10992
 */
public class LoginController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    static Logger log = LogManager.getLogger(LoginController.class.getName());
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        HttpSession session = request.getSession(false);
        JSONObject result = new JSONObject();
        JSONObject data = new JSONObject();
        String m_strfunction = "";
        PrintWriter out = response.getWriter();
        ResponceHandler responceHandler;
        JSONArray jsArr = null;
        
        try {
            
            m_strfunction = request.getParameter("functionName");
            LoginDAO loginDAO = new LoginDAOImpl();
            
            loginDAO.deactivateAllInactiveUsers();
            
            if (m_strfunction.equalsIgnoreCase("authentication")) {
                data.put("user_username", request.getParameter("user_username"));
                data.put("user_password", request.getParameter("user_password"));
                String enteredUsername = request.getParameter("user_username");
                jsArr = loginDAO.authentication(data);
                if (session.getAttribute(enteredUsername + "loginAttempts") == null) {
                    session.setAttribute(enteredUsername + "loginAttempts", "1");
                } else {
                    if (jsArr.length() == 0) {
                        session.setAttribute(enteredUsername + "loginAttempts", Integer.parseInt(session.getAttribute(enteredUsername + "loginAttempts").toString()) + 1);
                    } else {
                        session.setAttribute(enteredUsername + "loginAttempts", "1");
                    }
                }
                int noOfLoginAttempts = Integer.parseInt(session.getAttribute(enteredUsername + "loginAttempts").toString());
                if (noOfLoginAttempts == 4) {
                    loginDAO.deactivateUser(enteredUsername);
                }
                
            }
            
            if (m_strfunction.equalsIgnoreCase("redirect")) {
                session.setAttribute("session_username", request.getParameter("session_username"));
                session.setAttribute("session_firstname", request.getParameter("session_firstname"));
                session.setAttribute("session_lastname", request.getParameter("session_lastname"));
                session.setAttribute("session_role_type", request.getParameter("session_role_type"));
                session.setAttribute("session_bl_name", request.getParameter("session_bl_name"));
//                session.setAttribute("auth_type", request.getParameter("auth_type"));                
                session.setAttribute("session_login_trail_id", loginDAO.loginTrailRecordAdd(request.getParameter("session_username")));
                
            }
            
            if (m_strfunction.equalsIgnoreCase("logout")) {
                
                final Logger logger = LogManager.getLogger(LoginController.class.getName());
                logger.info("Logging out : " + session.getAttribute("session_username"));
                loginDAO.loginTrailRecordLogout((int) session.getAttribute("session_login_trail_id"));
                session.invalidate();
                
            }
            
        } catch (Exception e) {
            log.error(e.getMessage());
        }
        
        out.print(jsArr);
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
