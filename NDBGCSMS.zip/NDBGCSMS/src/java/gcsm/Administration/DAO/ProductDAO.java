/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Administration.DAO;

import gcsm.Utitlities.Model.ResponceHandler;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Randika_10992
 */
public interface ProductDAO {

    public ResponceHandler saveProduct(JSONObject jasonobj);

    public JSONArray getTableProduct(JSONObject jasonobj);

    public JSONArray getInfoProduct(JSONObject jasonobj);
    
    public JSONArray getProductOfBusinessLine(JSONObject jasonobj);

}
