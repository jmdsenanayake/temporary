/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Administration.DAO;

import gcsm.Utitlities.Model.ResponceHandler;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Janaka_5977
 */
public interface UserManagementDAO {    
    
    public ResponceHandler saveUser(JSONObject jasonobj);
    
    public JSONArray getTableUsers(JSONObject jasonobj);
    
    public JSONArray getInfoUsers(JSONObject jasonobj);

    public ResponceHandler updateUser(JSONObject data);

    public ResponceHandler checkPasswordForPasswordChange(JSONObject data);

    public ResponceHandler changePassword(JSONObject data);

    public JSONArray getPrivilegeStatus(JSONObject data);

    public ResponceHandler approveUserDetals(JSONObject data);
   
}
