/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Administration.DAO.Impl;

import gcsm.Administration.DAO.ProductDAO;
import gcsm.Administration.Model.ProductModel;
import gcsm.Utitlities.Impl.Auditing;
import gcsm.Utitlities.Impl.DatabaseConnection;
import gcsm.Utitlities.Impl.JSONObjects;
import gcsm.Utitlities.Model.ResponceHandler;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Randika_10992
 */
public class ProductDAOImpl extends DatabaseConnection implements ProductDAO {

    static Logger log = LogManager.getLogger(ProductDAOImpl.class.getName());

  

    static DatabaseConnection database_Connection;
    static Connection _currentCon = null;
    private Statement _statement = null;
    private PreparedStatement _prep_statement_1 = null;
    private PreparedStatement _prep_statement_2 = null;
    private ResultSet _rs = null;
    private Exception _exception;
    private ResponceHandler gcsm_responceHandler;
    private JSONObjects gcsm_Jason;
    private JSONArray _jsArr;

    @Override
    public ResponceHandler saveProduct(JSONObject jasonobj) {
        
          //Audit Trail
    String auditType = "";
    Auditing auditing = new Auditing();
    String related_table = "gcsm_product";
    String record_pk = "";
    String old_value = "##Empty##";

        String session_username = jasonobj.get("session_username").toString();

        gcsm_responceHandler = new ResponceHandler();
        database_Connection = DatabaseConnection.getInstance();
        _currentCon = database_Connection.get_JDBC_Connection();
        gcsm_Jason = new JSONObjects();
        ProductModel newProductModel;
        ProductModel renewProductModel;
        String main_AdministrationQry;

        boolean isDataAvailabile = false;

        try {

            newProductModel = new ProductModel();
            newProductModel = gcsm_Jason.convertProductModelToJSON(jasonobj.toString());
            renewProductModel = new ProductModel();

            // check database connection problem 
            if (!start_Connection(_currentCon)) {

                gcsm_responceHandler.setResponceModule("save_Product");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("00001");
                gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, database connection establishing problem.");

                log.error("database connection establishing problem.");
                throw new Exception("An error occurred, database connection establishing problem.");

            }

            // Check Record Already Exists
            if (newProductModel.getProduct_id() == 0) {

                main_AdministrationQry = "SELECT * FROM gcsm_product WHERE product_businessline =? AND product_name=?";

                _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry);
                _prep_statement_1.setInt(1, newProductModel.getProduct_businessline());
                _prep_statement_1.setString(2, newProductModel.getProduct_name());
                _rs = _prep_statement_1.executeQuery();

                if (_rs.next()) {

                    gcsm_responceHandler.setResponceModule("save_Product");
                    gcsm_responceHandler.setResponceType("error");;
                    gcsm_responceHandler.setResponceCode("00001");
                    gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, record already exists in the databse.");

                    log.error("record already exists in the databse.");
                    throw new Exception("An error occurred, record already exists in the databse.");

                }

            }

            main_AdministrationQry = "SELECT * FROM gcsm_product WHERE product_id=?";

            _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry);
            _prep_statement_1.setInt(1, newProductModel.getProduct_id());

            _rs = _prep_statement_1.executeQuery();

            if (_rs.next()) {

                renewProductModel.setProduct_businessline(_rs.getInt("product_id"));
                renewProductModel.setProduct_name(_rs.getString("product_name"));
                renewProductModel.setProduct_description(_rs.getString("product_description"));
                renewProductModel.setProduct_type(_rs.getString("product_type"));
                renewProductModel.setProduct_shadow_basis(_rs.getString("product_shadow_basis"));
                renewProductModel.setProduct_annual_fee(_rs.getDouble("product_annual_fee"));
                renewProductModel.setProduct_alco_approved_tp_rate(_rs.getDouble("product_alco_approved_tp_rate"));
                renewProductModel.setProduct_contract_value_retrive_from(_rs.getString("product_contract_value_retrive_from"));
                renewProductModel.setProduct_status_flag(_rs.getInt("product_status_flag"));

                isDataAvailabile = true;

            }

            if (isDataAvailabile) { //if data availabile, going to execute update query.   
                
                  //Audit Trail
                record_pk = "" + newProductModel.getProduct_id();
                old_value = auditing.getAllRecords(record_pk, related_table).toString();
                
                main_AdministrationQry
                        = "UPDATE gcsm_product SET \n"
                        + "product_businessline=?," //1
                        + "product_name=?,"         //2             
                        + "product_description=?,"  //3
                        + "product_type=?,"         //4
                        + "product_alco_approved_tp_rate=?,"         //5
                        + "product_shadow_basis=?," //6
                        + "product_annual_fee=?,"   //7
                        + "product_contract_value_retrive_from=?,"  //8
                        + "product_status_flag=?,"  //9
                        + "product_composed_user=?,"    //10
                        + "product_composed_timestamp=now() "   
                        + "WHERE product_id=?";         //1

                _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry);
                _prep_statement_1.setInt(1, newProductModel.getProduct_businessline());
                _prep_statement_1.setString(2, newProductModel.getProduct_name());
                _prep_statement_1.setString(3, newProductModel.getProduct_description());
                _prep_statement_1.setString(4, newProductModel.getProduct_type());
                _prep_statement_1.setDouble(5, newProductModel.getProduct_alco_approved_tp_rate());
                _prep_statement_1.setString(6, newProductModel.getProduct_shadow_basis());
                _prep_statement_1.setDouble(7, newProductModel.getProduct_annual_fee());
                _prep_statement_1.setString(8, newProductModel.getProduct_contract_value_retrive_from());
                _prep_statement_1.setInt(9, newProductModel.getProduct_status_flag());
                _prep_statement_1.setString(10, session_username);
                _prep_statement_1.setInt(11, newProductModel.getProduct_id());
              

                if (_prep_statement_1.executeUpdate() <= 0) {

                    gcsm_responceHandler.setResponceModule("save_Product");
                    gcsm_responceHandler.setResponceType("error");
                    gcsm_responceHandler.setResponceCode("0001");
                    gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");
                    log.error("unable to update this record.");

                }

                gcsm_responceHandler.setResponceModule("save_Product");
                gcsm_responceHandler.setResponceType("success");
                gcsm_responceHandler.setResponceCode("0000");
                gcsm_responceHandler.setResponceDescription("Awesome! You were successful.");
                log.info("update successful.");
                
                //Audit Trail
                auditType = "UPDATE";

            } else { //if data not availabile, going to execute insert query.

                main_AdministrationQry
                        = "INSERT INTO gcsm_product("
                        + "product_id,"
                        + "product_businessline,"
                        + "product_name,"
                        + "product_description,"
                        + "product_type,"
                        + "product_alco_approved_tp_rate,"
                        + "product_shadow_basis,"
                        + "product_annual_fee,"
                        + "product_contract_value_retrive_from,"
                        + "product_status_flag,"
                        + "product_setup_user,"
                        + "product_composed_user,"
                        + "product_setup_timestamp,"
                        + "product_composed_timestamp)"
                        + " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,now(),now())";

                _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry, Statement.RETURN_GENERATED_KEYS);
                _prep_statement_1.setInt(1, newProductModel.getProduct_id());
                _prep_statement_1.setInt(2, newProductModel.getProduct_businessline());
                _prep_statement_1.setString(3, newProductModel.getProduct_name());
                _prep_statement_1.setString(4, newProductModel.getProduct_description());
                _prep_statement_1.setString(5, newProductModel.getProduct_type());
                _prep_statement_1.setDouble(6, newProductModel.getProduct_alco_approved_tp_rate());
                _prep_statement_1.setString(7, newProductModel.getProduct_shadow_basis());
                _prep_statement_1.setDouble(8, newProductModel.getProduct_annual_fee());
                _prep_statement_1.setString(9, newProductModel.getProduct_contract_value_retrive_from());
                _prep_statement_1.setInt(10, newProductModel.getProduct_status_flag());
                _prep_statement_1.setString(11, session_username);
                _prep_statement_1.setString(12, session_username);

                if (_prep_statement_1.executeUpdate() <= 0) {

                    gcsm_responceHandler.setResponceModule("save_Product");
                    gcsm_responceHandler.setResponceType("error");
                    gcsm_responceHandler.setResponceCode("0001");
                    gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to insert this record.");
                    log.error("unable to insert this record.");

                }

                if (!isDataAvailabile) {
                    _rs = _prep_statement_1.getGeneratedKeys();
                }

                gcsm_responceHandler.setResponceModule("save_Product");
                gcsm_responceHandler.setResponceType("success");
                gcsm_responceHandler.setResponceCode("0000");
                gcsm_responceHandler.setResponceDescription("Awesome! You were successful.");
                log.info("update successful.");
                
                //Audit Trail
                auditType = "INSERT";
                if(_rs.first()){
                    record_pk = "" + (_rs.getInt(1));
                }
                

            }

            if (!end_Connection(_currentCon)) {

                gcsm_responceHandler.setResponceModule("save_Product");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("0001");
                gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }
            
            //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            switch (auditType) {
                case "INSERT":
                    {                        
                        auditing.saveAuditRecord(session_username, related_table, auditType, record_pk, old_value, new_value);
                        break;
                    }
                case "UPDATE":
                    {                        
                        auditing.saveAuditRecord(session_username, related_table, auditType, record_pk, old_value, new_value);
                        break;
                    }
            }

        } catch (Exception e) {

            gcsm_responceHandler.setResponceModule("save_Product");
            gcsm_responceHandler.setResponceType("error");
            gcsm_responceHandler.setResponceCode("00002");
            gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to insert this record.\n" + e);
            log.error("unable to insert this record : " + e.getMessage());

        } finally {

            try {

                if (_rs != null) {
                    _rs.close();
                }

                if (_prep_statement_1 != null) {
                    _prep_statement_1.close();
                }

                if (_currentCon != null) {
                    _currentCon.close();
                }

            } catch (Exception e) {

                gcsm_responceHandler.setResponceModule("save_Product");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("0001");
                gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to insert this record.\n" + e);
                log.error("unable to insert this record : " + e);
                log.error(e.getMessage());

            }

        }

        return gcsm_responceHandler;

    }

    @Override
    public JSONArray getTableProduct(JSONObject jasonobj) {

        database_Connection = DatabaseConnection.getInstance();
        _currentCon = database_Connection.get_JDBC_Connection();
        String main_AdministrationQry = "";
        JSONObject m_jsObj;
        _jsArr = new JSONArray();

        int i = 0;

        try {

            main_AdministrationQry
                    = "SELECT product.* ,\n"
                    + "(SELECT COUNT(*) FROM gcsm_product product , gcsm_businessline bl WHERE product.product_businessline = bl.bl_id ) as RowsCount ,\n"
                    + "bl.bl_name as user_businessline_name\n"
                    + "FROM\n"
                    + "gcsm_product product , gcsm_businessline bl\n"
                    + "WHERE\n"
                    + "product.product_businessline = bl.bl_id ORDER BY user_businessline_name ;";

            
            _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry);
            _rs = _prep_statement_1.executeQuery();

            while (_rs.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("product_id", _rs.getInt("product_id"));
                m_jsObj.put("product_businessline", _rs.getInt("product_businessline"));
                m_jsObj.put("product_name", _rs.getString("product_name"));
                m_jsObj.put("product_shadow_basis", _rs.getString("product_shadow_basis"));
                m_jsObj.put("product_annual_fee", _rs.getDouble("product_annual_fee"));
                m_jsObj.put("product_alco_approved_tp_rate", _rs.getDouble("product_alco_approved_tp_rate"));               
                m_jsObj.put("product_contract_value_retrive_from", _rs.getString("product_contract_value_retrive_from"));
                m_jsObj.put("product_description", _rs.getString("product_description"));
                m_jsObj.put("product_type", _rs.getString("product_type"));
                m_jsObj.put("product_status_flag", _rs.getInt("product_status_flag"));
                m_jsObj.put("product_setup_user", _rs.getString("product_setup_user"));
                m_jsObj.put("user_businessline_name", _rs.getString("user_businessline_name"));
                m_jsObj.put("RowsCount", _rs.getInt("RowsCount"));
                _jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {

            log.error(e.getMessage());

        } finally {

            try {

                if (_rs != null) {
                    _rs.close();
                }

                if (_prep_statement_1 != null) {
                    _prep_statement_1.close();
                }

                if (_currentCon != null) {
                    _currentCon.close();
                }

            } catch (Exception e) {

                gcsm_responceHandler.setResponceModule("get_Table_BusinessLine");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("0001");
                gcsm_responceHandler.setResponceDescription("Error occured.!\n" + e);
                log.error(e.getMessage());

            }

        }

        return _jsArr;

    }

    @Override
    public JSONArray getInfoProduct(JSONObject jasonobj) {

        database_Connection = DatabaseConnection.getInstance();
        _currentCon = database_Connection.get_JDBC_Connection();
        String main_AdministrationQry = "";
        JSONObject m_jsObj;
        _jsArr = new JSONArray();

        int i = 0;

        try {

            main_AdministrationQry
                    = "SELECT * \n"
                    + "FROM\n"
                    + "gcsm_product\n"
                    + "WHERE product_id='" + jasonobj.get("product_id") + "'";

            
            _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry);
            _rs = _prep_statement_1.executeQuery();

            while (_rs.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("product_id", _rs.getInt("product_id"));
                m_jsObj.put("product_businessline", _rs.getInt("product_businessline"));
                m_jsObj.put("product_name", _rs.getString("product_name"));
                m_jsObj.put("product_description", _rs.getString("product_description"));
                m_jsObj.put("product_type", _rs.getString("product_type"));
                m_jsObj.put("product_contract_value_retrive_from", _rs.getString("product_contract_value_retrive_from"));
                m_jsObj.put("product_shadow_basis", _rs.getString("product_shadow_basis"));
                m_jsObj.put("product_annual_fee", _rs.getDouble("product_annual_fee"));
                m_jsObj.put("product_alco_approved_tp_rate", _rs.getDouble("product_alco_approved_tp_rate"));               
                m_jsObj.put("product_status_flag", _rs.getInt("product_status_flag"));
                m_jsObj.put("product_setup_user", _rs.getString("product_setup_user"));

                _jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {

            log.error(e.getMessage());

        } finally {

            try {

                if (_rs != null) {
                    _rs.close();
                }

                if (_prep_statement_1 != null) {
                    _prep_statement_1.close();
                }

                if (_currentCon != null) {
                    _currentCon.close();
                }

            } catch (Exception e) {
                gcsm_responceHandler.setResponceModule("get_Info_BusinessLine");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("0001");
                gcsm_responceHandler.setResponceDescription("Error occured.!\n" + e);
                log.error(e.getMessage());

            }

        }

        return _jsArr;

    }

    @Override
    public JSONArray getProductOfBusinessLine(JSONObject jasonobj) {
        database_Connection = DatabaseConnection.getInstance();
        _currentCon = database_Connection.get_JDBC_Connection();
        String main_AdministrationQry = "";
        JSONObject m_jsObj;
        _jsArr = new JSONArray();

        int i = 0;

        try {

            main_AdministrationQry
                    = "SELECT * \n"
                    + "FROM\n"
                    + "gcsm_product\n"
                    + "WHERE product_businessline='" + jasonobj.get("product_businessline") + "'";

            
            _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry);
            _rs = _prep_statement_1.executeQuery();

            while (_rs.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("product_id", _rs.getInt("product_id"));
                m_jsObj.put("product_businessline", _rs.getInt("product_businessline"));
                m_jsObj.put("product_name", _rs.getString("product_name"));
                m_jsObj.put("product_description", _rs.getString("product_description"));
                m_jsObj.put("product_type", _rs.getString("product_type"));
                m_jsObj.put("product_contract_value_retrive_from", _rs.getString("product_contract_value_retrive_from"));
                m_jsObj.put("product_shadow_basis", _rs.getString("product_shadow_basis"));
                m_jsObj.put("product_annual_fee", _rs.getDouble("product_annual_fee"));
                m_jsObj.put("product_alco_approved_tp_rate", _rs.getDouble("product_alco_approved_tp_rate"));               
                m_jsObj.put("product_status_flag", _rs.getInt("product_status_flag"));
                m_jsObj.put("product_setup_user", _rs.getString("product_setup_user"));

                _jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {

            log.error(e.getMessage());

        } finally {

            try {

                if (_rs != null) {
                    _rs.close();
                }

                if (_prep_statement_1 != null) {
                    _prep_statement_1.close();
                }

                if (_currentCon != null) {
                    _currentCon.close();
                }

            } catch (Exception e) {
                gcsm_responceHandler.setResponceModule("get_Info_Product_BusinessLine");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("0001");
                gcsm_responceHandler.setResponceDescription("Error occured.!\n" + e);
                log.error(e.getMessage());

            }

        }

        return _jsArr;
    }

}
