/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Administration.DAO.Impl;

import gcsm.Administration.DAO.UsersRoleDAO;
import gcsm.Administration.Model.UsersRoleModel;
import gcsm.Utitlities.Impl.Auditing;
import gcsm.Utitlities.Impl.DatabaseConnection;
import gcsm.Utitlities.Impl.Encryption;
import gcsm.Utitlities.Impl.JSONObjects;
import gcsm.Utitlities.Model.JSPPages;
import gcsm.Utitlities.Model.ResponceHandler;
import gcsm.Utitlities.Model.RoleTypes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Randika_10992
 */
public class UsersRoleDAOImpl extends DatabaseConnection implements UsersRoleDAO {

    static Logger log = LogManager.getLogger(UsersRoleDAOImpl.class.getName());

    static DatabaseConnection database_Connection;
    static Connection _currentCon = null;
    private Statement _statement = null;
    private PreparedStatement _prep_statement_1 = null;
    private PreparedStatement _prep_statement_2 = null;
    private ResultSet _rs = null;
    private ResultSet _rs2 = null;
    private Exception _exception;
    private ResponceHandler gcsm_responceHandler;
    private JSONObjects gcsm_Jason;
    private JSONArray _jsArr;
    private Encryption encryption;

    @Override
    public ResponceHandler saveUsersRole(JSONObject jasonobj) {

        //Audit Trail
        String auditType = "";
        Auditing auditing = new Auditing();
        String related_table = "gcsm_user_has_role";
        String record_pk = "";
        String old_value = "##Empty##";

        String session_username = jasonobj.get("session_username").toString();

        gcsm_responceHandler = new ResponceHandler();
        database_Connection = DatabaseConnection.getInstance();
        _currentCon = database_Connection.get_JDBC_Connection();
        gcsm_Jason = new JSONObjects();
        UsersRoleModel newUsersRoleModel;
        UsersRoleModel renewUsersRoleModel;
        String main_AdministrationQry;
        String main_AdministrationQry_2;

        boolean isDataAvailabile = false;

        try {

            newUsersRoleModel = new UsersRoleModel();
            newUsersRoleModel = gcsm_Jason.convertUserRoleModelToJSON(jasonobj.toString());
            renewUsersRoleModel = new UsersRoleModel();

            // check database connection problem 
            if (!start_Connection(_currentCon)) {

                gcsm_responceHandler.setResponceModule("save_Users_Role");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("00001");
                gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, database connection establishing problem.");

                log.error("database connection establishing problem.");
                throw new Exception("An error occurred, database connection establishing problem.");

            }

            // Check Record Already Exists
            if (newUsersRoleModel.getUser_has_role_id() == 0) {

                main_AdministrationQry = "SELECT * FROM gcsm_user_has_role WHERE user_has_role_user=?";

                _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry);
                _prep_statement_1.setInt(1, newUsersRoleModel.getUser_has_role_user());
                _rs = _prep_statement_1.executeQuery();

                if (_rs.next()) {

                    gcsm_responceHandler.setResponceModule("save_Users_Role");
                    gcsm_responceHandler.setResponceType("error");
                    gcsm_responceHandler.setResponceCode("00001");
                    gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, record already exists in the databse.");

                    log.error("record already exists in the databse.");
                    throw new Exception("An error occurred, record already exists in the databse.");

                }

            }

            main_AdministrationQry = "SELECT * FROM gcsm_user_has_role WHERE user_has_role_id=?";

            _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry);
            _prep_statement_1.setInt(1, newUsersRoleModel.getUser_has_role_id());

            _rs = _prep_statement_1.executeQuery();

            if (_rs.next()) {

                renewUsersRoleModel.setUser_has_role_type(_rs.getInt("user_has_role_type"));
                renewUsersRoleModel.setUser_has_role_status_flag(_rs.getInt("user_has_role_status_flag"));
                isDataAvailabile = true;

            }

            if (isDataAvailabile) { //if data availabile, going to execute update query.          
                
                 //Audit Trail
                record_pk = "" + newUsersRoleModel.getUser_has_role_id();
                old_value = auditing.getAllRecords(record_pk, related_table).toString();

                main_AdministrationQry
                        = "UPDATE gcsm_user_has_role SET \n"
                        + "user_has_role_type=?,"
                        + "user_has_role_status_flag=?,"
                        + "user_has_role_composed_user=?,"
                        + "user_has_role_composed_timestamp=now() "
                        + "WHERE user_has_role_id=?";

                _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry);
                _prep_statement_1.setInt(1, newUsersRoleModel.getUser_has_role_type());
                _prep_statement_1.setInt(2, newUsersRoleModel.getUser_has_role_status_flag());
                _prep_statement_1.setString(3, session_username);
                _prep_statement_1.setInt(4, newUsersRoleModel.getUser_has_role_id());

                if (_prep_statement_1.executeUpdate() <= 0) {

                    gcsm_responceHandler.setResponceModule("save_Users_Role");
                    gcsm_responceHandler.setResponceType("error");
                    gcsm_responceHandler.setResponceCode("0001");
                    gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");
                    log.error("unable to update this record.");

                }
                //update userprivilages for selected privilages
                String username = jasonobj.getString("userNIC");
                String[] pageNames = jasonobj.getString("user_privileges").split(",");
                String[] allPages = JSPPages.PAGES;
                Arrays.sort(allPages);
                Arrays.sort(pageNames);
                for (String allPageName : allPages) {
                    int authorizationStatus = 1;
                    if (Arrays.binarySearch(pageNames, allPageName) < 0) {
                        authorizationStatus = 0;
                    }
                    main_AdministrationQry
                            = "UPDATE gcsm_user_page_privilages SET \n"
                            + "authorization_status=? "
                            + "WHERE page=? and user_name=?";

                    _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry);
                    _prep_statement_1.setInt(1, authorizationStatus);
                    _prep_statement_1.setString(2, allPageName);
                    _prep_statement_1.setString(3, username);

                    if (_prep_statement_1.executeUpdate() <= 0) {

                        gcsm_responceHandler.setResponceModule("save_Users_Role");
                        gcsm_responceHandler.setResponceType("error");
                        gcsm_responceHandler.setResponceCode("0001");
                        gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");
                        log.error("unable to update this record.");
                    }
                }

                gcsm_responceHandler.setResponceModule("save_Users_Role");
                gcsm_responceHandler.setResponceType("success");
                gcsm_responceHandler.setResponceCode("0000");
                gcsm_responceHandler.setResponceDescription("Awesome! You were successful.");
                log.info("update successful");
                
                  //Audit Trail
                auditType = "UPDATE";

            } else { //if data not availabile, going to execute insert query.

                main_AdministrationQry
                        = "INSERT INTO gcsm_user_has_role("
                        + "user_has_role_id,"
                        + "user_has_role_user,"
                        + "user_has_role_type,"
                        + "user_has_role_status_flag,"
                        + "user_has_role_setup_user,"
                        + "user_has_role_composed_user,"
                        + "user_has_role_setup_timestamp,"
                        + "user_has_role_composed_timestamp"
                        + ")"
                        + " VALUES(?,?,?,?,?,?,now(),now())";

                _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry, Statement.RETURN_GENERATED_KEYS);
                _prep_statement_1.setInt(1, newUsersRoleModel.getUser_has_role_id());
                _prep_statement_1.setInt(2, newUsersRoleModel.getUser_has_role_user());
                _prep_statement_1.setInt(3, newUsersRoleModel.getUser_has_role_type());
                _prep_statement_1.setInt(4, newUsersRoleModel.getUser_has_role_status_flag());
                _prep_statement_1.setString(5, session_username);
                _prep_statement_1.setString(6, session_username);

                main_AdministrationQry_2
                        = "UPDATE gcsm_user SET \n"
                        + "user_auth_user=?,\n"
                        + "user_auth_timestamp=now() \n"
                        + "WHERE user_id=?";

                _prep_statement_2 = _currentCon.prepareStatement(main_AdministrationQry_2, Statement.RETURN_GENERATED_KEYS);
                _prep_statement_2.setString(1, session_username);
                _prep_statement_2.setInt(2, newUsersRoleModel.getUser_has_role_user());

                if (_prep_statement_1.executeUpdate() <= 0) {

                    gcsm_responceHandler.setResponceModule("save_Users_Role");
                    gcsm_responceHandler.setResponceType("error");
                    gcsm_responceHandler.setResponceCode("0001");
                    gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to insert this record.");
                    log.error("unable to insert this record.");

                }

                //update userprivilages for selected privilages
                String username = jasonobj.getString("userNIC");
                String[] pageNames = jasonobj.getString("user_privileges").split(",");
                for (String pageName : pageNames) {
                    main_AdministrationQry
                            = "UPDATE gcsm_user_page_privilages SET \n"
                            + "authorization_status=1 "
                            + "WHERE page=? and user_name=?";

                    _prep_statement_2 = _currentCon.prepareStatement(main_AdministrationQry);
                    _prep_statement_2.setString(1, pageName);
                    _prep_statement_2.setString(2, username);

                    if (_prep_statement_2.executeUpdate() <= 0) {

                        gcsm_responceHandler.setResponceModule("save_Users_Role");
                        gcsm_responceHandler.setResponceType("error");
                        gcsm_responceHandler.setResponceCode("0001");
                        gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");
                        log.error("unable to update this record.");
                    }
                }

                if (_prep_statement_2.executeUpdate() <= 0) {

                    gcsm_responceHandler.setResponceModule("save_Users_Role");
                    gcsm_responceHandler.setResponceType("error");
                    gcsm_responceHandler.setResponceCode("0001");
                    gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to insert this record.");
                    log.error("unable to insert this record.");
                }

                if (!isDataAvailabile) {
                    _rs = _prep_statement_1.getGeneratedKeys();
                }

                gcsm_responceHandler.setResponceModule("save_Users_Role");
                gcsm_responceHandler.setResponceType("success");
                gcsm_responceHandler.setResponceCode("0000");
                gcsm_responceHandler.setResponceDescription("Awesome! You were successful.");
                log.info("insert successful");
                
                  //Audit Trail
                auditType = "INSERT";
                if(_rs.first()){
                    record_pk = "" + (_rs.getInt(1));
                }

            }

            if (!end_Connection(_currentCon)) {

                gcsm_responceHandler.setResponceModule("save_Users_Role");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("0001");
                gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }
            
             //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            switch (auditType) {
                case "INSERT":
                    {                        
                        auditing.saveAuditRecord(session_username, related_table, auditType, record_pk, old_value, new_value);
                        break;
                    }
                case "UPDATE":
                    {                        
                        auditing.saveAuditRecord(session_username, related_table, auditType, record_pk, old_value, new_value);
                        break;
                    }
            }

        } catch (Exception e) {

            gcsm_responceHandler.setResponceModule("save_Users_Role");
            gcsm_responceHandler.setResponceType("error");
            gcsm_responceHandler.setResponceCode("00002");
            gcsm_responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to insert this record.\n" + e);
            log.error("unable to insert this record : " + e.getMessage());

        } finally {

            try {

                if (_rs != null) {
                    _rs.close();
                }

                if (_prep_statement_1 != null) {
                    _prep_statement_1.close();
                }

                if (_currentCon != null) {
                    _currentCon.close();
                }

            } catch (Exception e) {

                gcsm_responceHandler.setResponceModule("save_Users_Role");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("0001");
                gcsm_responceHandler.setResponceDescription("Error occured.!\n" + e);
                log.error("unable to insert this record : " + e.getMessage());

            }

        }

        return gcsm_responceHandler;
    }

    @Override
    public JSONArray getTableUsersRoles(JSONObject jasonobj) {

        database_Connection = DatabaseConnection.getInstance();
        _currentCon = database_Connection.get_JDBC_Connection();
        String main_AdministrationQry = "";
        JSONObject m_jsObj;
        _jsArr = new JSONArray();

        int i = 0;

        try {

            main_AdministrationQry
                    = "SELECT usr_role.* ,\n"
                    + "usr.user_EPF as user_EPF,\n"
                    + "usr.user_name_first as user_firstname,\n"
                    + "usr.user_name_last as user_lastname,\n"
                    + "usr.user_NIC as user_NIC,\n"
                    + "(SELECT COUNT(*) FROM gcsm_user_has_role usr_role , gcsm_user usr WHERE usr_role.user_has_role_user = usr.user_id) as RowsCount \n"
                    + "FROM\n"
                    + "gcsm_user_has_role usr_role , gcsm_user usr\n"
                    + "WHERE\n"
                    + "usr_role.user_has_role_user = usr.user_id\n"
                    + "AND user_has_role_type!=0 \n"
                    + "ORDER BY \n"
                    + "usr_role.user_has_role_id;";

            _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry);
            _rs = _prep_statement_1.executeQuery();

            int usr_role_type = 0;
            String user_has_role_type = "";

            while (_rs.next()) {

                m_jsObj = new JSONObject();

                usr_role_type = _rs.getInt("user_has_role_type");
                user_has_role_type = "";

//                if (usr_role_type == 1) {
//                    user_has_role_type = RoleTypes.ADMINISTRATOR;
//                } else if (usr_role_type == 2) {
//                    user_has_role_type = RoleTypes.FINANCE_ADMINISTRATOR;
//                } else if (usr_role_type == 3) {
//                    user_has_role_type = RoleTypes.INPUTER;
//                } else if (usr_role_type == 4) {
//                    user_has_role_type = RoleTypes.AUTHORIZER;
//                } else if (usr_role_type == 5) {
//                    user_has_role_type = RoleTypes.FINANCE_AUTHORIZER;
//                } else if (usr_role_type == 6) {
//                    user_has_role_type = RoleTypes.OTHER_LINE_ADMINISTRATOR;
//                }

                m_jsObj.put("user_has_role_id", _rs.getInt("user_has_role_id"));
                m_jsObj.put("user_has_role_user", _rs.getInt("user_has_role_user"));
                m_jsObj.put("user_has_role_type", user_has_role_type);
                m_jsObj.put("user_has_role_type_flag", _rs.getInt("user_has_role_type"));
                m_jsObj.put("user_EPF", _rs.getInt("user_EPF"));
                m_jsObj.put("user_firstname", _rs.getString("user_firstname"));
                m_jsObj.put("user_lastname", _rs.getString("user_lastname"));
                m_jsObj.put("user_NIC", _rs.getString("user_NIC"));
                m_jsObj.put("user_has_role_status_flag", _rs.getInt("user_has_role_status_flag"));
                m_jsObj.put("user_has_role_setup_user", _rs.getString("user_has_role_setup_user"));
                m_jsObj.put("RowsCount", _rs.getInt("RowsCount"));

                _jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {

            log.error(e.getMessage());

        } finally {

            try {

                if (_rs != null) {
                    _rs.close();
                }

                if (_prep_statement_1 != null) {
                    _prep_statement_1.close();
                }

                if (_currentCon != null) {
                    _currentCon.close();
                }

            } catch (Exception e) {

                gcsm_responceHandler.setResponceModule("save_Users_Role");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("0001");
                gcsm_responceHandler.setResponceDescription("Error occured.!\n" + e);
                log.error(e.getMessage());

            }

        }

        return _jsArr;
    }

    @Override
    public JSONArray getInfoUsersRoles(JSONObject jasonobj) {

        database_Connection = DatabaseConnection.getInstance();
        _currentCon = database_Connection.get_JDBC_Connection();
        String main_AdministrationQry = "";
        JSONObject m_jsObj;
        _jsArr = new JSONArray();

        int i = 0;

        try {

            main_AdministrationQry
                    = "SELECT usr_role.* ,\n"
                    + "usr.user_EPF as user_EPF,\n"
                    + "usr.user_name_first as user_firstname,\n"
                    + "usr.user_name_last as user_lastname,\n"
                    + "usr.user_NIC as user_NIC\n"
                    + "FROM\n"
                    + "gcsm_user_has_role usr_role , gcsm_user usr\n"
                    + "WHERE\n"
                    + "usr_role.user_has_role_user = usr.user_id AND user_has_role_id = '" + jasonobj.get("user_has_role_id") + "' \n"
                    + "ORDER BY \n"
                    + "usr_role.user_has_role_id \n"
                    + "LIMIT 1;";

            _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry);
            _rs = _prep_statement_1.executeQuery();

            while (_rs.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("user_has_role_id", _rs.getInt("user_has_role_id"));
                m_jsObj.put("user_has_role_user", _rs.getInt("user_has_role_user"));
                m_jsObj.put("user_has_role_type", _rs.getInt("user_has_role_type"));
                m_jsObj.put("user_has_role_status_flag", _rs.getInt("user_has_role_status_flag"));
                m_jsObj.put("user_NIC", _rs.getString("user_NIC"));
                m_jsObj.put("user_EPF", _rs.getInt("user_EPF"));
                m_jsObj.put("user_firstname", _rs.getString("user_firstname"));
                m_jsObj.put("user_lastname", _rs.getString("user_lastname"));

                String privilagesQuery = "select * from gcsm_user_page_privilages where authorization_status=1 and user_name in (select user_username from gcsm_user where user_id in (select user_has_role_user from gcsm_user_has_role where user_has_role_id='" + jasonobj.get("user_has_role_id") + "'))";
                _prep_statement_2 = _currentCon.prepareStatement(privilagesQuery);
                _rs2 = _prep_statement_2.executeQuery();

                List privilages = new ArrayList<String>();
                while (_rs2.next()) {
                    privilages.add(_rs2.getString("page"));
                }

                m_jsObj.put("pageNames", privilages.toArray());

                _jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {

            log.error(e.getMessage());

        } finally {

            try {

                if (_rs != null) {
                    _rs.close();
                }

                if (_prep_statement_1 != null) {
                    _prep_statement_1.close();
                }

                if (_currentCon != null) {
                    _currentCon.close();
                }

            } catch (Exception e) {

                gcsm_responceHandler.setResponceModule("save_Users_Role");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("0001");
                gcsm_responceHandler.setResponceDescription("Error occured.!\n" + e);
                log.error(e.getMessage());

            }

        }

        return _jsArr;

    }

    @Override
    public JSONArray getInfoUser(JSONObject jasonobj) {

        database_Connection = DatabaseConnection.getInstance();
        _currentCon = database_Connection.get_JDBC_Connection();
        String main_AdministrationQry = "";
        JSONObject m_jsObj;
        _jsArr = new JSONArray();

        int i = 0;

        try {

            main_AdministrationQry
                    = "SELECT * ,\n"
                    + "bl.bl_name as user_businessline_name\n"
                    + "FROM\n"
                    + "gcsm_user usr, gcsm_businessline bl\n"
                    + "WHERE\n"
                    + "usr.user_businessline = bl.bl_id AND usr.user_EPF='" + jasonobj.get("user_EPF") + "' AND usr.user_NIC='" + jasonobj.get("user_NIC") + "' \n"
                    + "ORDER BY \n"
                    + "user_id \n"
                    + "LIMIT 1;";

            _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry);
            _rs = _prep_statement_1.executeQuery();

            while (_rs.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("user_id", _rs.getInt("user_id"));
                m_jsObj.put("user_businessline", _rs.getInt("user_businessline"));
                m_jsObj.put("user_name_first", _rs.getString("user_name_first"));
                m_jsObj.put("user_name_last", _rs.getString("user_name_last"));
                m_jsObj.put("user_businessline_name", _rs.getString("user_businessline_name"));

                _jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {

            log.error(e.getMessage());

        } finally {

            try {

                if (_rs != null) {
                    _rs.close();
                }

                if (_prep_statement_1 != null) {
                    _prep_statement_1.close();
                }

                if (_currentCon != null) {
                    _currentCon.close();
                }

            } catch (Exception e) {

                gcsm_responceHandler.setResponceModule("save_Users_Role");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("0001");
                gcsm_responceHandler.setResponceDescription("Error occured.!\n" + e);
                log.error(e.getMessage());

            }

        }

        return _jsArr;

    }

    @Override
    public JSONArray getPrivilegeStatus(JSONObject jasonobj) {
        JSONObject m_jsObj = new JSONObject();
        database_Connection = DatabaseConnection.getInstance();
        _currentCon = database_Connection.get_JDBC_Connection();
        String checkPrivilegeQuery = "";
        _jsArr = new JSONArray();
        String user_name = jasonobj.get("username").toString();
        String pageName = jasonobj.get("pageName").toString();

        try {

            checkPrivilegeQuery = "SELECT authorization_status from gcsm_user_page_privilages where user_name=? and page=?";

            _prep_statement_1 = _currentCon.prepareStatement(checkPrivilegeQuery);
            _prep_statement_1.setString(1, user_name);
            _prep_statement_1.setString(2, pageName);
            _rs = _prep_statement_1.executeQuery();
            boolean isPrivilege = false;

            while (_rs.next()) {

                isPrivilege = _rs.getInt("authorization_status") == 1;

            }
            m_jsObj.put("isPrivilege", isPrivilege);
            _jsArr.put(m_jsObj);

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (_rs != null) {
                    _rs.close();
                }

                if (_prep_statement_1 != null) {
                    _prep_statement_1.close();
                }

                if (_currentCon != null) {
                    _currentCon.close();
                }

            } catch (Exception e) {

                gcsm_responceHandler.setResponceModule("save_Users_Role");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("0001");
                gcsm_responceHandler.setResponceDescription("Error occured.!\n" + e);
                log.error(e.getMessage());

            }

        }

        return _jsArr;

    }

}
