/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Administration.DAO.Impl;

import gcsm.Administration.DAO.UserManagementDAO;
import gcsm.Administration.Model.UserManagementModel;
import gcsm.Utitlities.Impl.Auditing;
import gcsm.Utitlities.Impl.DatabaseConnection;
import gcsm.Utitlities.Impl.Encryption;
import gcsm.Utitlities.Impl.JSONObjects;
import gcsm.Utitlities.Model.JSPPages;
import gcsm.Utitlities.Model.ResponceHandler;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Janaka_5977
 */
public class UserManagementDAOImpl implements UserManagementDAO {

    static Logger log = LogManager.getLogger(UserDAOImpl.class.getName());

    private JSONObjects gcsm_Jason;
    private JSONArray _jsArr;
    private Encryption encryption;

    @Override
    public ResponceHandler saveUser(JSONObject jasonobj) {

        String auditType = "";
        Auditing auditing = new Auditing();
        String related_table = "gcsm_user";
        String record_pk = "";
        String old_value = "##Empty##";

        ResponceHandler GCSMResponseHandler = new ResponceHandler();
        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        PreparedStatement preparedStatement2 = null;
        ResultSet rs = null;
        String session_username = jasonobj.get("session_username").toString();
        JSONObjects GCSMJSON = new JSONObjects();
        UserManagementModel userManagementModel = GCSMJSON.convertUserManagementModelToJSON(jasonobj.toString());

        try {
            if (!databaseConnection.start_Connection(currentConnection)) {

                GCSMResponseHandler.setResponceModule("save_User");
                GCSMResponseHandler.setResponceType("error");
                GCSMResponseHandler.setResponceCode("00001");
                GCSMResponseHandler.setResponceDescription("Uh oh! An error occurred, database connection establishing problem.");

                log.error("database connection establishing problem.");
                throw new Exception("An error occurred, database connection establishing problem.");

            } else {
                String query = "SELECT * FROM gcsm_user WHERE user_NIC=?";

                preparedStatement = currentConnection.prepareStatement(query);
                preparedStatement.setString(1, userManagementModel.getUser_NIC());
                rs = preparedStatement.executeQuery();

                if (rs.next()) {

                    GCSMResponseHandler.setResponceModule("save_User");
                    GCSMResponseHandler.setResponceType("error");;
                    GCSMResponseHandler.setResponceCode("00001");
                    GCSMResponseHandler.setResponceDescription("Uh oh! An error occurred, record already exists in the databse.");

                    log.error("record already exists in the databse.");
                    throw new Exception("An error occurred, record already exists in the databse.");

                } else {
                    query
                            = "INSERT INTO gcsm_user("
                            + "user_businessline," //1
                            + "user_name_first," //2
                            + "user_name_last," //3
                            + "user_username," //4
                            + "user_password," //5
                            + "user_NIC," //6
                            + "user_EPF," //7
                            + "user_status_flag," //8
                            + "user_role," //9
                            + "user_designation," //10
                            + "user_type," //11
                            + "user_setup_user," //12
                            + "user_setup_timestamp,"
                            + "user_modified_user," //13
                            + "user_modified_timestamp,"
                            + "record_auth_status)"
                            + " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,now(),?,now(),0)";

                    preparedStatement = currentConnection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
                    preparedStatement.setInt(1, userManagementModel.getUser_businessline());
                    preparedStatement.setString(2, userManagementModel.getUser_name_first());
                    preparedStatement.setString(3, userManagementModel.getUser_name_last());
                    preparedStatement.setString(4, userManagementModel.getUser_username());
                    encryption = new Encryption();
                    String pass = userManagementModel.getUser_password();
                    preparedStatement.setString(5, encryption.encrypt(pass));

                    preparedStatement.setString(6, userManagementModel.getUser_NIC());
                    preparedStatement.setInt(7, userManagementModel.getUser_EPF());
                    preparedStatement.setInt(8, userManagementModel.getUser_status_flag());
                    preparedStatement.setString(9, userManagementModel.getUser_role());
                    preparedStatement.setString(10, userManagementModel.getUser_designation());
                    preparedStatement.setInt(11, userManagementModel.getUser_type());
                    preparedStatement.setString(12, session_username);
                    preparedStatement.setString(13, session_username);

                    if (preparedStatement.executeUpdate() <= 0) {

                        GCSMResponseHandler.setResponceModule("save_User");
                        GCSMResponseHandler.setResponceType("error");
                        GCSMResponseHandler.setResponceCode("0001");
                        GCSMResponseHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to insert this record.");
                        log.error("unable to insert this record.");

                    } else {

                        String[] pageNames = jasonobj.getString("user_privileges").split(",");
                        String[] allPages = JSPPages.PAGES;
                        Arrays.sort(allPages);
                        Arrays.sort(pageNames);
                        for (String allPageName : allPages) {
                            int authorizationStatus = 1;
                            if (Arrays.binarySearch(pageNames, allPageName) < 0) {
                                authorizationStatus = 0;
                            }
                            String query2
                                    = "INSERT INTO gcsm_user_page_privilages (user_name,page,authorization_status) \n"
                                    + "values (?,?,?)";

                            preparedStatement2 = currentConnection.prepareStatement(query2);
                            preparedStatement2.setString(1, userManagementModel.getUser_username());
                            preparedStatement2.setString(2, allPageName);
                            preparedStatement2.setInt(3, authorizationStatus);

                            preparedStatement2.executeUpdate();

                        }

                        if (!databaseConnection.end_Connection(currentConnection)) {
                            GCSMResponseHandler.setResponceModule("save_User");
                            GCSMResponseHandler.setResponceType("error");
                            GCSMResponseHandler.setResponceCode("0001");
                            GCSMResponseHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                            log.error("database connection terminating problem.");
                            throw new Exception("An error occurred, database connection terminating problem.");
                        }

                        rs = preparedStatement.getGeneratedKeys();

                        //Audit Trail
                        auditType = "INSERT";
                        if (rs.first()) {
                            record_pk = "" + (rs.getInt(1));
                        }

                        //Audit Trail
                        String new_value = auditing.getAllRecords(record_pk, related_table).toString();
                        auditing.saveAuditRecord(session_username, related_table, auditType, record_pk, old_value, new_value);

                        GCSMResponseHandler.setResponceModule("save_User");
                        GCSMResponseHandler.setResponceType("success");
                        GCSMResponseHandler.setResponceCode("0000");
                        GCSMResponseHandler.setResponceDescription("Awesome! You were successful.");
                        log.info("update successful.");
                    }
                }

            }
        } catch (Exception e) {

            GCSMResponseHandler.setResponceModule("save_User");
            GCSMResponseHandler.setResponceType("error");
            GCSMResponseHandler.setResponceCode("00002");
            GCSMResponseHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to insert this record.\n" + e);
            log.error("unable to insert this record : " + e);
            log.error(e.getMessage());

        } finally {

            try {

                if (rs != null) {
                    rs.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {

                GCSMResponseHandler.setResponceModule("save_User");
                GCSMResponseHandler.setResponceType("error");
                GCSMResponseHandler.setResponceCode("0001");
                GCSMResponseHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to insert this record.\n" + e);
                log.error("unable to insert this record : " + e);
                log.error(e.getMessage());
            }
        }

        return GCSMResponseHandler;

    }

    @Override
    public ResponceHandler updateUser(JSONObject jasonobj) {

        String auditType = "UPDATE";
        Auditing auditing = new Auditing();
        String related_table = "gcsm_user";
        String record_pk = "";
        String old_value = "##Empty##";

        ResponceHandler GCSMResponseHandler = new ResponceHandler();
        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement1 = null;
        PreparedStatement preparedStatement2 = null;
        ResultSet rs = null;
        String session_username = jasonobj.get("session_username").toString();
        JSONObjects GCSMJSON = new JSONObjects();
        UserManagementModel userManagementModel = GCSMJSON.convertUserManagementModelToJSON(jasonobj.toString());

        try {
            if (!databaseConnection.start_Connection(currentConnection)) {

                GCSMResponseHandler.setResponceModule("updateUser");
                GCSMResponseHandler.setResponceType("error");
                GCSMResponseHandler.setResponceCode("00001");
                GCSMResponseHandler.setResponceDescription("Uh oh! An error occurred, database connection establishing problem.");

                log.error("database connection establishing problem.");
                throw new Exception("An error occurred, database connection establishing problem.");

            } else {
                if (userManagementModel.getUser_id() != 0) {
//                     Audit Trail
                    record_pk = "" + userManagementModel.getUser_id();
                    old_value = auditing.getAllRecords(record_pk, related_table).toString();

                    String query
                            = "UPDATE gcsm_user SET \n"
                            + "user_businessline=?," //1
                            + "user_name_first=?," //2
                            + "user_name_last=?," //3
                            + "user_EPF=?," //4
                            + "user_status_flag=?," //5
                            + "user_role=?," //6
                            + "user_designation=?," //7
                            + "user_type=?," //8
                            + "user_modified_user=?," //9
                            + "user_modified_timestamp=now(), "
                            + "record_auth_status=0 "
                            + "WHERE user_id=?";        //10

                    preparedStatement1 = currentConnection.prepareStatement(query);
                    preparedStatement1.setInt(1, userManagementModel.getUser_businessline());
                    preparedStatement1.setString(2, userManagementModel.getUser_name_first());
                    preparedStatement1.setString(3, userManagementModel.getUser_name_last());
                    preparedStatement1.setInt(4, userManagementModel.getUser_EPF());
                    preparedStatement1.setInt(5, userManagementModel.getUser_status_flag());
                    preparedStatement1.setString(6, userManagementModel.getUser_role());
                    preparedStatement1.setString(7, userManagementModel.getUser_designation());
                    preparedStatement1.setInt(8, userManagementModel.getUser_type());
                    preparedStatement1.setString(9, session_username);
                    preparedStatement1.setInt(10, userManagementModel.getUser_id());

                    if (preparedStatement1.executeUpdate() <= 0) {

                        GCSMResponseHandler.setResponceModule("updateUser");
                        GCSMResponseHandler.setResponceType("error");
                        GCSMResponseHandler.setResponceCode("0001");
                        GCSMResponseHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");
                        log.error("unable to update this record.");

                    } else {
                        GCSMResponseHandler.setResponceModule("updateUser");
                        GCSMResponseHandler.setResponceType("success");
                        GCSMResponseHandler.setResponceCode("0000");
                        GCSMResponseHandler.setResponceDescription("Awesome! You were successful.");
                        log.info("update successful.");

                        //update userprivilages for selected privilages
                        String[] pageNames = jasonobj.getString("user_privileges").split(",");
                        String[] allPages = JSPPages.PAGES;
                        Arrays.sort(allPages);
                        Arrays.sort(pageNames);
                        for (String allPageName : allPages) {
                            int authorizationStatus = 1;
                            if (Arrays.binarySearch(pageNames, allPageName) < 0) {
                                authorizationStatus = 0;
                            }
                            String query2
                                    = "UPDATE gcsm_user_page_privilages SET \n"
                                    + "authorization_status=? "
                                    + "WHERE page=? and user_name=?";

                            preparedStatement2 = currentConnection.prepareStatement(query2);
                            preparedStatement2.setInt(1, authorizationStatus);
                            preparedStatement2.setString(2, allPageName);
                            preparedStatement2.setString(3, userManagementModel.getUser_NIC());
                            preparedStatement2.executeUpdate();
                        }
                    }

                }

                if (!databaseConnection.end_Connection(currentConnection)) {
                    GCSMResponseHandler.setResponceModule("update");
                    GCSMResponseHandler.setResponceType("error");
                    GCSMResponseHandler.setResponceCode("0001");
                    GCSMResponseHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                    log.error("database connection terminating problem.");
                    throw new Exception("An error occurred, database connection terminating problem.");
                }

                //Audit Trail
                String new_value = auditing.getAllRecords(record_pk, related_table).toString();
                auditing.saveAuditRecord(session_username, related_table, auditType, record_pk, old_value, new_value);

                GCSMResponseHandler.setResponceModule("updateUser");
                GCSMResponseHandler.setResponceType("success");
                GCSMResponseHandler.setResponceCode("0000");
                GCSMResponseHandler.setResponceDescription("Awesome! You were successful.");
                log.info("update successful.");
            }
        } catch (Exception e) {

            GCSMResponseHandler.setResponceModule("updateUser");
            GCSMResponseHandler.setResponceType("error");
            GCSMResponseHandler.setResponceCode("00002");
            GCSMResponseHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to insert this record.\n" + e);
            log.error("unable to insert this record : " + e);
            log.error(e.getMessage());

        } finally {

            try {

                if (rs != null) {
                    rs.close();
                }

                if (preparedStatement1 != null) {
                    preparedStatement1.close();
                }
                if (preparedStatement2 != null) {
                    preparedStatement2.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {

                GCSMResponseHandler.setResponceModule("updateUser");
                GCSMResponseHandler.setResponceType("error");
                GCSMResponseHandler.setResponceCode("0001");
                GCSMResponseHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to insert this record.\n" + e);
                log.error("unable to insert this record : " + e);
                log.error(e.getMessage());
            }
        }

        return GCSMResponseHandler;

    }

    @Override
    public JSONArray getTableUsers(JSONObject jasonobj) {

        DatabaseConnection database_Connection = DatabaseConnection.getInstance();
        Connection _currentCon = database_Connection.get_JDBC_Connection();
        String main_AdministrationQry = "";
        JSONObject m_jsObj;
        JSONArray _jsArr = new JSONArray();
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        ResponceHandler GCSMResponseHandler = new ResponceHandler();

        int i = 0;

        try {

            main_AdministrationQry
                    = "SELECT usr.*, "
                    + "bl.bl_name as user_businessline_name "
                    + "FROM "
                    + "gcsm_user usr, gcsm_businessline bl "
                    + "WHERE "
                    + "usr.user_businessline = bl.bl_id AND "
                    + "usr.user_username !='root' ORDER BY user_id ;";

            preparedStatement = _currentCon.prepareStatement(main_AdministrationQry);
            rs = preparedStatement.executeQuery();

            while (rs.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("user_id", rs.getInt("user_id"));
                m_jsObj.put("user_businessline", rs.getInt("user_businessline"));
                m_jsObj.put("user_name_first", rs.getString("user_name_first"));
                m_jsObj.put("user_name_last", rs.getString("user_name_last"));
                m_jsObj.put("user_username", rs.getString("user_username"));
                m_jsObj.put("user_NIC", rs.getString("user_NIC"));
                m_jsObj.put("user_EPF", rs.getInt("user_EPF"));
                m_jsObj.put("user_designation", rs.getString("user_designation"));
                m_jsObj.put("user_role", rs.getString("user_role"));
                m_jsObj.put("user_type", rs.getInt("user_type"));
                m_jsObj.put("user_status_flag", rs.getInt("user_status_flag"));
                m_jsObj.put("user_setup_user", rs.getString("user_setup_user"));
                m_jsObj.put("user_setup_timestamp", rs.getString("user_setup_timestamp"));
                m_jsObj.put("user_modified_user", rs.getString("user_modified_user"));
                m_jsObj.put("user_modified_timestamp", rs.getString("user_modified_timestamp"));
                m_jsObj.put("user_auth_user", rs.getString("user_auth_user"));
                m_jsObj.put("user_auth_timestamp", rs.getString("user_auth_timestamp"));
                m_jsObj.put("user_businessline_name", rs.getString("user_businessline_name"));
                m_jsObj.put("record_auth_status", rs.getInt("record_auth_status"));
                m_jsObj.put("record_auth_comment", rs.getString("record_auth_comment"));
                _jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {

            log.error(e.getMessage());

        } finally {

            try {

                if (rs != null) {
                    rs.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (_currentCon != null) {
                    _currentCon.close();
                }

            } catch (Exception e) {

                GCSMResponseHandler.setResponceModule("get_Table_Users");
                GCSMResponseHandler.setResponceType("error");
                GCSMResponseHandler.setResponceCode("0001");
                GCSMResponseHandler.setResponceDescription("Error occured.!\n" + e);
                log.error(e.getMessage());

            }

        }

        return _jsArr;

    }

    @Override
    public JSONArray getInfoUsers(JSONObject jasonobj) {

        DatabaseConnection database_Connection = DatabaseConnection.getInstance();
        Connection _currentCon = database_Connection.get_JDBC_Connection();
        String main_AdministrationQry = "";
        JSONObject m_jsObj;
        JSONArray _jsArr = new JSONArray();
        PreparedStatement _prep_statement_1 = null;
        PreparedStatement _prep_statement_2 = null;
        ResultSet _rs = null;
        ResultSet _rs2 = null;
        ResponceHandler GCSMResponseHandler = new ResponceHandler();

        int i = 0;

        try {

            main_AdministrationQry
                    = "SELECT * ,\n"
                    + "bl.bl_name as user_businessline_name\n"
                    + "FROM\n"
                    + "gcsm_user usr, gcsm_businessline bl\n"
                    + "WHERE\n"
                    + "usr.user_businessline = bl.bl_id AND user_id = '" + jasonobj.get("user_id") + "' ORDER BY user_id ;";

            _prep_statement_1 = _currentCon.prepareStatement(main_AdministrationQry);
            _rs = _prep_statement_1.executeQuery();

            while (_rs.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("user_id", _rs.getInt("user_id"));
                m_jsObj.put("user_businessline", _rs.getInt("user_businessline"));
                m_jsObj.put("user_name_first", _rs.getString("user_name_first"));
                m_jsObj.put("user_name_last", _rs.getString("user_name_last"));
                m_jsObj.put("user_username", _rs.getString("user_username"));
                m_jsObj.put("user_NIC", _rs.getString("user_NIC"));
                m_jsObj.put("user_EPF", _rs.getInt("user_EPF"));
                m_jsObj.put("user_role", _rs.getString("user_role"));
                m_jsObj.put("user_designation", _rs.getString("user_designation"));
                m_jsObj.put("user_status_flag", _rs.getInt("user_status_flag"));
                m_jsObj.put("user_type", _rs.getInt("user_type"));

                String privilagesQuery = "select * from gcsm_user_page_privilages where authorization_status=1 and user_name ='" + _rs.getString("user_username") + "'";
                _prep_statement_2 = _currentCon.prepareStatement(privilagesQuery);
                _rs2 = _prep_statement_2.executeQuery();

                List privilages = new ArrayList<>();
                while (_rs2.next()) {
                    privilages.add(_rs2.getString("page"));
                }
                System.out.println(privilages);
                m_jsObj.put("pageNames", privilages.toArray());

                m_jsObj.put("user_businessline_name", _rs.getString("user_businessline_name"));

                _jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {

            log.error(e.getMessage());

        } finally {

            try {

                if (_rs != null) {
                    _rs.close();
                }
                if (_rs2 != null) {
                    _rs2.close();
                }

                if (_prep_statement_1 != null) {
                    _prep_statement_1.close();
                }
                if (_prep_statement_2 != null) {
                    _prep_statement_2.close();
                }

                if (_currentCon != null) {
                    _currentCon.close();
                }

            } catch (Exception e) {

                GCSMResponseHandler.setResponceModule("get_Info_Users");
                GCSMResponseHandler.setResponceType("error");
                GCSMResponseHandler.setResponceCode("0001");
                GCSMResponseHandler.setResponceDescription("Error occured.!\n" + e);
                log.error(e.getMessage());
            }
        }
        return _jsArr;

    }

    @Override
    public ResponceHandler checkPasswordForPasswordChange(JSONObject jasonobj) {
        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        JSONObject m_jsObj;
        JSONArray jsArr = new JSONArray();
        String username = jasonobj.get("username").toString();
        String password = jasonobj.get("current_password").toString();
        ResponceHandler gcsm_responceHandler = new ResponceHandler();

        encryption = new Encryption();
        String en_password = encryption.encrypt(String.valueOf(password));

        try {
            String queryCheckPassword = "SELECT user_id FROM gcsm_user where user_username=? and user_password=?";

            preparedStatement = currentConnection.prepareStatement(queryCheckPassword);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, en_password);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.first()) {
                gcsm_responceHandler.setResponceModule("user_id");
                gcsm_responceHandler.setResponceType("success");
                gcsm_responceHandler.setResponceCode("0000");
                gcsm_responceHandler.setResponceDescription("User_id exitsts");

            } else {
                gcsm_responceHandler.setResponceModule("user_id");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("0001");
                gcsm_responceHandler.setResponceDescription("Current Password is incorrect.");
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                gcsm_responceHandler.setResponceModule("user_id");
                gcsm_responceHandler.setResponceType("error");
                gcsm_responceHandler.setResponceCode("0001");
                gcsm_responceHandler.setResponceDescription("Error occured in user_id retrieving");
                log.error(e.getMessage());
            }

        }

        return gcsm_responceHandler;
    }

    @Override
    public ResponceHandler changePassword(JSONObject jasonobj) {
        ResponceHandler responceHandler = new ResponceHandler();
        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        JSONObjects jsonObejcts = new JSONObjects();
        String username = jasonobj.get("username").toString();
        String password = jasonobj.get("new_password").toString();

        //Audit Trail
        Auditing auditing = new Auditing();
        String auditType = "UPDATE";
        String related_table = "gcsm_user";
        String record_pk = "";
        String old_value = "";

        encryption = new Encryption();
        String en_password = encryption.encrypt(String.valueOf(password));

        try {

            String shadowOtherAmountsUpdateSuery
                    = "UPDATE gcsm_user "
                    + "set user_password=? " //1                     
                    + "where user_username=?";        //2

            preparedStatement = currentConnection.prepareStatement(shadowOtherAmountsUpdateSuery);
            preparedStatement.setString(1, en_password);
            preparedStatement.setString(2, username);

            //Audit Trail 
            String userID = getUserID(username);
            record_pk = "" + userID;
            old_value = auditing.getAllRecords(record_pk, related_table).toString();

            if (preparedStatement.executeUpdate() <= 0) {

                responceHandler.setResponceModule("changePassword");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");

            }

            responceHandler.setResponceModule("changePassword");
            responceHandler.setResponceType("success");
            responceHandler.setResponceCode("0000");
            responceHandler.setResponceDescription("Success");

            if (!databaseConnection.end_Connection(currentConnection)) {

                responceHandler.setResponceModule("changePassword");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("Uh oh! An error occurred, database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }

            //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            auditing.saveAuditRecord(jasonobj.getString("performing_username"), related_table, auditType, record_pk, old_value, new_value);

        } catch (SQLException ex) {
            log.error(ex.getMessage());

        } catch (Exception ex) {
            log.error(ex.getMessage());
        } finally {

            try {

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {

                responceHandler.setResponceModule("modifyOtherContractvalue");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in modifyOtherContractvalue");
                log.error(e.getMessage());

            }
        }
        return responceHandler;
    }

    private String getUserID(String username) {
        String userID = "";

        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            if (!databaseConnection.start_Connection(currentConnection)) {

            } else {
                String sql = "select user_id from gcsm_user where user_username=?";
                preparedStatement = currentConnection.prepareStatement(sql);
                preparedStatement.setString(1, username);
                resultSet = preparedStatement.executeQuery();

                while (resultSet.next()) {
                    userID = resultSet.getString("user_id");
                }
            }

            databaseConnection.end_Connection(currentConnection);

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (currentConnection != null) {
                    currentConnection.close();
                }
            } catch (Exception e) {
               log.error(e.getMessage());
            }

        }

        return userID;
    }

    @Override
    public JSONArray getPrivilegeStatus(JSONObject jasonobj) {
        JSONObject m_jsObj = new JSONObject();
        DatabaseConnection database_Connection = DatabaseConnection.getInstance();
        Connection _currentCon = database_Connection.get_JDBC_Connection();
        String checkPrivilegeQuery = "";
        JSONArray _jsArr = new JSONArray();
        String user_name = jasonobj.get("username").toString();
        String pageName = jasonobj.get("pageName").toString();
        PreparedStatement _prep_statement_1 = null;
        ResultSet _rs = null;
        ResponceHandler responceHandler = new ResponceHandler();

        try {

            checkPrivilegeQuery = "SELECT authorization_status from gcsm_user_page_privilages where user_name=? and page=?";

            _prep_statement_1 = _currentCon.prepareStatement(checkPrivilegeQuery);
            _prep_statement_1.setString(1, user_name);
            _prep_statement_1.setString(2, pageName);
            _rs = _prep_statement_1.executeQuery();
            boolean isPrivilege = false;

            while (_rs.next()) {

                isPrivilege = _rs.getInt("authorization_status") == 1;

            }
            m_jsObj.put("isPrivilege", isPrivilege);
            _jsArr.put(m_jsObj);

        } catch (Exception e) {
            log.error(e);

        } finally {

            try {

                if (_rs != null) {
                    _rs.close();
                }

                if (_prep_statement_1 != null) {
                    _prep_statement_1.close();
                }

                if (_currentCon != null) {
                    _currentCon.close();
                }

            } catch (Exception e) {

                responceHandler.setResponceModule("getPrivilegeStatus");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured.!\n" + e);
                log.error(e.getMessage());

            }

        }

        return _jsArr;

    }

    @Override
    public ResponceHandler approveUserDetals(JSONObject jasonobj) {
        ResponceHandler responceHandler = new ResponceHandler();
        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        JSONObjects jsonObejcts = new JSONObjects();
        String username = jasonobj.get("session_username").toString();
        String userID = jasonobj.get("user_id").toString();
        String rejectApprove = jasonobj.get("rejectApprove").toString();
        String rejectReason = jasonobj.get("user_reject_reason").toString();

        //Audit Trail
        Auditing auditing = new Auditing();
        String auditType = "UPDATE";
        String related_table = "gcsm_user";
        String record_pk = "";
        String old_value = "";

        try {

            String shadowOtherAmountsUpdateSuery
                    = "UPDATE gcsm_user "
                    + "set record_auth_status=?, "//1
                    + "record_auth_comment=?, "//2
                    + "user_auth_user=?, "//3
                    + "user_auth_timestamp=now() "
                    + "where user_id=?";        //4

            preparedStatement = currentConnection.prepareStatement(shadowOtherAmountsUpdateSuery);
            preparedStatement.setString(1, rejectApprove);
            preparedStatement.setString(2, rejectReason);
            preparedStatement.setString(3, username);
            preparedStatement.setString(4, userID);

            //Audit Trail 
//            String userID=getUserID(username);
            record_pk = "" + userID;
            old_value = auditing.getAllRecords(record_pk, related_table).toString();

            if (preparedStatement.executeUpdate() <= 0) {

                responceHandler.setResponceModule("approveUserDetals");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");

            }

            responceHandler.setResponceModule("approveUserDetals");
            responceHandler.setResponceType("success");
            responceHandler.setResponceCode("0000");
            responceHandler.setResponceDescription("Success");

            if (!databaseConnection.end_Connection(currentConnection)) {

                responceHandler.setResponceModule("approveUserDetals");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("Uh oh! An error occurred, database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }

            //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            auditing.saveAuditRecord(username, related_table, auditType, record_pk, old_value, new_value);

        } catch (SQLException ex) {
            log.error(ex.getMessage());

        } catch (Exception ex) {
            log.error(ex.getMessage());
        } finally {

            try {

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {

                responceHandler.setResponceModule("approveUserDetals");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in modifyOtherContractvalue");
                log.error(e.getMessage());

            }
        }
        return responceHandler;
    }

}
