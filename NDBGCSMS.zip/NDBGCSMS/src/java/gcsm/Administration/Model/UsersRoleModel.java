/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Administration.Model;

/**
 *
 * @author Randika_10992
 */
public class UsersRoleModel {
    
    private int user_has_role_id;
    private int user_has_role_user;
    private int user_has_role_type ;
    private int user_has_role_status_flag;
    private String session_username;

    /**
     * @return the user_has_role_id
     */
    public int getUser_has_role_id() {
        return user_has_role_id;
    }

    /**
     * @param user_has_role_id the user_has_role_id to set
     */
    public void setUser_has_role_id(int user_has_role_id) {
        this.user_has_role_id = user_has_role_id;
    }

    /**
     * @return the user_has_role_user
     */
    public int getUser_has_role_user() {
        return user_has_role_user;
    }

    /**
     * @param user_has_role_user the user_has_role_user to set
     */
    public void setUser_has_role_user(int user_has_role_user) {
        this.user_has_role_user = user_has_role_user;
    }

    /**
     * @return the user_has_role_type
     */
    public int getUser_has_role_type() {
        return user_has_role_type;
    }

    /**
     * @param user_has_role_type the user_has_role_type to set
     */
    public void setUser_has_role_type(int user_has_role_type) {
        this.user_has_role_type = user_has_role_type;
    }

    /**
     * @return the user_has_role_status_flag
     */
    public int getUser_has_role_status_flag() {
        return user_has_role_status_flag;
    }

    /**
     * @param user_has_role_status_flag the user_has_role_status_flag to set
     */
    public void setUser_has_role_status_flag(int user_has_role_status_flag) {
        this.user_has_role_status_flag = user_has_role_status_flag;
    }

    /**
     * @return the session_username
     */
    public String getSession_username() {
        return session_username;
    }

    /**
     * @param session_username the session_username to set
     */
    public void setSession_username(String session_username) {
        this.session_username = session_username;
    }  
   
    
}
