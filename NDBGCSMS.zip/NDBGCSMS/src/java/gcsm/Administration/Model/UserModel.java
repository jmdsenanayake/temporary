/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Administration.Model;

/**
 *
 * @author Randika_10992
 */
public class UserModel {
    
    
    private int user_id;
    private int user_businessline;
    private String user_name_first ;
    private String user_name_last;
    private String user_username;
    private String user_password;
    private String user_NIC;
    private String user_designation;
    private int user_EPF;
    private int user_status_flag;
    private String session_username;  

    /**
     * @return the user_id
     */
    public int getUser_id() {
        return user_id;
    }

    /**
     * @param user_id the user_id to set
     */
    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    /**
     * @return the user_businessline
     */
    public int getUser_businessline() {
        return user_businessline;
    }

    /**
     * @param user_businessline the user_businessline to set
     */
    public void setUser_businessline(int user_businessline) {
        this.user_businessline = user_businessline;
    }

    /**
     * @return the user_name_first
     */
    public String getUser_name_first() {
        return user_name_first;
    }

    /**
     * @param user_name_first the user_name_first to set
     */
    public void setUser_name_first(String user_name_first) {
        this.user_name_first = user_name_first;
    }

    /**
     * @return the user_name_last
     */
    public String getUser_name_last() {
        return user_name_last;
    }

    /**
     * @param user_name_last the user_name_last to set
     */
    public void setUser_name_last(String user_name_last) {
        this.user_name_last = user_name_last;
    }

    /**
     * @return the user_username
     */
    public String getUser_username() {
        return user_username;
    }

    /**
     * @param user_username the user_username to set
     */
    public void setUser_username(String user_username) {
        this.user_username = user_username;
    }

    /**
     * @return the user_password
     */
    public String getUser_password() {
        return user_password;
    }

    /**
     * @param user_password the user_password to set
     */
    public void setUser_password(String user_password) {
        this.user_password = user_password;
    }

    /**
     * @return the user_NIC
     */
    public String getUser_NIC() {
        return user_NIC;
    }

    /**
     * @param user_NIC the user_NIC to set
     */
    public void setUser_NIC(String user_NIC) {
        this.user_NIC = user_NIC;
    }

    /**
     * @return the user_EPF
     */
    public int getUser_EPF() {
        return user_EPF;
    }

    /**
     * @param user_EPF the user_EPF to set
     */
    public void setUser_EPF(int user_EPF) {
        this.user_EPF = user_EPF;
    }

    /**
     * @return the user_status_flag
     */
    public int getUser_status_flag() {
        return user_status_flag;
    }

    /**
     * @param user_status_flag the user_status_flag to set
     */
    public void setUser_status_flag(int user_status_flag) {
        this.user_status_flag = user_status_flag;
    }

    /**
     * @return the session_username
     */
    public String getSession_username() {
        return session_username;
    }

    /**
     * @param session_username the session_username to set
     */
    public void setSession_username(String session_username) {
        this.session_username = session_username;
    }

    /**
     * @return the user_designation
     */
    public String getUser_designation() {
        return user_designation;
    }

    /**
     * @param user_designation the user_designation to set
     */
    public void setUser_designation(String user_designation) {
        this.user_designation = user_designation;
    }
   
    
}
