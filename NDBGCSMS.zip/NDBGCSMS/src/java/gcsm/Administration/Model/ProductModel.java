/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Administration.Model;

/**
 *
 * @author Randika_10992
 */
public class ProductModel {

    private int product_id;
    private String product_name;
    private String product_description;
    private String product_type;
    private int product_businessline;
    private int product_status_flag;
    private String session_username;
    private String product_shadow_basis;
    private double product_annual_fee;
    private String product_contract_value_retrive_from;
    private double product_alco_approved_tp_rate;

    /**
     * @return the product_id
     */
    public int getProduct_id() {
        return product_id;
    }

    /**
     * @param product_id the product_id to set
     */
    public void setProduct_id(int product_id) {
        this.product_id = product_id;
    }

    /**
     * @return the product_name
     */
    public String getProduct_name() {
        return product_name;
    }

    /**
     * @param product_name the product_name to set
     */
    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    /**
     * @return the product_description
     */
    public String getProduct_description() {
        return product_description;
    }

    /**
     * @param product_description the product_description to set
     */
    public void setProduct_description(String product_description) {
        this.product_description = product_description;
    }

    /**
     * @return the product_businessline
     */
    public int getProduct_businessline() {
        return product_businessline;
    }

    /**
     * @param product_businessline the product_businessline to set
     */
    public void setProduct_businessline(int product_businessline) {
        this.product_businessline = product_businessline;
    }

    /**
     * @return the product_status_flag
     */
    public int getProduct_status_flag() {
        return product_status_flag;
    }

    /**
     * @param product_status_flag the product_status_flag to set
     */
    public void setProduct_status_flag(int product_status_flag) {
        this.product_status_flag = product_status_flag;
    }

    /**
     * @return the session_username
     */
    public String getSession_username() {
        return session_username;
    }

    /**
     * @param session_username the session_username to set
     */
    public void setSession_username(String session_username) {
        this.session_username = session_username;
    }

    /**
     * @return the product_shadow_basis
     */
    public String getProduct_shadow_basis() {
        return product_shadow_basis;
    }

    /**
     * @param product_shadow_basis the product_shadow_basis to set
     */
    public void setProduct_shadow_basis(String product_shadow_basis) {
        this.product_shadow_basis = product_shadow_basis;
    }

    /**
     * @return the product_annual_fee
     */
    public double getProduct_annual_fee() {
        return product_annual_fee;
    }

    /**
     * @param product_annual_fee the product_annual_fee to set
     */
    public void setProduct_annual_fee(double product_annual_fee) {
        this.product_annual_fee = product_annual_fee;
    }

    /**
     * @return the product_type
     */
    public String getProduct_type() {
        return product_type;
    }

    /**
     * @param product_type the product_type to set
     */
    public void setProduct_type(String product_type) {
        this.product_type = product_type;
    }

    /**
     * @return the product_contract_value_retrive_from
     */
    public String getProduct_contract_value_retrive_from() {
        return product_contract_value_retrive_from;
    }

    /**
     * @param product_contract_value_retrive_from the product_contract_value_retrive_from to set
     */
    public void setProduct_contract_value_retrive_from(String product_contract_value_retrive_from) {
        this.product_contract_value_retrive_from = product_contract_value_retrive_from;
    }

    /**
     * @return the product_alco_approved_tp_rate
     */
    public double getProduct_alco_approved_tp_rate() {
        return product_alco_approved_tp_rate;
    }

    /**
     * @param product_alco_approved_tp_rate the product_alco_approved_tp_rate to set
     */
    public void setProduct_alco_approved_tp_rate(double product_alco_approved_tp_rate) {
        this.product_alco_approved_tp_rate = product_alco_approved_tp_rate;
    }
    
    
}
