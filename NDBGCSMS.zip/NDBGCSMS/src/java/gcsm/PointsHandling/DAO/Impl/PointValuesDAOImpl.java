/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.PointsHandling.DAO.Impl;

import gcsm.PointsHandling.DAO.PointValuesDAO;
import gcsm.PointsHandling.Model.PointValuesModel;
import gcsm.Utitlities.Impl.Auditing;
import gcsm.Utitlities.Impl.DatabaseConnection;
import gcsm.Utitlities.Impl.JSONObjects;
import gcsm.Utitlities.Model.ResponceHandler;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Janaka_5977
 */
public class PointValuesDAOImpl implements PointValuesDAO {

    static Logger log = LogManager.getLogger(PointValuesDAOImpl.class.getName());
    private ResponceHandler responceHandler;
    static DatabaseConnection databaseConnection;
    static Connection currentConnection = null;
    private PreparedStatement preparedStatement = null;
    private ResultSet resultSet = null;
    private JSONObjects jsonObejcts;
    private JSONArray jsArr;

    @Override
    public JSONArray viewPointValues(JSONObject jasonobj) {
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();
        try {
            String queryViewPointValues = "SELECT point_value_id, point_A_upper_value, point_A_lower_value, point_B_upper_value, point_B_lower_value, point_C_upper_value, point_C_lower_value, point_D_upper_value, point_D_lower_value, point_value_status, point_value_setup_user, point_value_setup_timestamp, ifnull(point_value_approve_reject_user,'---') as point_value_approve_reject_user, ifnull(point_value_approve_reject_timestamp,'---') as point_value_approve_reject_timestamp, ifnull(point_value_approve_reject_comment,'---') as point_value_approve_reject_comment FROM gcsm_point_values order by point_value_status DESC,point_value_approve_reject_timestamp DESC";

            

            preparedStatement = currentConnection.prepareStatement(queryViewPointValues);
            resultSet = preparedStatement.executeQuery();
            int i = 0;
            while (resultSet.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("point_value_id", resultSet.getInt("point_value_id"));
                m_jsObj.put("point_A_upper_value", resultSet.getDouble("point_A_upper_value"));
                m_jsObj.put("point_A_lower_value", resultSet.getDouble("point_A_lower_value"));
                m_jsObj.put("point_B_upper_value", resultSet.getDouble("point_B_upper_value"));
                m_jsObj.put("point_B_lower_value", resultSet.getDouble("point_B_lower_value"));
                m_jsObj.put("point_C_upper_value", resultSet.getDouble("point_C_upper_value"));
                m_jsObj.put("point_C_lower_value", resultSet.getDouble("point_C_lower_value"));
                m_jsObj.put("point_D_upper_value", resultSet.getDouble("point_D_upper_value"));
                m_jsObj.put("point_D_lower_value", resultSet.getDouble("point_D_lower_value"));
                m_jsObj.put("point_value_status", resultSet.getInt("point_value_status"));
                m_jsObj.put("point_value_setup_user", resultSet.getString("point_value_setup_user"));
                m_jsObj.put("point_value_setup_timestamp", resultSet.getString("point_value_setup_timestamp"));
                m_jsObj.put("point_value_approve_reject_user", resultSet.getString("point_value_approve_reject_user"));
                m_jsObj.put("point_value_approve_reject_timestamp", resultSet.getString("point_value_approve_reject_timestamp"));
                m_jsObj.put("point_value_approve_reject_comment", resultSet.getString("point_value_approve_reject_comment"));
                jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("View_PointValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return jsArr;
    }

    @Override
    public ResponceHandler insertPointValues(JSONObject jasonobj) {
        responceHandler = new ResponceHandler();
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        jsonObejcts = new JSONObjects();
        PointValuesModel newPointValuesModel;

        String session_username = jasonobj.get("user_username").toString();

        //Audit Trail        
        Auditing auditing = new Auditing();
        String auditType = "INSERT";
        String related_table = "gcsm_point_values";
        String record_pk = "";
        String old_value = "##Empty##";

        try {
            newPointValuesModel = jsonObejcts.convertPointValuesModelToJSON(jasonobj.toString());

            String insertPointValuesQuery
                    = "INSERT INTO gcsm_point_values ("
                    + "point_A_upper_value, " //1
                    + "point_A_lower_value, " //2
                    + "point_B_upper_value, " //3
                    + "point_B_lower_value, " //4
                    + "point_C_upper_value, " //5
                    + "point_C_lower_value," //6
                    + "point_D_upper_value, " //7
                    + "point_D_lower_value," //8
                    + "point_value_status," //9
                    + "point_value_setup_user," //10
                    + "point_value_setup_timestamp) "
                    + "values (?,?,?,?,?,?,?,?,?,?,now())";

            preparedStatement = currentConnection.prepareStatement(insertPointValuesQuery, Statement.RETURN_GENERATED_KEYS);
            preparedStatement.setDouble(1, newPointValuesModel.getPoint_A_upper_value());
            preparedStatement.setDouble(2, newPointValuesModel.getPoint_A_lower_value());
            preparedStatement.setDouble(3, newPointValuesModel.getPoint_B_upper_value());
            preparedStatement.setDouble(4, newPointValuesModel.getPoint_B_lower_value());
            preparedStatement.setDouble(5, newPointValuesModel.getPoint_C_upper_value());
            preparedStatement.setDouble(6, newPointValuesModel.getPoint_C_lower_value());
            preparedStatement.setDouble(7, newPointValuesModel.getPoint_D_upper_value());
            preparedStatement.setDouble(8, newPointValuesModel.getPoint_D_lower_value());
            preparedStatement.setInt(9, 0);
            preparedStatement.setString(10, session_username);

            if (preparedStatement.executeUpdate() <= 0) {

                responceHandler.setResponceModule("insertPointValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");

            }

            responceHandler.setResponceModule("insertPointValues");
            responceHandler.setResponceType("success");
            responceHandler.setResponceCode("0000");
            responceHandler.setResponceDescription("Awesome! You were successful.");

            //Audit Trail
            resultSet = preparedStatement.getGeneratedKeys();
            resultSet.next();
            record_pk = "" + (resultSet.getInt(1));

            if (!databaseConnection.end_Connection(currentConnection)) {

                responceHandler.setResponceModule("insertPointValues");
                responceHandler.setResponceType("error");;
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("Uh oh! An error occurred, database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }

            //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            auditing.saveAuditRecord(session_username, related_table, auditType, record_pk, old_value, new_value);

        } catch (SQLException ex) {
            log.error(ex.getMessage());

        } catch (Exception ex) {
            log.error(ex.getMessage());
        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("insertPointValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert Point Value");

            }

        }

        return responceHandler;

    }

    @Override
    public ResponceHandler verifyPointValues(JSONObject jasonobj, int approveReject) {
        responceHandler = new ResponceHandler();
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        jsonObejcts = new JSONObjects();
        PointValuesModel newPointValuesModel;

        String session_username = jasonobj.get("user_username").toString();

        //Audit Trail
        Auditing auditing = new Auditing();
        String auditType = "UPDATE";
        String related_table = "gcsm_point_values";
        String record_pk = "";
        String old_value = "";

        try {
            newPointValuesModel = jsonObejcts.convertPointValuesModelToJSON(jasonobj.toString());

            //Audit Trail
            record_pk = "" + newPointValuesModel.getPoint_value_id();
            old_value = auditing.getAllRecords(record_pk, related_table).toString();

            String pointValuesVerifyQuery
                    = "UPDATE gcsm_point_values "
                    + "set point_value_status=" + approveReject + ", "
                    + "point_value_approve_reject_comment=?, " //1
                    + "point_value_approve_reject_user=?, " //2
                    + "point_value_approve_reject_timestamp=now() "
                    + "where point_value_id=?";              //3

            preparedStatement = currentConnection.prepareStatement(pointValuesVerifyQuery);
            preparedStatement.setString(1, newPointValuesModel.getPoint_value_approve_reject_comment());
            preparedStatement.setString(2, jasonobj.get("user_username").toString());
            preparedStatement.setInt(3, newPointValuesModel.getPoint_value_id());

            if (preparedStatement.executeUpdate() <= 0) {

                responceHandler.setResponceModule("verify_Point_Values_Details");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");

            }

            responceHandler.setResponceModule("verify_Point_Values_Details");
            responceHandler.setResponceType("success");
            responceHandler.setResponceCode("0000");
            responceHandler.setResponceDescription((approveReject == 1) ? "Succefully Approved" : "Successfully Rejected");

            if (!databaseConnection.end_Connection(currentConnection)) {

                responceHandler.setResponceModule("verify_Point_Values_Details");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("Uh oh! An error occurred, database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }

            //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            auditing.saveAuditRecord(session_username, related_table, auditType, record_pk, old_value, new_value);

        } catch (SQLException ex) {
            log.error(ex.getMessage());

        } catch (Exception ex) {
            log.error(ex.getMessage());
        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("verify_Point_Values_Details");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return responceHandler;
    }

}
