/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.PointsHandling.DAO;

import gcsm.Utitlities.Model.ResponceHandler;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Janaka_5977
 */
public interface CalculatePointsDAO {
    public void calculateAndStorePointDetails(String relatedUser, String targetValue, String setupUser);
    
    public JSONArray viewPointDetails(JSONObject jasonobj);
    
    public ResponceHandler initiatePointCalculationStatus(JSONObject jasonobj);
    
    public JSONArray checkInitiationStatus(JSONObject jasonobj);    
    
    public void updatePointsCalculationStatus(int status,String session_username);
    
    public ResponceHandler verifyPointsDetails(JSONObject jasonobj, int approveReject);
}
