/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Reports.DAO.Impl;

import gcsm.Reports.DAO.RewardReportDAO;
import gcsm.Utitlities.Impl.DatabaseConnection;
import gcsm.Utitlities.Impl.JSONObjects;
import gcsm.Utitlities.Model.ResponceHandler;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Janaka_5977
 */
public class RewardReportDAOImpl implements RewardReportDAO {

    static Logger log = LogManager.getLogger(RewardReportDAOImpl.class.getName());
    private ResponceHandler responceHandler;
    static DatabaseConnection databaseConnection;
    static Connection currentConnection = null;
    private PreparedStatement preparedStatement = null;
    private ResultSet resultSet = null;
    private JSONObjects jsonObejcts;
    private JSONArray jsArr;

    @Override
    public JSONArray fillRewardReportContent(JSONObject jasonobj) {
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();

        String reward_yearmonth_from = jasonobj.getString("reward_yearmonth_from");
        try {

            
            String queryVieRewardReports = ""
                    + "select \n"
                    + "    reward_contract_no, \n"
                    + "     cs_customer_name,      \n"
                    + "    cs_units_sold_by, \n"
                    + "     cs_employee_name, \n"
                    + "    reward_related_user,\n"
                    + "    prodowner.bl_name as cs_product_owner,\n"
                    + "    csowner.bl_name as cs_owner,\n"
                    + "    cs_product_status, \n"
                    + "    month(cs_date) as cs_month, \n"
                    + "    portfolio_value,\n"
                    + "    total_reward_amount      \n"
                    + "from \n"
                    + "     gcsm_reward_details, \n"
                    + "     gcsm_cross_selling_details,     \n"
                    + "    gcsm_businessline as prodowner,    \n"
                    + "     gcsm_businessline as csowner    \n"
                    + "where \n"
                    + "    reward_contract_no=cs_contract_no and\n"
                    + "    reward_yearmonth_from ='"+reward_yearmonth_from+"' and\n"
                    + "    reward_approval_status=1 and\n"
                    + "    cs_product_owner=prodowner.bl_id and\n"
                    + "    cs_own_company=csowner.bl_id\n"
                    + "    order by reward_related_user"; 
                    
           

            preparedStatement = currentConnection.prepareStatement(queryVieRewardReports);
            resultSet = preparedStatement.executeQuery();
            int i = 0;
            while (resultSet.next()) {
                m_jsObj = new JSONObject();

                m_jsObj.put("reward_contract_no", resultSet.getString("reward_contract_no"));
                m_jsObj.put("cs_customer_name", resultSet.getString("cs_customer_name"));
                m_jsObj.put("cs_units_sold_by", resultSet.getString("cs_units_sold_by"));
                m_jsObj.put("reward_related_user", resultSet.getString("reward_related_user"));
                m_jsObj.put("cs_employee_name", resultSet.getString("cs_employee_name"));
                m_jsObj.put("cs_owner", resultSet.getString("cs_owner"));
                m_jsObj.put("cs_product_owner", resultSet.getString("cs_product_owner"));
                m_jsObj.put("cs_product_status", resultSet.getString("cs_product_status"));
                m_jsObj.put("cs_month", resultSet.getString("cs_month"));
                m_jsObj.put("portfolio_value", String.format("%.2f", resultSet.getDouble("portfolio_value")));
                m_jsObj.put("total_reward_amount", String.format("%.2f", resultSet.getDouble("total_reward_amount")));
                jsArr.put(i, m_jsObj);
                i++;
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("View_crossSellingData");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");
            }
        }

        return jsArr;
    }

}
