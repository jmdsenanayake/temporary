/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Reports.DAO.Impl;

import static gcsm.Reports.DAO.Impl.RewardReportDAOImpl.databaseConnection;
import gcsm.Reports.DAO.PointsReportDAO;
import gcsm.Utitlities.Impl.DatabaseConnection;
import gcsm.Utitlities.Impl.JSONObjects;
import gcsm.Utitlities.Model.ResponceHandler;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Janaka_5977
 */
public class PointsDAOImpl implements PointsReportDAO{
    
    static Logger log = LogManager.getLogger(PointsDAOImpl.class.getName());
    private ResponceHandler responceHandler;
    static DatabaseConnection databaseConnection;
    static Connection currentConnection = null;
    private PreparedStatement preparedStatement = null;
    private ResultSet resultSet = null;
    private JSONObjects jsonObejcts;
    private JSONArray jsArr;

    @Override
    public JSONArray fillPointsReportContent(JSONObject data) {
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();

        String reward_yearmonth_from = data.getString("reward_yearmonth_from");
        String reward_yearmonth_to = data.getString("reward_yearmonth_to");
        try {

            
            String queryViewPointsReports = ""
                    + "SELECT * "
                    + "FROM gcsm_point_details "
                    + "where year_month_from=? and year_month_to=? and point_detail_status=1"; 
                    
           

            preparedStatement = currentConnection.prepareStatement(queryViewPointsReports);
            preparedStatement.setString(1, reward_yearmonth_from);
            preparedStatement.setString(2, reward_yearmonth_to);
            resultSet = preparedStatement.executeQuery();
            
            int i = 0;
            while (resultSet.next()) {
                m_jsObj = new JSONObject();

                m_jsObj.put("point_detail_id", resultSet.getString("point_detail_id"));
                m_jsObj.put("related_user", resultSet.getString("related_user"));
//                m_jsObj.put("cs_employee_name", resultSet.getString("cs_employee_name"));
//                m_jsObj.put("cs_units_sold_by", resultSet.getString("cs_units_sold_by"));
                m_jsObj.put("target_value", resultSet.getString("target_value"));
                m_jsObj.put("achivement_value", resultSet.getString("achivement_value"));
                m_jsObj.put("target_achivement_percentage", resultSet.getString("target_achivement_percentage"));
                m_jsObj.put("point_value", resultSet.getString("point_value"));
                jsArr.put(i, m_jsObj);
                i++;
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("fillPointsReportContent");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");
            }
        }

        return jsArr;
    }
    
}
