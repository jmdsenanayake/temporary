/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Reports.DAO.Impl;

import gcsm.Reports.DAO.CrossSellingReportsDAO;
import gcsm.Utitlities.Impl.DatabaseConnection;
import gcsm.Utitlities.Impl.JSONObjects;
import gcsm.Utitlities.Model.ResponceHandler;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Janaka_5977
 */
public class CrossSellingReportsDAOImpl implements CrossSellingReportsDAO {

    static Logger log = LogManager.getLogger(CrossSellingReportsDAOImpl.class.getName());
    private ResponceHandler responceHandler;
    static DatabaseConnection databaseConnection;
    static Connection currentConnection = null;
    private PreparedStatement preparedStatement = null;
    private ResultSet resultSet = null;
    private JSONObjects jsonObejcts;
    private JSONArray jsArr;

    @Override
    public JSONArray fillCrossSellingReportContent(JSONObject jasonobj) {
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();

        String yearMonth = jasonobj.getString("yearMonth");
        String ownCompany = jasonobj.getString("ownCompany");
        try {

            
            String queryViewCrossSellingReports = "SELECT \n"
                    + "	shadow_year_month,\n"
                    + "    csowner.bl_name as cs_own_company,\n"
                    + "    prodowner.bl_name as cs_product_owner,\n"
                    + "    cs_own_company, \n"
                    + "    cs_product_owner,\n"
                    + "    cs_customer_name,\n"
                    + "    shadow_cs_contract_no,\n"
                    + "    shadow_revenue_value,\n"
                    + "    shadow_portfolio_value    \n"
                    + "FROM \n"
                    + "	gcsm_cross_selling_details, \n"
                    + "    gcsm_shadow_revenue, \n"
                    + "    gcsm_businessline as csowner, \n"
                    + "    gcsm_businessline as prodowner    \n"
                    + "where \n"
                    + "	shadow_cs_contract_no=cs_contract_no and \n"
                    + "    shadow_year_month='" + yearMonth + "' and \n"
                    + "    cs_own_company='" + ownCompany + "' and \n"
                    + "    cs_own_company=csowner.bl_id and \n"
                    + "    cs_product_owner=prodowner.bl_id and"
                    + "    shadow_revenue_status=1;";

           

            preparedStatement = currentConnection.prepareStatement(queryViewCrossSellingReports);
            resultSet = preparedStatement.executeQuery();
            int i = 0;
            while (resultSet.next()) {
                m_jsObj = new JSONObject();

                m_jsObj.put("shadow_year_month", resultSet.getString("shadow_year_month"));
                m_jsObj.put("cs_own_company", resultSet.getString("cs_own_company"));
                m_jsObj.put("cs_product_owner", resultSet.getString("cs_product_owner"));
                m_jsObj.put("shadow_cs_contract_no", resultSet.getString("shadow_cs_contract_no"));
                m_jsObj.put("cs_customer_name", resultSet.getString("cs_customer_name"));
                m_jsObj.put("shadow_revenue_value", String.format("%.2f", resultSet.getDouble("shadow_revenue_value")));
                m_jsObj.put("shadow_portfolio_value", String.format("%.2f", resultSet.getDouble("shadow_portfolio_value")));
                jsArr.put(i, m_jsObj);
                i++;
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("View_crossSellingData");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");
            }
        }

        return jsArr;
    }
    
    @Override
    public JSONArray fillCrossSellingProductWiseReportContent(JSONObject jasonobj) {
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();

        String yearMonth = jasonobj.getString("yearMonth");
        String ownCompany = jasonobj.getString("ownCompany");
        try {

            
            String queryViewCrossSellingReports = "SELECT \n" +
                    "	shadow_year_month, \n" +
                    "    csowner.bl_name as cs_own_company,\n" +
                    "    prodowner.bl_name as cs_product_owner,\n" +
                    "    product_name,\n" +
                    "    cs_own_company,\n" +
                    "    cs_product_owner,\n" +
                    "    sum(shadow_revenue_value) as shadow_revenue_value,\n" +
                    "    sum(shadow_portfolio_value) as shadow_portfolio_value\n" +
                    "FROM \n" +
                    "	gcsm_cross_selling_details, \n" +
                    "    gcsm_shadow_revenue, \n" +
                    "    gcsm_businessline as csowner, \n" +
                    "    gcsm_businessline as prodowner,    \n" +
                    "    gcsm_product\n" +
                    "where \n" +
                    "  	shadow_cs_contract_no=cs_contract_no and \n" +
                    "    shadow_year_month='"+yearMonth+"' and \n" +
                    "    cs_own_company=csowner.bl_id and \n" +
                    "    cs_product_owner=prodowner.bl_id and\n" +
                    "    cs_product=product_id and\n" +
                    "    cs_own_company='"+ownCompany+"' and \n"+
                    "    shadow_revenue_status=1 "+
                    "group by \n" +
                    "	cs_product,prodowner.bl_name;";

            

            preparedStatement = currentConnection.prepareStatement(queryViewCrossSellingReports);
            resultSet = preparedStatement.executeQuery();
            int i = 0;
            while (resultSet.next()) {
                m_jsObj = new JSONObject();

                m_jsObj.put("shadow_year_month", resultSet.getString("shadow_year_month"));
                m_jsObj.put("cs_own_company", resultSet.getString("cs_own_company"));
                m_jsObj.put("cs_product_owner", resultSet.getString("cs_product_owner"));
                m_jsObj.put("product_name", resultSet.getString("product_name"));
                m_jsObj.put("shadow_revenue_value", String.format("%.2f", resultSet.getDouble("shadow_revenue_value")));
                m_jsObj.put("shadow_portfolio_value", String.format("%.2f", resultSet.getDouble("shadow_portfolio_value")));
                jsArr.put(i, m_jsObj);
                i++;
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("View_crossSellingData");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");
            }
        }

        return jsArr;
    }

    @Override
    public JSONArray getCrossSellingReportMonthlyVolume(JSONObject jasonobj) {

        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();

        String yearMonth = jasonobj.getString("yearMonth");
        String ownCompany = jasonobj.getString("ownCompany");

        try {
           

            String queryViewCrossSellingReports = "select \n"
                    + "	shadow_year_month,\n"
                    + "    sum(shadow_revenue_value) as shadow_revenue_value,\n"
                    + "    sum(shadow_portfolio_value) as total_volume_for_month,\n"
                    + "    csowner.bl_name as cs_own_company_name\n"
                    + "from \n"
                    + "	gcsm_cross_selling_details, \n"
                    + "    gcsm_shadow_revenue, \n"
                    + "	gcsm_businessline as csowner \n"
                    + "where \n"
                    + "	shadow_cs_contract_no=cs_contract_no and \n"
                    + "    shadow_year_month='"+yearMonth+"' and     \n"
                    + "    cs_own_company=csowner.bl_id and \n"
                    + "    cs_own_company='"+ownCompany+"' and \n"
                    + "    shadow_revenue_status=1;";

            

            preparedStatement = currentConnection.prepareStatement(queryViewCrossSellingReports);
            resultSet = preparedStatement.executeQuery();
            int i = 0;
            while (resultSet.next()) {
                m_jsObj = new JSONObject();
                m_jsObj.put("shadow_year_month", resultSet.getString("shadow_year_month"));
                m_jsObj.put("cs_own_company_name", resultSet.getString("cs_own_company_name"));
                m_jsObj.put("shadow_revenue_value", String.format("%.2f", resultSet.getDouble("shadow_revenue_value")));
                m_jsObj.put("total_volume_for_month", String.format("%.2f", resultSet.getDouble("total_volume_for_month")));
                jsArr.put(i, m_jsObj);
                i++;
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("View_crossSellingData");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");
            }
        }
        return jsArr;

    }

    @Override
    public JSONArray getCrossSellingOwnCompanies(JSONObject jasonobj) {

        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();

        String yearMonth = jasonobj.getString("yearMonth");

        try {
            String queryViewCrossSellingReports = "SELECT distinct cs_own_company FROM gcsm_cross_selling_details, gcsm_shadow_revenue where shadow_cs_contract_no=cs_contract_no and shadow_year_month='" + yearMonth + "';";
           

            preparedStatement = currentConnection.prepareStatement(queryViewCrossSellingReports);
            resultSet = preparedStatement.executeQuery();
            int i = 0;
            while (resultSet.next()) {
                m_jsObj = new JSONObject();
                m_jsObj.put("cs_own_company", resultSet.getString("cs_own_company"));
                jsArr.put(i, m_jsObj);
                i++;
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("View_crossSellingData");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");
            }
        }
        return jsArr;

    }

}
