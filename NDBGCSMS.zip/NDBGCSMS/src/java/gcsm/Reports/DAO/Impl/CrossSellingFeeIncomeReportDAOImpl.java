/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Reports.DAO.Impl;

import gcsm.Reports.DAO.CrossSellingFeeIncomeReportDAO;
import gcsm.Utitlities.Impl.DatabaseConnection;
import gcsm.Utitlities.Impl.JSONObjects;
import gcsm.Utitlities.Model.ResponceHandler;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Janaka_5977
 */
public class CrossSellingFeeIncomeReportDAOImpl implements CrossSellingFeeIncomeReportDAO {

    static Logger log = LogManager.getLogger(CrossSellingFeeIncomeReportDAOImpl.class.getName());
    private ResponceHandler responceHandler;
    static DatabaseConnection databaseConnection;
    static Connection currentConnection = null;
    private PreparedStatement preparedStatement = null;
    private ResultSet resultSet = null;
    private JSONObjects jsonObejcts;
    private JSONArray jsArr;

    @Override
    public JSONArray fillCrossSellingFeeIncomeReportContent(JSONObject jasonobj) {
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();

        String csYear = jasonobj.getString("csYear");
        try {

            //String queryViewCrossSellingReports = "SELECT shadow_year_month,cs_own_company, cs_product_owner,shadow_cs_contract_no,shadow_NII_value,portfolio_value FROM gcsm_cross_selling_details, gcsm_shadow_revenue, gcsm_reward_details where shadow_cs_contract_no=cs_contract_no and cs_contract_no=reward_contract_no and shadow_year_month='" + yearMonth + "' and cs_own_company='"+ownCompany+"'";           
            String queryViewCrossSellingFeeIncomeReports = ""
                    + "SELECT \n"
                    + "	cs_date,\n"
                    + "    prodowner.bl_name as cs_product_owner,\n"
                    + "    cs_fee,\n"
                    + "    product_name as cs_product,\n"
                    + "    cs_contract_no,\n"
                    + "    csowner.bl_name as cs_own_company,\n"
                    + "    cs_units_sold_by,\n"
                    + "    cs_employee_name\n"
                    + "FROM \n"
                    + "	gcsm_cross_selling_details,\n"
                    + "    gcsm_businessline as csowner,\n"
                    + "    gcsm_businessline as prodowner,\n"
                    + "    gcsm_product\n"
                    + "WHERE\n"
                    + "	cs_product=product_id and\n"
                    + "    cs_own_company=csowner.bl_id and\n"
                    + "    cs_product_owner=prodowner.bl_id and\n"
                     + "   cs_fee>0 and\n"
                    + "    year(cs_date)='"+csYear+"';";

            

            preparedStatement = currentConnection.prepareStatement(queryViewCrossSellingFeeIncomeReports);
            resultSet = preparedStatement.executeQuery();
            int i = 0;
            while (resultSet.next()) {
                m_jsObj = new JSONObject();

                m_jsObj.put("cs_date", resultSet.getString("cs_date"));
                m_jsObj.put("cs_product_owner", resultSet.getString("cs_product_owner"));
                m_jsObj.put("cs_fee", String.format("%.2f", resultSet.getDouble("cs_fee")));
                m_jsObj.put("cs_product", resultSet.getString("cs_product"));
                m_jsObj.put("cs_contract_no", resultSet.getString("cs_contract_no"));
                m_jsObj.put("cs_own_company", resultSet.getString("cs_own_company"));
                m_jsObj.put("cs_units_sold_by", resultSet.getString("cs_units_sold_by"));
                m_jsObj.put("cs_employee_name", resultSet.getString("cs_employee_name"));
                
                jsArr.put(i, m_jsObj);
                i++;
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("View_crossSellingFeeIncomeReportData");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");
            }
        }

        return jsArr;
    }

}
