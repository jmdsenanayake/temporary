/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.RewardsHandling.Model;

/**
 *
 * @author Janaka_5977
 */
public class RewardsValuesModel {
    private int reward_product_id;
    private int reward_level;
    private String tier1_reward_calc_method;
    private double tier1_reward_value_or_percentage;
    private String tier2_reward_calc_method;
    private double tier2_reward_value_or_percentage;
    private double reward_cap_value;
    private int reward_value_status;
    private String reward_value_setup_user;
    private String reward_value_setup_timestamp;
    private String reward_value_modified_user;
    private String reward_modified_timestamp;    
    private String reward_1_year_less_method;
    private double reward_1_year_less_percentage;
    private String reward_1_2_year_method;
    private double reward_1_2_year_percentage;
    private String reward_value_comments;

    /**
     * @return the reward_product_id
     */
    public int getReward_product_id() {
        return reward_product_id;
    }

    /**
     * @param reward_product_id the reward_product_id to set
     */
    public void setReward_product_id(int reward_product_id) {
        this.reward_product_id = reward_product_id;
    }

    /**
     * @return the reward_level
     */
    public int getReward_level() {
        return reward_level;
    }

    /**
     * @param reward_level the reward_level to set
     */
    public void setReward_level(int reward_level) {
        this.reward_level=reward_level;
    }

    /**
     * @return the tier1_reward_calc_method
     */
    public String getTier1_reward_calc_method() {
        return tier1_reward_calc_method;
    }

    /**
     * @param tier1_reward_calc_method the tier1_reward_calc_method to set
     */
    public void setTier1_reward_calc_method(String tier1_reward_calc_method) {
        this.tier1_reward_calc_method = tier1_reward_calc_method;
    }

    /**
     * @return the tier1_reward_value_or_percentage
     */
    public double getTier1_reward_value_or_percentage() {
        return tier1_reward_value_or_percentage;
    }

    /**
     * @param tier1_reward_value_or_percentage the tier1_reward_value_or_percentage to set
     */
    public void setTier1_reward_value_or_percentage(double tier1_reward_value_or_percentage) {
        this.tier1_reward_value_or_percentage = tier1_reward_value_or_percentage;
    }

    /**
     * @return the tier2_reward_calc_method
     */
    public String getTier2_reward_calc_method() {
        return tier2_reward_calc_method;
    }

    /**
     * @param tier2_reward_calc_method the tier2_reward_calc_method to set
     */
    public void setTier2_reward_calc_method(String tier2_reward_calc_method) {
        this.tier2_reward_calc_method = tier2_reward_calc_method;
    }

    /**
     * @return the tier2_reward_value_or_percentage
     */
    public double getTier2_reward_value_or_percentage() {
        return tier2_reward_value_or_percentage;
    }

    /**
     * @param tier2_reward_value_or_percentage the tier2_reward_value_or_percentage to set
     */
    public void setTier2_reward_value_or_percentage(double tier2_reward_value_or_percentage) {
        this.tier2_reward_value_or_percentage = tier2_reward_value_or_percentage;
    }

    /**
     * @return the reward_cap_value
     */
    public double getReward_cap_value() {
        return reward_cap_value;
    }

    /**
     * @param reward_cap_value the reward_cap_value to set
     */
    public void setReward_cap_value(double reward_cap_value) {
        this.reward_cap_value = reward_cap_value;
    }

    /**
     * @return the reward_value_status
     */
    public int getReward_value_status() {
        return reward_value_status;
    }

    /**
     * @param reward_value_status the reward_value_status to set
     */
    public void setReward_value_status(int reward_value_status) {
        this.reward_value_status = reward_value_status;
    }

    /**
     * @return the reward_value_setup_user
     */
    public String getReward_value_setup_user() {
        return reward_value_setup_user;
    }

    /**
     * @param reward_value_setup_user the reward_value_setup_user to set
     */
    public void setReward_value_setup_user(String reward_value_setup_user) {
        this.reward_value_setup_user = reward_value_setup_user;
    }

    /**
     * @return the reward_value_setup_timestamp
     */
    public String getReward_value_setup_timestamp() {
        return reward_value_setup_timestamp;
    }

    /**
     * @param reward_value_setup_timestamp the reward_value_setup_timestamp to set
     */
    public void setReward_value_setup_timestamp(String reward_value_setup_timestamp) {
        this.reward_value_setup_timestamp = reward_value_setup_timestamp;
    }

    /**
     * @return the reward_value_modified_user
     */
    public String getReward_value_modified_user() {
        return reward_value_modified_user;
    }

    /**
     * @param reward_value_modified_user the reward_value_modified_user to set
     */
    public void setReward_value_modified_user(String reward_value_modified_user) {
        this.reward_value_modified_user = reward_value_modified_user;
    }

    /**
     * @return the reward_modified_timestamp
     */
    public String getReward_modified_timestamp() {
        return reward_modified_timestamp;
    }

    /**
     * @param reward_modified_timestamp the reward_modified_timestamp to set
     */
    public void setReward_modified_timestamp(String reward_modified_timestamp) {
        this.reward_modified_timestamp = reward_modified_timestamp;
    }

    /**
     * @return the reward_1_year_less_method
     */
    public String getReward_1_year_less_method() {
        return reward_1_year_less_method;
    }

    /**
     * @param reward_1_year_less_method the reward_1_year_less_method to set
     */
    public void setReward_1_year_less_method(String reward_1_year_less_method) {
        this.reward_1_year_less_method = reward_1_year_less_method;
    }

    /**
     * @return the reward_1_year_less_percentage
     */
    public double getReward_1_year_less_percentage() {
        return reward_1_year_less_percentage;
    }

    /**
     * @param reward_1_year_less_percentage the reward_1_year_less_percentage to set
     */
    public void setReward_1_year_less_percentage(double reward_1_year_less_percentage) {
        this.reward_1_year_less_percentage = reward_1_year_less_percentage;
    }

    /**
     * @return the reward_1_2_year_method
     */
    public String getReward_1_2_year_method() {
        return reward_1_2_year_method;
    }

    /**
     * @param reward_1_2_year_method the reward_1_2_year_method to set
     */
    public void setReward_1_2_year_method(String reward_1_2_year_method) {
        this.reward_1_2_year_method = reward_1_2_year_method;
    }

    /**
     * @return the reward_1_2_year_percentage
     */
    public double getReward_1_2_year_percentage() {
        return reward_1_2_year_percentage;
    }

    /**
     * @param reward_1_2_year_percentage the reward_1_2_year_percentage to set
     */
    public void setReward_1_2_year_percentage(double reward_1_2_year_percentage) {
        this.reward_1_2_year_percentage = reward_1_2_year_percentage;
    }

    /**
     * @return the reward_value_comments
     */
    public String getReward_value_comments() {
        return reward_value_comments;
    }

    /**
     * @param reward_value_comments the reward_value_comments to set
     */
    public void setReward_value_comments(String reward_value_comments) {
        this.reward_value_comments = reward_value_comments;
    }


    
}
