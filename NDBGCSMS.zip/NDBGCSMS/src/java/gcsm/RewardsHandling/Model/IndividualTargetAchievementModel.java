/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.RewardsHandling.Model;

/**
 *
 * @author Janaka_5977
 */
public class IndividualTargetAchievementModel {

    private int achievement_id;
    private double core_target_asset;
    private double core_target_liabilities;
    private double core_target_achievement_asset;
    private double core_target_achievement_liabilities;
    private double cs_asset_achievement;
    private double cs_liabilities_achievement;
    private String period_from_yearmonth;
    private int target_achivement_status;
    private String approval_reject_comment;
    private String related_to;
    private String user_designation;

    /**
     * @return the achievement_id
     */
    public int getAchievement_id() {
        return achievement_id;
    }

    /**
     * @param achievement_id the achievement_id to set
     */
    public void setAchievement_id(int achievement_id) {
        this.achievement_id = achievement_id;
    }

    /**
     * @return the core_target_asset
     */
    public double getCore_target_asset() {
        return core_target_asset;
    }

    /**
     * @param core_target_asset the core_target_asset to set
     */
    public void setCore_target_asset(double core_target_asset) {
        this.core_target_asset = core_target_asset;
    }

    /**
     * @return the core_target_liabilities
     */
    public double getCore_target_liabilities() {
        return core_target_liabilities;
    }

    /**
     * @param core_target_liabilities the core_target_liabilities to set
     */
    public void setCore_target_liabilities(double core_target_liabilities) {
        this.core_target_liabilities = core_target_liabilities;
    }

    /**
     * @return the cs_asset_achievement
     */
    public double getCs_asset_achievement() {
        return cs_asset_achievement;
    }

    /**
     * @param cs_asset_achievement the cs_asset_achievement to set
     */
    public void setCs_asset_achievement(double cs_asset_achievement) {
        this.cs_asset_achievement = cs_asset_achievement;
    }

    /**
     * @return the cs_liabilities_achievement
     */
    public double getCs_liabilities_achievement() {
        return cs_liabilities_achievement;
    }

    /**
     * @param cs_liabilities_achievement the cs_liabilities_achievement to set
     */
    public void setCs_liabilities_achievement(double cs_liabilities_achievement) {
        this.cs_liabilities_achievement = cs_liabilities_achievement;
    }

    /**
     * @return the period_from_yearmonth
     */
    public String getPeriod_from_yearmonth() {
        return period_from_yearmonth;
    }

    /**
     * @param period_from_yearmonth the period_from_yearmonth to set
     */
    public void setPeriod_from_yearmonth(String period_from_yearmonth) {
        this.period_from_yearmonth = period_from_yearmonth;
    }

    /**
     * @return the target_achivement_status
     */
    public int getTarget_achivement_status() {
        return target_achivement_status;
    }

    /**
     * @param target_achivement_status the target_achivement_status to set
     */
    public void setTarget_achivement_status(int target_achivement_status) {
        this.target_achivement_status = target_achivement_status;
    }

    /**
     * @return the approval_reject_comment
     */
    public String getApproval_reject_comment() {
        return approval_reject_comment;
    }

    /**
     * @param approval_reject_comment the approval_reject_comment to set
     */
    public void setApproval_reject_comment(String approval_reject_comment) {
        this.approval_reject_comment = approval_reject_comment;
    }

    /**
     * @return the related_to
     */
    public String getRelated_to() {
        return related_to;
    }

    /**
     * @param related_to the related_to to set
     */
    public void setRelated_to(String related_to) {
        this.related_to = related_to;
    }

    /**
     * @return the core_target_achievement_asset
     */
    public double getCore_target_achievement_asset() {
        return core_target_achievement_asset;
    }

    /**
     * @param core_target_achievement_asset the core_target_achievement_asset to set
     */
    public void setCore_target_achievement_asset(double core_target_achievement_asset) {
        this.core_target_achievement_asset = core_target_achievement_asset;
    }

    /**
     * @return the core_target_achievement_liabilities
     */
    public double getCore_target_achievement_liabilities() {
        return core_target_achievement_liabilities;
    }

    /**
     * @param core_target_achievement_liabilities the core_target_achievement_liabilities to set
     */
    public void setCore_target_achievement_liabilities(double core_target_achievement_liabilities) {
        this.core_target_achievement_liabilities = core_target_achievement_liabilities;
    }

    /**
     * @return the user_designation
     */
    public String getUser_designation() {
        return user_designation;
    }

    /**
     * @param user_designation the user_designation to set
     */
    public void setUser_designation(String user_designation) {
        this.user_designation = user_designation;
    }

}
