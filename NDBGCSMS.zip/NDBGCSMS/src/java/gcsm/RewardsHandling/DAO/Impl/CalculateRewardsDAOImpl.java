/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.RewardsHandling.DAO.Impl;

import gcsm.RewardsHandling.DAO.CalculateRewardsDAO;
import gcsm.Utitlities.Impl.Auditing;
import gcsm.Utitlities.Impl.DatabaseConnection;
import gcsm.Utitlities.Impl.JSONObjects;
import gcsm.Utitlities.Impl.SQLServerDatabaseConnection;
import gcsm.Utitlities.Model.Designations;
import gcsm.Utitlities.Model.ResponceHandler;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Janaka_5977
 */
public class CalculateRewardsDAOImpl implements CalculateRewardsDAO {

    static Logger log = LogManager.getLogger(CalculateRewardsDAOImpl.class.getName());
    private ResponceHandler responceHandler;
    static DatabaseConnection databaseConnection;
    static Connection currentConnection = null;
    private PreparedStatement preparedStatement = null;
    private ResultSet resultSet = null;
    private JSONObjects jsonObejcts;
    private JSONArray jsArr;

    @Override
    public JSONArray checkInitiationStatus(JSONObject jasonobj) {
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();
        try {
            String queryInitiationStatusCheck = "SELECT status,period_from_yearmonth FROM gcsm_reward_calculation_status order by status_id desc limit 1";

            preparedStatement = currentConnection.prepareStatement(queryInitiationStatusCheck);
            resultSet = preparedStatement.executeQuery();
            int i = 0;
            while (resultSet.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("intiation_status", resultSet.getInt("status"));
                m_jsObj.put("period_from_yearmonth", resultSet.getString("period_from_yearmonth"));
                jsArr.put(i, m_jsObj);
                i++;

            }
            //If no reward calculation initiated
            if (i == 0) {
                m_jsObj = new JSONObject();
                m_jsObj.put("intiation_status", 0);
                jsArr.put(i, m_jsObj);
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("View_RewardValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return jsArr;
    }

    @Override
    public JSONArray getCalculatedRewardValues(JSONObject jasonobj) {
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();
        try {
            String queryToGetRewardDetails = "SELECT \n"
                    + "	reward_detail_id,\n"
                    + "    reward_related_user,\n"
                    + "    cs_employee_name,\n"
                    + "    cs_units_sold_by,\n"
                    + "    reward_contract_no,\n"
                    + "    product_name,\n"
                    + "    total_reward_amount,\n"
                    + "    reward_yearmonth_from,\n"
                    + "    reward_setup_timestamp,\n"
                    + "    reward_approval_status,\n"
                    + "    bl_name\n"
                    + " FROM \n"
                    + "	gcsm_reward_details,\n"
                    + "    gcsm_cross_selling_details,\n"
                    + "    gcsm_product,gcsm_businessline \n"
                    + "where \n"
                    + "	reward_contract_no=cs_contract_no and \n"
                    + "    cs_product=product_id and \n"
                    + "    bl_id=cs_own_company and \n"
                    + "    reward_yearmonth_from in (\n"
                    + "	SELECT \n"
                    + "		period_from_yearmonth \n"
                    + "	FROM \n"
                    + "		gcsm_reward_calculation_status \n"
                    + "	where \n"
                    + "		status=2\n"
                    + "	) \n"
                    + "order by \n"
                    + "	reward_setup_timestamp desc";

            preparedStatement = currentConnection.prepareStatement(queryToGetRewardDetails);
            resultSet = preparedStatement.executeQuery();
            int i = 0;
            while (resultSet.next()) {
                m_jsObj = new JSONObject();
                m_jsObj.put("reward_detail_id", resultSet.getInt("reward_detail_id"));
                m_jsObj.put("reward_related_user", resultSet.getString("reward_related_user"));
                m_jsObj.put("cs_employee_name", resultSet.getString("cs_employee_name"));
                m_jsObj.put("cs_units_sold_by", resultSet.getString("cs_units_sold_by"));
                m_jsObj.put("bl_name", resultSet.getString("bl_name"));
                m_jsObj.put("reward_contract_no", resultSet.getString("reward_contract_no"));
                m_jsObj.put("product_name", resultSet.getString("product_name"));
                m_jsObj.put("total_reward_amount", resultSet.getDouble("total_reward_amount"));
                m_jsObj.put("reward_yearmonth_from", resultSet.getString("reward_yearmonth_from"));
                m_jsObj.put("reward_setup_timestamp", resultSet.getString("reward_setup_timestamp"));
                m_jsObj.put("reward_approval_status", resultSet.getString("reward_approval_status"));
                jsArr.put(i, m_jsObj);
                i++;
            }
        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("View_RewardValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return jsArr;
    }

    @Override
    public void startRewardCalculation(JSONObject jasonobj) {
        String fromYearMonth = jasonobj.getString("fromYearMonth");
        calculateRewardAmount(fromYearMonth);
    }

    private List getPerformedContractNosForTargetAchievedUsers(String yearMonthFrom) {
        List contractNos = new ArrayList<String>();
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {

            String sql = "select cs_contract_no from gcsm_cross_selling_details where concat(cs_emp_id,' - ',cs_employee_name) in (select related_to from gcsm_individual_target_achievements where target_achivement_status=1 and related_to!='' and period_from_yearmonth=?) or cs_units_sold_by in (select related_to from gcsm_individual_target_achievements where target_achivement_status=1 and related_to!='' and period_from_yearmonth=?)";

            preparedStatement = currentConnection.prepareStatement(sql);
            preparedStatement.setString(1, yearMonthFrom);
            preparedStatement.setString(2, yearMonthFrom);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                contractNos.add(resultSet.getString("cs_contract_no"));
            }

        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return contractNos;
    }

    private Map getRewardValueDetails(String contract_no) {
        Map rewardValues = new HashMap<String, String>();
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {

            String sql = "select reward_product_id, reward_level, tier1_reward_calc_method, tier1_reward_value_or_percentage, ifnull(tier2_reward_calc_method,'') as tier2_reward_calc_method, ifnull(tier2_reward_value_or_percentage,0) as tier2_reward_value_or_percentage, reward_cap_value, reward_1_year_less_method, reward_1_year_less_percentage, reward_1_2_year_method, reward_1_2_year_percentage from gcsm_reward_values where reward_product_id in (select  cs_product from gcsm_cross_selling_details where cs_contract_no=?)";

            preparedStatement = currentConnection.prepareStatement(sql);
            preparedStatement.setString(1, contract_no);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                rewardValues.put("reward_product_id", resultSet.getString("reward_product_id"));
                rewardValues.put("reward_level", resultSet.getString("reward_level"));
                rewardValues.put("tier1_reward_calc_method", resultSet.getString("tier1_reward_calc_method"));
                rewardValues.put("tier1_reward_value_or_percentage", resultSet.getString("tier1_reward_value_or_percentage"));
                rewardValues.put("tier2_reward_calc_method", resultSet.getString("tier2_reward_calc_method"));
                rewardValues.put("tier2_reward_value_or_percentage", resultSet.getString("tier2_reward_value_or_percentage"));
                rewardValues.put("reward_cap_value", resultSet.getString("reward_cap_value"));
                rewardValues.put("reward_1_year_less_method", resultSet.getString("reward_1_year_less_method"));
                rewardValues.put("reward_1_year_less_percentage", resultSet.getString("reward_1_year_less_percentage"));
                rewardValues.put("reward_1_2_year_method", resultSet.getString("reward_1_2_year_method"));
                rewardValues.put("reward_1_2_year_percentage", resultSet.getString("reward_1_2_year_percentage"));
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        }
        return rewardValues;
    }

    private String getPerformedUser(String contractNo) {
        String username = "";
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {

            String sql = "select cs_emp_id,cs_units_sold_by from gcsm_cross_selling_details where cs_contract_no=?";

            preparedStatement = currentConnection.prepareStatement(sql);
            preparedStatement.setString(1, contractNo);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                username = resultSet.getString("cs_emp_id");
                username = username.equals("") ? resultSet.getString("cs_units_sold_by") : username;
            }

        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return username;
    }

    private boolean checkRewardsEligibility(String contractNo) {
        boolean isEligible = false;
        DatabaseConnection databaseConnection0 = DatabaseConnection.getInstance();
        Connection currentConnection0 = databaseConnection0.get_JDBC_Connection();
        ResultSet resultSet1 = null;
        PreparedStatement preparedStatement1 = null;

        ResultSet resultSet2 = null;
        PreparedStatement preparedStatement2 = null;

        ResultSet resultSet3 = null;
        PreparedStatement preparedStatement3 = null;

        String csOwnCompany = "";
        String csProdOwner = "";
        String userDesignation = "";
        try {

            String sql = "select cs_contract_no,cs_owner.bl_name as own_company, prod_owner.bl_name  as product_owner,cs_emp_id\n"
                    + "from gcsm_cross_selling_details, gcsm_businessline as cs_owner, gcsm_businessline as prod_owner \n"
                    + "where cs_owner.bl_id=cs_own_company and prod_owner.bl_id=cs_product_owner and  cs_contract_no=?";

            preparedStatement1 = currentConnection0.prepareStatement(sql);
            preparedStatement1.setString(1, contractNo);
            resultSet1 = preparedStatement1.executeQuery();
            String relatedUser = "";
            while (resultSet1.next()) {
                csOwnCompany = resultSet1.getString("own_company");
                csProdOwner = resultSet1.getString("product_owner");
                relatedUser = resultSet1.getString("cs_emp_id");
                System.out.println(csOwnCompany + csProdOwner);
            }

            System.out.println(relatedUser);

            if (!relatedUser.equals("")) {
                String sql2 = "SELECT user_designation FROM gcsm_individual_target_achievements where related_to like ?";
                preparedStatement2 = currentConnection0.prepareStatement(sql2);
                preparedStatement2.setString(1, relatedUser + "%");
                resultSet2 = preparedStatement2.executeQuery();

                while (resultSet2.next()) {
                    userDesignation = resultSet2.getString("user_designation");
                    System.out.println(userDesignation);
                }
            }

            String sql3 = "SELECT eligibility_designation FROM gcsm_reward_eligibility where eligibility_reward_from=? and eligibility_reward_to=?";
            preparedStatement3 = currentConnection0.prepareStatement(sql3);
            preparedStatement3.setString(1, csOwnCompany);
            preparedStatement3.setString(2, csProdOwner);
            resultSet3 = preparedStatement3.executeQuery();

            String eligibilityDesignations = "";
            while (resultSet3.next()) {
                eligibilityDesignations = resultSet3.getString("eligibility_designation");
            }

            System.out.println(eligibilityDesignations);

            if (userDesignation.equals("Any")) {
                if (eligibilityDesignations.split(",").length == Designations.DESIGNATIONS.length) {
                    isEligible = true;
                }
            } else {
                if (eligibilityDesignations.contains(userDesignation)) {
                    isEligible = true;
                }
            }

        } catch (Exception e) {
            log.error(e.getMessage());
        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());

            }

        }
        return isEligible;
    }

    private String getProductStatus(String contractNo) {
        String productStatus = "";
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {

            String sql = "select cs_product_status from gcsm_cross_selling_details where cs_contract_no=?";

            preparedStatement = currentConnection.prepareStatement(sql);
            preparedStatement.setString(1, contractNo);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                productStatus = resultSet.getString("cs_product_status");
            }

        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return productStatus;
    }

//    private double getPortfolioValue(String contractNo, String yearMonthFrom,String type) {
//        yearMonthFrom=yearMonthFrom.replace("-", "");
//        SQLServerDatabaseConnection sqlserver_databaseConnection = SQLServerDatabaseConnection.getInstance();;
//        Connection sqlserver_currentConnection = sqlserver_databaseConnection.get_JDBC_Connection();
//        PreparedStatement preparedStatement = null;
//        ResultSet resultSet = null;
//        double portfolioValue = 0;
//        try {
//            if (!sqlserver_databaseConnection.start_Connection(sqlserver_currentConnection)) {
//
//            } else {
//                String sql = "";
//                if (type.equals("AVG_6_MONTHS")) {
//                    sql = "select (sum(PORT_AMT)/6) AS PORT_AMT from SEG_PROFITABILITY_MAS where CON_REF_NO=? and UP_DT_KY=?";
//                } else if (type.equals("TOTAL")) {
//                    sql = "select TOP 1 PORT_AMT from SEG_PROFITABILITY_MAS where CON_REF_NO=? and UP_DT_KY=? and PORT_AMT!=0 order by UP_DT_KY ";
//                }
//                preparedStatement = sqlserver_currentConnection.prepareStatement(sql);
//
//                preparedStatement.setString(1, contractNo);
//                preparedStatement.setString(2, yearMonthFrom);
//
//                resultSet = preparedStatement.executeQuery();
//                while (resultSet.next()) {
//                    portfolioValue = resultSet.getDouble("PORT_AMT");
//                }
//            }
//            sqlserver_databaseConnection.end_Connection(sqlserver_currentConnection);
//
//        } catch (Exception e) {
//            log.error(e.getMessage());
//
//        } finally {
//            try {
//                if (resultSet != null) {
//                    resultSet.close();
//                }
//                if (preparedStatement != null) {
//                    preparedStatement.close();
//                }
//                if (sqlserver_currentConnection != null) {
//                    sqlserver_currentConnection.close();
//                }
//            } catch (Exception e) {
//                log.error(e.getMessage());
//
//            }
//        }
//        return portfolioValue;
//    }
    private double getInitialYearRewardedAmount(String contractNo, String type) {
        //this will get the Intitial year rewarded amounth
        double initialYearRewardedAmount = 0;

        //perfom a mysql query to get all the previous year details
        double initialYearTotalRewardedAmount = 0;

        double intitalYearTier2RewardedAmount = 0;

        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {

            String sql = "select  tier2_reward_amount_for_new,total_reward_amount_for_new from gcsm_reward_details where reward_contract_no=? order by reward_approved_timestamp desc limit 1";

            preparedStatement = currentConnection.prepareStatement(sql);
            preparedStatement.setString(1, contractNo);

            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                initialYearTotalRewardedAmount = resultSet.getDouble("total_reward_amount_for_new");
                intitalYearTier2RewardedAmount = resultSet.getDouble("tier2_reward_amount_for_new");
            }

            if (type.equals("Total")) {
                initialYearRewardedAmount = initialYearTotalRewardedAmount;

            } else if (type.equals("Tier2")) {
                initialYearRewardedAmount = intitalYearTier2RewardedAmount;
            }

        } catch (Exception e) {
            log.error(e.getMessage());
        }

        return initialYearRewardedAmount;
    }

    private void calculateRewardAmount(String yearMonthFrom) {

        List<String> contractNos = getPerformedContractNosForTargetAchievedUsers(yearMonthFrom);

        //List<String> RewardEligibleContractNos=getRewardEligibleContractList(contractNos, yearMonthTo);
        //contractNos.retainAll(RewardEligibleContractNos);
        for (String contractNo : contractNos) {
            boolean isEligible = checkRewardsEligibility(contractNo);

            if (isEligible) {
                double tier1RewardAmountForNew = 0;
                double tier2RewardAmountForNew = 0;

                double totalRewardAmountForNew = 0;

                double rewardAmountRenewal1YearLess = 0;
                double rewardAmountRenewal1To2Year = 0;

                double totalRewardAmountForRenewal = 0;

                double totalRewardAmount = 0;

                String perfomedUser = getPerformedUser(contractNo);

                String productStatus = getProductStatus(contractNo);
                Map rewardValueDetails = getRewardValueDetails(contractNo);

                int rewardLevel = Integer.parseInt(rewardValueDetails.get("reward_level").toString());

                String tier1RewardCalcMethod = rewardValueDetails.get("tier1_reward_calc_method").toString();
                double tier1RewardCalcValOrPercentage = Double.parseDouble(rewardValueDetails.get("tier1_reward_value_or_percentage").toString());

                String tier2RewardCalcMethod = rewardValueDetails.get("tier2_reward_calc_method").toString();
                double tier2RewardCalcValOrPercentage = Double.parseDouble(rewardValueDetails.get("tier2_reward_value_or_percentage").toString());

                double rewardCapValue = Double.parseDouble(rewardValueDetails.get("reward_cap_value").toString());                

                String reward1YearLessMethod = rewardValueDetails.get("reward_1_year_less_method").toString();
                double reward1YearLessPercentage = Double.parseDouble(rewardValueDetails.get("reward_1_year_less_percentage").toString());

                String reward1to2YearMethod = rewardValueDetails.get("reward_1_2_year_method").toString();
                double reward1to2YearPercentage = Double.parseDouble(rewardValueDetails.get("reward_1_2_year_percentage").toString());

                String type = (tier1RewardCalcMethod.equals("Percentage on Average 6 Months Balance") || tier2RewardCalcMethod.equals("Percentage on Average 6 Months Balance")) ? "AVG_6_MONTHS" : "TOTAL";

                double portfolioValue = 0;

                boolean isTwoTierProductsWithValueAndAVG6Months = (rewardLevel == 2 && tier1RewardCalcMethod.equals("Value") && tier2RewardCalcMethod.equals("Percentage on Average 6 Months Balance"));

                if (productStatus.equalsIgnoreCase("New")) {

                    if (isTwoTierProductsWithValueAndAVG6Months) {
                        double[] rewardAmounts = getRewardAmountsForTwoTierProductsWithValueAndAVG6Months(tier1RewardCalcValOrPercentage, tier2RewardCalcValOrPercentage, contractNo, yearMonthFrom);
                        portfolioValue = rewardAmounts[0];
                        tier1RewardAmountForNew = rewardAmounts[1];
                        tier2RewardAmountForNew = rewardAmounts[2];
                        totalRewardAmountForNew = tier1RewardAmountForNew + tier2RewardAmountForNew;

                    } else {
                        portfolioValue = getPortfolioValue(contractNo, yearMonthFrom, type);
                        if (rewardLevel == 1) {

                            switch (tier1RewardCalcMethod) {
                                case "Value":
                                    tier1RewardAmountForNew = tier1RewardCalcValOrPercentage;
                                    break;
                                case "Percentage on Total Value":
                                    tier1RewardAmountForNew = portfolioValue * (tier1RewardCalcValOrPercentage) / 100;
                                    break;
                                case "Percentage on Disbursed Value":
                                    tier1RewardAmountForNew = portfolioValue * (tier1RewardCalcValOrPercentage / 100);
                                    break;
                                case "Percentage on Average 6 Months Balance":
                                    tier1RewardAmountForNew = portfolioValue * (tier1RewardCalcValOrPercentage / 100);
                                    break;
                            }

                            totalRewardAmountForNew = tier1RewardAmountForNew;

                        } else if (rewardLevel == 2) {

                            switch (tier1RewardCalcMethod) {
                                case "Value":
                                    tier1RewardAmountForNew = tier1RewardCalcValOrPercentage;
                                    break;
                                case "Percentage on Total Value":
                                    tier1RewardAmountForNew = portfolioValue * (tier1RewardCalcValOrPercentage / 100);
                                    break;
                                case "Percentage on Disbursed Value":
                                    tier1RewardAmountForNew = portfolioValue * (tier1RewardCalcValOrPercentage / 100);
                                    break;
                                case "Percentage on Average 6 Months Balance":
                                    tier1RewardAmountForNew = portfolioValue * (tier1RewardCalcValOrPercentage / 100);
                                    break;
                            }

                            switch (tier2RewardCalcMethod) {
                                case "Value":
                                    tier2RewardAmountForNew = tier2RewardCalcValOrPercentage;
                                    break;
                                case "Percentage on Total Value":
                                    tier2RewardAmountForNew = portfolioValue * (tier2RewardCalcValOrPercentage / 100);
                                    break;
                                case "Percentage on Disbursed Value":
                                    tier2RewardAmountForNew = portfolioValue * (tier2RewardCalcValOrPercentage / 100);
                                    break;
                                case "Percentage on Average 6 Months Balance":
                                    tier2RewardAmountForNew = portfolioValue * (tier2RewardCalcValOrPercentage / 100);
                                    break;
                            }

                            totalRewardAmountForNew = tier1RewardAmountForNew + tier2RewardAmountForNew;
                        }
                    }

                } else {
                    double initialYearRewardedAmount = getInitialYearRewardedAmount(contractNo, "Total");
                    double initialYearTier2RewardedAmount = getInitialYearRewardedAmount(contractNo, "Tier2");
                    if (productStatus.equals("Top-Up-1-Less")) {
                        switch (reward1YearLessMethod) {
                            case "Percentage over the rewarded amount at Tier II level":
                                rewardAmountRenewal1YearLess = initialYearTier2RewardedAmount * (reward1YearLessPercentage / 100);
                                break;
                            case "Percentage over the rewarded amount":
                                rewardAmountRenewal1YearLess = initialYearRewardedAmount * (reward1YearLessPercentage / 100);
                                break;
                        }
                    } else if (productStatus.equals("Top-Up-1-2")) {
                        switch (reward1to2YearMethod) {
                            case "Percentage over the rewarded amount at Tier II level":
                                rewardAmountRenewal1To2Year = initialYearTier2RewardedAmount * (reward1to2YearPercentage / 100);
                                break;
                            case "Percentage over the rewarded amount":
                                rewardAmountRenewal1To2Year = initialYearRewardedAmount * (reward1to2YearPercentage / 100);
                                break;
                        }
                    }

                    //either rewardAmountRenewal1YearLess==0 or rewardAmountRenewal1To2Year==0
                    totalRewardAmountForRenewal = rewardAmountRenewal1YearLess + rewardAmountRenewal1To2Year;

                }
                //either totalRewardAmountForNew==0 or totalRewardAmountForRenewal==0
                totalRewardAmount = totalRewardAmountForNew + totalRewardAmountForRenewal;
                
//                if(totalRewardAmount>rewardCapValue){
//                    totalRewardAmount=rewardCapValue;
//                }

                Object[] rewardAmountDetails = {
                    tier1RewardAmountForNew,
                    tier2RewardAmountForNew,
                    totalRewardAmountForNew,
                    rewardAmountRenewal1YearLess,
                    rewardAmountRenewal1To2Year,
                    totalRewardAmountForRenewal,
                    totalRewardAmount,
                    perfomedUser,
                    contractNo,
                    yearMonthFrom,
                    portfolioValue

                };

                storeRewardDetails(rewardAmountDetails);
            }
        }
    }

    private boolean checkForRewardAlreadyCalculated(String contractNo, String yearMonthFrom) {
        boolean isNotCalculated = true;

        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {

            String sql = "select count(*) as NoOfRecords from gcsm_reward_details where reward_contract_no=? and reward_yearmonth_from=?";

            preparedStatement = currentConnection.prepareStatement(sql);
            preparedStatement.setString(1, contractNo);
            preparedStatement.setString(2, yearMonthFrom);

            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                if (resultSet.getInt("NoOfRecords") > 0) {
                    isNotCalculated = false;
                }
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        }
        return isNotCalculated;
    }

    private boolean storeRewardDetails(Object[] rewardAmountDetails) {
        boolean isStored = false;

        double tier1RewardAmountForNew = (double) rewardAmountDetails[0];
        double tier2RewardAmountForNew = (double) rewardAmountDetails[1];
        double totalRewardAmountForNew = (double) rewardAmountDetails[2];
        double rewardAmountRenewal1YearLess = (double) rewardAmountDetails[3];
        double rewardAmountRenewal1To2Year = (double) rewardAmountDetails[4];
        double totalRewardAmountForRenewal = (double) rewardAmountDetails[5];
        double totalRewardAmount = (double) rewardAmountDetails[6];
        String perfomedUser = (String) rewardAmountDetails[7];
        String contractNo = (String) rewardAmountDetails[8];
        String yearMonthFrom = (String) rewardAmountDetails[9];
        double portfolioValue = (double) rewardAmountDetails[10];

        if (checkForRewardAlreadyCalculated(contractNo, yearMonthFrom)) {
            databaseConnection = DatabaseConnection.getInstance();
            currentConnection = databaseConnection.get_JDBC_Connection();
            preparedStatement = null;
            resultSet = null;

            //Audit Trail        
            Auditing auditing = new Auditing();
            String auditType = "INSERT";
            String related_table = "gcsm_reward_details";
            String record_pk = "";
            String old_value = "##Empty##";

            try {

                if (!databaseConnection.start_Connection(currentConnection)) {

                } else {
                    String sql
                            = "INSERT INTO gcsm_reward_details("
                            + "reward_contract_no,"//1
                            + "portfolio_value," //2
                            + "tier1_reward_amount_for_new," //3
                            + "tier2_reward_amount_for_new," //4
                            + "total_reward_amount_for_new," //5
                            + "reward_amount_renewal1_year_less," //6
                            + "reward_amount_renewal1_to_2_year," //7
                            + "total_reward_amount_for_renewal," //8
                            + "total_reward_amount," //9
                            + "reward_related_user," //10                        
                            + "reward_yearmonth_from," //11
                            + "reward_setup_timestamp,"
                            + "reward_approval_status)"
                            + " VALUES(?,?,?,?,?,?,?,?,?,?,?,now(),0)";

                    preparedStatement = currentConnection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                    preparedStatement.setString(1, contractNo);
                    preparedStatement.setDouble(2, portfolioValue);
                    preparedStatement.setDouble(3, tier1RewardAmountForNew);
                    preparedStatement.setDouble(4, tier2RewardAmountForNew);
                    preparedStatement.setDouble(5, totalRewardAmountForNew);
                    preparedStatement.setDouble(6, rewardAmountRenewal1YearLess);
                    preparedStatement.setDouble(7, rewardAmountRenewal1To2Year);
                    preparedStatement.setDouble(8, totalRewardAmountForRenewal);
                    preparedStatement.setDouble(9, totalRewardAmount);
                    preparedStatement.setString(10, perfomedUser);
                    preparedStatement.setString(11, yearMonthFrom);
                    int executeUpdate = preparedStatement.executeUpdate();
                    resultSet = preparedStatement.getGeneratedKeys();
                }

                while (resultSet.next()) {
                    //Audit Trail
                    record_pk = "" + (resultSet.getInt(1));
                }

                if (!databaseConnection.end_Connection(currentConnection)) {

                    log.error("Uh oh! An error occurred, database connection terminating problem.");

                }

                //Audit Trail
                String new_value = auditing.getAllRecords(record_pk, related_table).toString();
                auditing.saveAuditRecord(perfomedUser, related_table, auditType, record_pk, old_value, new_value);

            } catch (Exception e) {
                log.error(e.getMessage());

            }
        }
        return isStored;
    }

    @Override
    public void updateRewardCalculationStatus(JSONObject jasonobj, int status) {

        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        preparedStatement = null;
        resultSet = null;

        //Audit Trail
        Auditing auditing = new Auditing();
        String auditType = "";
        String related_table = "gcsm_reward_calculation_status";
        String record_pk = "";
        String old_value = "##Empty##";

        try {
            int latestStatusID = getLatestRewardCalculationStatusID();
            if (!databaseConnection.start_Connection(currentConnection)) {

            } else {

                String sql = "";
                if (status == 0) {
                    sql = "INSERT INTO gcsm_reward_calculation_status("
                            + "status," //1
                            + "initiated_user," //2
                            + "initiated_timestamp,"
                            + "period_from_yearmonth)" //3
                            + " VALUES(?,?,now(),?)";
                    //Audit Trail
                    auditType = "INSERT";

                } else if (status == 1) {
                    sql = "update gcsm_reward_calculation_status "
                            + "set status=?, calculated_user=?,calculated_timestamp=now() where status_id=" + latestStatusID + "";

                    //Audit Trail
                    auditType = "UPDATE";

                } else if (status == 2) {
                    sql = "update gcsm_reward_calculation_status "
                            + "set status=?, closed_user=?,closed_timestamp=now() where status_id=" + latestStatusID + "";

                    //Audit Trail
                    auditType = "UPDATE";

                } else if (status-- == 10) {
                    sql = "update gcsm_reward_calculation_status "
                            + "set status=? where status_id=" + latestStatusID + "";

                    //Audit Trail
                    auditType = "UPDATE";

                }

                preparedStatement = currentConnection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                preparedStatement.setInt(1, status + 1);

                if (status != 9) {
                    preparedStatement.setString(2, jasonobj.getString("user_username"));
                }
                if (status == 0) {
                    preparedStatement.setString(3, jasonobj.getString("period_from_yearmonth"));
                }

                int executeUpdate = preparedStatement.executeUpdate();
                resultSet = preparedStatement.getGeneratedKeys();
            }

            if (resultSet.first()) {
                record_pk = "" + resultSet.getInt(1);
            } else {
                record_pk = "" + latestStatusID;
            }
            if (status != 0) {
                old_value = auditing.getAllRecords(record_pk, related_table).toString();
            }

            if (!databaseConnection.end_Connection(currentConnection)) {
                log.error("Uh oh! An error occurred, database connection terminating problem.");
            }

            //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            auditing.saveAuditRecord(jasonobj.get("user_username").toString(), related_table, auditType, record_pk, old_value, new_value);

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
            }
        }

    }

    @Override
    public ResponceHandler verifyRewardDetails(JSONObject jasonobj, int approveReject) {
        responceHandler = new ResponceHandler();
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        jsonObejcts = new JSONObjects();

        //Audit Trail
        Auditing auditing = new Auditing();
        String auditType = "UPDATE";
        String related_table = "gcsm_reward_details";
        String record_pk = "";
        String old_value = "";

        try {
            if (!databaseConnection.start_Connection(currentConnection)) {

            } else {
                String pointValuesVerifyQuery
                        = "UPDATE gcsm_reward_details "
                        + "set reward_approval_status=" + approveReject + ", "
                        + "reward_approved_user=?,"//1
                        + "reward_approval_comment=?, " //2
                        + "reward_approved_timestamp=now() "
                        + "where reward_detail_id=?";              //3

                preparedStatement = currentConnection.prepareStatement(pointValuesVerifyQuery);
                preparedStatement.setString(1, jasonobj.get("user_username").toString());
                preparedStatement.setString(2, jasonobj.get("reward_approval_comment").toString());
                preparedStatement.setInt(3, Integer.parseInt(jasonobj.getString("reward_detail_id").trim()));

                //Audit Trail 
                record_pk = "" + Integer.parseInt(jasonobj.getString("reward_detail_id").trim());
                old_value = auditing.getAllRecords(record_pk, related_table).toString();

                if (preparedStatement.executeUpdate() <= 0) {

                    responceHandler.setResponceModule("verify_Reward_Details");
                    responceHandler.setResponceType("error");
                    responceHandler.setResponceCode("0001");
                    responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");

                }

                responceHandler.setResponceModule("verify_Reward_Details");
                responceHandler.setResponceType("success");
                responceHandler.setResponceCode("0000");
                responceHandler.setResponceDescription((approveReject == 1) ? "Succefully Approved" : "Successfully Rejected");
            }
            if (!databaseConnection.end_Connection(currentConnection)) {

                responceHandler.setResponceModule("verify_Reward_Details");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("Uh oh! An error occurred, database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }

            //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            auditing.saveAuditRecord(jasonobj.get("user_username").toString(), related_table, auditType, record_pk, old_value, new_value);

            if (isAllRewardsApproved()) {
                updateRewardCalculationStatus(jasonobj, 2);
            }

        } catch (SQLException ex) {
            log.error(ex.getMessage());

        } catch (Exception ex) {
            log.error(ex.getMessage());
        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("verify_Reward_Details");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");
            }

        }

        return responceHandler;
    }

    private boolean isAllRewardsApproved() {
        boolean flag = false;

        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {
            if (!databaseConnection.start_Connection(currentConnection)) {

            } else {
                String sql = "select count(*) as pendingApprovalCount from gcsm_reward_details where reward_approval_status=0";

                preparedStatement = currentConnection.prepareStatement(sql);

                resultSet = preparedStatement.executeQuery();

                while (resultSet.next()) {
                    flag = resultSet.getInt("pendingApprovalCount") == 0;
                }
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        }
        return flag;
    }

    @Override
    public JSONArray checkForAlreadyCalculations(JSONObject jasonobj) {
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();
        try {
            String queryToGetRewardDetailsAlreadyExist = "select count(*) as NoOfRecords from gcsm_reward_calculation_status where period_from_yearmonth=?";

            preparedStatement = currentConnection.prepareStatement(queryToGetRewardDetailsAlreadyExist);
            preparedStatement.setString(1, jasonobj.getString("yearMonthFrom"));
            resultSet = preparedStatement.executeQuery();

            int i = 0;
            while (resultSet.next()) {
                m_jsObj = new JSONObject();
                m_jsObj.put("NoOfRecords", resultSet.getInt("NoOfRecords"));
                jsArr.put(i, m_jsObj);
                i++;
            }
        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("View_RewardValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");
            }
        }

        return jsArr;
    }

    private int getLatestRewardCalculationStatusID() {
        int statusID = 0;
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {

            String sql = "select status_id from gcsm_reward_calculation_status ORDER BY status_id DESC LIMIT 1";

            preparedStatement = currentConnection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                statusID = resultSet.getInt("status_id");
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        }
        return statusID;
    }

//    private double getTPRateforContract(String contractNo, String yearMonth) {        
//        SQLServerDatabaseConnection sqlserver_databaseConnection = SQLServerDatabaseConnection.getInstance();;
//        Connection sqlserver_currentConnection = sqlserver_databaseConnection.get_JDBC_Connection();
//        PreparedStatement preparedStatement = null;
//        ResultSet resultSet = null;
//        double TPRate = 0;
//        try {
//            if (!sqlserver_databaseConnection.start_Connection(sqlserver_currentConnection)) {
//
//            } else {
//                String sql = "select TP_RATE from PROFITABILITY_MAS where CON_REF_NO=? and UP_DT_KY=?";
//                preparedStatement = sqlserver_currentConnection.prepareStatement(sql);
//                preparedStatement.setString(1, contractNo);
//                preparedStatement.setString(2, yearMonth);
//
//                resultSet = preparedStatement.executeQuery();
//                while (resultSet.next()) {
//                    TPRate = resultSet.getDouble("TP_RATE");
//                }
//            }
//            sqlserver_databaseConnection.end_Connection(sqlserver_currentConnection);
//
//        } catch (Exception e) {
//            log.error(e.getMessage());
//
//        } finally {
//            try {
//                if (resultSet != null) {
//                    resultSet.close();
//                }
//                if (preparedStatement != null) {
//                    preparedStatement.close();
//                }
//                if (sqlserver_currentConnection != null) {
//                    sqlserver_currentConnection.close();
//                }
//            } catch (Exception e) {
//                log.error(e.getMessage());
//
//            }
//
//        }
//        return TPRate;
//    }
//    
//    private Object[] getALCOApprovedTPRates(String contractNo){  
//        Object[] typeRate=new Object[2];
//        
//        databaseConnection = DatabaseConnection.getInstance();
//        currentConnection = databaseConnection.get_JDBC_Connection();
//        try {
//
//            String sql = "select product_type,product_alco_approved_tp_rate from gcsm_product where product_id in (select cs_product from gcsm_cross_selling_details where cs_contract_no=?)";
//
//            preparedStatement = currentConnection.prepareStatement(sql);
//            preparedStatement.setString(1, contractNo);
//            resultSet = preparedStatement.executeQuery();
//
//            while (resultSet.next()) {
//               typeRate[0]=resultSet.getString("product_type");
//               typeRate[1]=resultSet.getDouble("product_alco_approved_tp_rate");                
//            }        
//            
//        } catch (Exception e) {
//            log.error(e.getMessage());
//
//        }   
//        return typeRate;
//    }
//    
//    private List<String> getRewardEligibleContractList(List<String> contractNos,String yearMonth){
//        yearMonth=yearMonth.replace("-", "");
//        List<String> rewardEligibleContractList=new ArrayList<>();
//        
//        for(String contractNo:contractNos){
//            Object[] typeRate=getALCOApprovedTPRates(contractNo);
//            
//            String productType=(String) typeRate[0];
//            double ALCOApprovedTPRate=(Double) typeRate[1];
//            
//            double TPRate=getTPRateforContract(contractNo, yearMonth);
//            
//            if(productType.equals("Asset")){
//                if(ALCOApprovedTPRate<=TPRate){
//                    rewardEligibleContractList.add(contractNo);
//                }
//            }
//            
//            else if(productType.equals("Liability")){
//                if(ALCOApprovedTPRate>=TPRate){
//                    rewardEligibleContractList.add(contractNo);
//                }
//            }
//        }      
//        return rewardEligibleContractList;
//    }     
    @Override
    public boolean checkForProductRewardValuesConfiguration() {
        boolean isAllRewardValuesConfigured = false;

        int allProducts = getAllProductsCount();

        int getConfiguredProductsCount = getRewardValuesConfiguredProductsCount();

        isAllRewardValuesConfigured = (allProducts == getConfiguredProductsCount);

        return isAllRewardValuesConfigured;
    }

    private int getAllProductsCount() {
        int count = 0;

        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {

            String sql = "select count(product_id) as allProducts from gcsm_product;";

            preparedStatement = currentConnection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                count = resultSet.getInt("allProducts");
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        }

        return count;
    }

    private int getRewardValuesConfiguredProductsCount() {
        int count = 0;

        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {

            String sql = "select count(reward_product_id) as rewardConfiguredCount from gcsm_reward_values where reward_value_status=2;";

            preparedStatement = currentConnection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                count = resultSet.getInt("rewardConfiguredCount");
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        }

        return count;
    }

    //---------------------------------------------------------------------------
    private double getPortfolioValue(String contractNo, String yearMonthFrom, String type) {
        yearMonthFrom = yearMonthFrom.replace("-", "");
        SQLServerDatabaseConnection sqlserver_databaseConnection = SQLServerDatabaseConnection.getInstance();;
        Connection sqlserver_currentConnection = sqlserver_databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        double portfolioValue = 0;
        try {
            if (!sqlserver_databaseConnection.start_Connection(sqlserver_currentConnection)) {

            } else {
                String sql = "";
                if (type.equals("AVG_6_MONTHS")) {
                    sql = "select (sum(PORT_AMT)/6) AS PORT_AMT from SEG_PROFITABILITY_MAS where CON_REF_NO=? and UP_DT_KY=?";
                } else if (type.equals("TOTAL")) {
                    sql = "select TOP 1 PORT_AMT from SEG_PROFITABILITY_MAS where CON_REF_NO=? and UP_DT_KY=? and PORT_AMT!=0 order by UP_DT_KY ";
                }
                preparedStatement = sqlserver_currentConnection.prepareStatement(sql);

                preparedStatement.setString(1, contractNo);
                preparedStatement.setString(2, yearMonthFrom);

                resultSet = preparedStatement.executeQuery();
                while (resultSet.next()) {
                    portfolioValue = resultSet.getDouble("PORT_AMT");
                }
            }
            sqlserver_databaseConnection.end_Connection(sqlserver_currentConnection);

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (sqlserver_currentConnection != null) {
                    sqlserver_currentConnection.close();
                }
            } catch (Exception e) {
                log.error(e.getMessage());

            }
        }
        return portfolioValue;
    }

    private String getCSYearMonth(String contractNo) {
        String yearMonth = "";

        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {

            String sql = "select concat(year(cs_date),month(cs_date)) as yearMonth from gcsm_cross_selling_details where cs_contract_no='" + contractNo + "'";

            preparedStatement = currentConnection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                yearMonth = resultSet.getString("yearMonth");
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        }

        return yearMonth;
    }

    private int monthDiffBetweenCSYearMonthAndRewardYearMonth(String csYearMonth, String rewardYearMonth) {
        int diff = 0;

        int csYear = Integer.parseInt(csYearMonth.substring(0, 4));
        int csMonth = Integer.parseInt(csYearMonth.substring(4, csYearMonth.length()));

        int rewardYear = Integer.parseInt(rewardYearMonth.substring(0, 4));
        int rewardMonth = Integer.parseInt(rewardYearMonth.substring(4, rewardYearMonth.length()));

        Calendar calCS = Calendar.getInstance();
        calCS.set(csYear, csMonth - 1, 1);

        Calendar calRewards = Calendar.getInstance();
        calRewards.set(rewardYear, rewardMonth - 1, 1);

        diff = (calRewards.get(Calendar.YEAR) * 12 + calRewards.get(Calendar.MONTH)) - (calCS.get(Calendar.YEAR) * 12 + calCS.get(Calendar.MONTH)) + 1;
        return diff;
    }

    private String getTierIOrTierIITypeForAVG6MonthsBalance(String contractNo, String rewardYearMonth) {
        String type = "";

        String csYearMonth = getCSYearMonth(contractNo);

        int monthDiff = monthDiffBetweenCSYearMonthAndRewardYearMonth(csYearMonth, rewardYearMonth);

        boolean is6Months = monthDiff % 6 == 0;

        if (monthDiff == 1) {
            type = "Tier1";
        } else if (is6Months) {
            type = "Tier2";
        } else {
            type = "None";
        }

        return type;

    }

    private double[] getRewardAmountsForTwoTierProductsWithValueAndAVG6Months(double tier1RewardCalcValOrPercentage, double tier2RewardCalcValOrPercentage, String contractNo, String yearMonthFrom) {
        yearMonthFrom = yearMonthFrom.replace("-", "");
        double[] rewardAmounts = new double[3]; // port val, reward amount tier I, reward amount tier II
        String rewardType = getTierIOrTierIITypeForAVG6MonthsBalance(contractNo, yearMonthFrom);

        double portfolioValue = getPortfolioValueFromShadowRevenue(contractNo, yearMonthFrom);
        double tierIRewardAmount = 0;
        double tierIIRewardAmount = 0;

        if (rewardType.equalsIgnoreCase("Tier1")) {
            tierIRewardAmount = tier1RewardCalcValOrPercentage;
            tierIIRewardAmount = 0;
        } else if (rewardType.equalsIgnoreCase("Tier2")) {
            tierIRewardAmount = 0;

            String rewardingYear = yearMonthFrom.substring(0, 4);
            String rewardingMonth = yearMonthFrom.substring(4, yearMonthFrom.length());

            Calendar cal = Calendar.getInstance();
            cal.set(Integer.parseInt(rewardingYear), Integer.parseInt(rewardingMonth), 1);

            String[] last6Months = new String[6];

            for (int i = 0; i < last6Months.length; i++) {
                last6Months[i] = "" + cal.get(Calendar.YEAR) + (cal.get(Calendar.MONTH) < 10 ? "" + "0" + cal.get(Calendar.MONTH) : cal.get(Calendar.MONTH));
                last6Months[i] = last6Months[i].substring(4, 6).equals("00") ? (Integer.parseInt(last6Months[i].substring(0, 4)) - 1) + "12" : last6Months[i];
                cal.add(Calendar.MONTH, -1);
                System.out.println(last6Months[i]);
            }

            double month6TotalBalance = 0;
            for (int i = 0; i < 6; i++) {
                double thisMonthBalance = (getPortfolioValueFromShadowRevenue(contractNo, last6Months[i]));
                month6TotalBalance += thisMonthBalance;

            }
            tierIIRewardAmount = ((month6TotalBalance / 6) * tier2RewardCalcValOrPercentage) / 100;

        } else if (rewardType.equals("None")) {
            tierIRewardAmount = 0;
            tierIIRewardAmount = 0;
        }

        rewardAmounts[0] = Math.round(portfolioValue * 100.0) / 100.0;
        rewardAmounts[1] = Math.round(tierIRewardAmount * 100.0) / 100.0;
        rewardAmounts[2] = Math.round(tierIIRewardAmount * 100.0) / 100.0;

        return rewardAmounts;
    }

    private double getPortfolioValueFromShadowRevenue(String contractNo, String yearMonth) {
        double portfolioValue = 0;

        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {

            String sql = "select shadow_portfolio_value from gcsm_shadow_revenue where shadow_cs_contract_no='" + contractNo + "' and shadow_year_month='" + yearMonth + "'";

            preparedStatement = currentConnection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                portfolioValue = resultSet.getDouble("shadow_portfolio_value");
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        }

        return portfolioValue;
    }

    public static void main(String[] args) {
        System.out.println(new CalculateRewardsDAOImpl().checkRewardsEligibility("106001599006"));
    }
}
