/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.RewardsHandling.DAO.Impl;

import gcsm.RewardsHandling.DAO.IndividualTargetAchievementDAO;
import gcsm.RewardsHandling.Model.IndividualTargetAchievementModel;
import gcsm.Utitlities.Impl.Auditing;
import gcsm.Utitlities.Impl.DatabaseConnection;
import gcsm.Utitlities.Impl.JSONObjects;
import gcsm.Utitlities.Model.ResponceHandler;
import gcsm.Utitlities.Model.RoleTypes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Janaka_5977
 */
public class IndividualTargetAchievementDAOImpl implements IndividualTargetAchievementDAO {

    static Logger log = LogManager.getLogger(IndividualTargetAchievementDAOImpl.class.getName());
    private ResponceHandler responceHandler;
    static DatabaseConnection databaseConnection;
    static Connection currentConnection = null;
    private PreparedStatement preparedStatement = null;
    private ResultSet resultSet = null;
    private JSONObjects jsonObejcts;
    private JSONArray jsArr;

    @Override
    public JSONArray viewAchievementValues(JSONObject jasonobj) {
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        String roleType = jasonobj.get("session_role_type").toString();
        String username = jasonobj.get("user_username").toString();
        jsArr = new JSONArray();
        try {
            String queryViewIndividualTargertQuery = "";
            if (roleType.equals(RoleTypes.INPUTER)) {
                queryViewIndividualTargertQuery = "select achievement_id, core_target_asset, core_target_liabilities,core_target_achievement_asset,core_target_achievement_liabilities, cs_asset_achievement, cs_liabilities_achievement, period_from_yearmonth,  target_achivement_status, related_to,user_designation, setup_user, setup_time, ifnull(approved_rejected_user,'--') as approved_rejected_user, ifnull(approved_rejected_time,'--') as approved_rejected_time, ifnull(approval_reject_comment,'--') as approval_reject_comment from gcsm_individual_target_achievements where setup_user='" + username + "' order by setup_time desc";
            } else if (roleType.equals(RoleTypes.AUTHORIZER)) {
                queryViewIndividualTargertQuery = "select achievement_id, core_target_asset, core_target_liabilities,core_target_achievement_asset,core_target_achievement_liabilities, cs_asset_achievement, cs_liabilities_achievement, period_from_yearmonth,  target_achivement_status, related_to,user_designation, setup_user, setup_time, ifnull(approved_rejected_user,'--') as approved_rejected_user, ifnull(approved_rejected_time,'--') as approved_rejected_time, ifnull(approval_reject_comment,'--') as approval_reject_comment from gcsm_individual_target_achievements where setup_user in (select user_username from gcsm_user where user_businessline in (select user_businessline from gcsm_user where user_username='" + username + "')) order by setup_time desc";
            } else if (roleType.equals(RoleTypes.FINANCE_ADMINISTRATOR)) {
                queryViewIndividualTargertQuery = "select achievement_id, core_target_asset, core_target_liabilities,core_target_achievement_asset,core_target_achievement_liabilities, cs_asset_achievement, cs_liabilities_achievement, period_from_yearmonth,  target_achivement_status, related_to,user_designation, setup_user, setup_time, ifnull(approved_rejected_user,'--') as approved_rejected_user, ifnull(approved_rejected_time,'--') as approved_rejected_time, ifnull(approval_reject_comment,'--') as approval_reject_comment from gcsm_individual_target_achievements order by setup_time desc";
            } 
            

            preparedStatement = currentConnection.prepareStatement(queryViewIndividualTargertQuery);
            resultSet = preparedStatement.executeQuery();
            int i = 0;
            while (resultSet.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("achievement_id", resultSet.getInt("achievement_id"));
                m_jsObj.put("core_target_asset", resultSet.getString("core_target_asset"));
                m_jsObj.put("core_target_liabilities", resultSet.getString("core_target_liabilities"));
                m_jsObj.put("core_target_achievement_asset", resultSet.getString("core_target_achievement_asset"));
                m_jsObj.put("core_target_achievement_liabilities", resultSet.getString("core_target_achievement_liabilities"));
                m_jsObj.put("cs_asset_achievement", resultSet.getString("cs_asset_achievement"));
                m_jsObj.put("cs_liabilities_achievement", resultSet.getString("cs_liabilities_achievement"));
                
                double cross_target_achievement_assets=Double.parseDouble(resultSet.getString("cs_asset_achievement"));
                double cross_target_achievement_liabilities=Double.parseDouble(resultSet.getString("cs_liabilities_achievement"));
                
                double core_target_asset=resultSet.getDouble("core_target_asset");
                double core_target_liabilities=resultSet.getDouble("core_target_liabilities");
                String assets_percentage_achievement=""+(core_target_asset==0?0:(cross_target_achievement_assets/core_target_asset)*100);
                String liabilites_percentage_achievement=""+(core_target_liabilities==0?0:(cross_target_achievement_liabilities/core_target_liabilities)*100);
                
                m_jsObj.put("assets_percentage_achievement", assets_percentage_achievement);
                m_jsObj.put("liabilites_percentage_achievement", liabilites_percentage_achievement);
                m_jsObj.put("period_from_yearmonth", resultSet.getString("period_from_yearmonth"));
                m_jsObj.put("target_achivement_status", resultSet.getString("target_achivement_status"));
                m_jsObj.put("related_to", resultSet.getString("related_to"));
                m_jsObj.put("user_designation", resultSet.getString("user_designation"));
                m_jsObj.put("setup_user", resultSet.getString("setup_user"));
                m_jsObj.put("setup_time", resultSet.getString("setup_time"));
                m_jsObj.put("approved_rejected_user", resultSet.getString("approved_rejected_user"));
                m_jsObj.put("approved_rejected_time", resultSet.getString("approved_rejected_time"));
                m_jsObj.put("approval_reject_comment", resultSet.getString("approval_reject_comment"));
                jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("View_RewardValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return jsArr;
    }

    @Override
    public ResponceHandler insertAchievementValues(JSONObject jasonobj) {
        responceHandler = new ResponceHandler();
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        jsonObejcts = new JSONObjects();
        IndividualTargetAchievementModel individualTargetAchievementModel;
        double csShadowTotalForAssets = 0;
        double csShadowTotalForLiabilities = 0;

        //Audit Trail        
        Auditing auditing = new Auditing();
        String auditType = "INSERT";
        String related_table = "gcsm_individual_target_achievements";
        String record_pk = "";
        String old_value = "##Empty##";

        try {
            individualTargetAchievementModel = jsonObejcts.convertIndividualTargetAchievementModelToJSON(jasonobj.toString());
            String relatedTo=individualTargetAchievementModel.getRelated_to();
            String perfomedByNICUnit="";
            String relatedToCalculationValue="";
            if(relatedTo.contains("-")){
                perfomedByNICUnit="NIC";
                relatedToCalculationValue=relatedTo.split(" - ")[0];
            }
            else{
                perfomedByNICUnit="Unit";
                relatedToCalculationValue=relatedTo;
            }
            csShadowTotalForAssets = calculateCSAchievementValues("Asset", individualTargetAchievementModel.getPeriod_from_yearmonth(), perfomedByNICUnit,relatedToCalculationValue);
            csShadowTotalForLiabilities = calculateCSAchievementValues("Liability", individualTargetAchievementModel.getPeriod_from_yearmonth(), perfomedByNICUnit,relatedToCalculationValue);
            individualTargetAchievementModel.setCs_asset_achievement(csShadowTotalForAssets);
            individualTargetAchievementModel.setCs_liabilities_achievement(csShadowTotalForLiabilities);

            String insertIndividualTargetQuery
                    = "INSERT INTO gcsm_individual_target_achievements ("
                    + "core_target_asset, " //1
                    + "core_target_liabilities, " //2
                    + "core_target_achievement_asset, " //3
                    + "core_target_achievement_liabilities, " //4
                    + "cs_asset_achievement, " //5
                    + "cs_liabilities_achievement, " //6
                    + "period_from_yearmonth, " //7
                    + "target_achivement_status, " //8
                    + "related_to, " //9
                     + "user_designation, " //10
                    + "setup_user, " //11
                    + "setup_time) "
                    + "values (?,?,?,?,?,?,?,?,?,?,?,now())";

            preparedStatement = currentConnection.prepareStatement(insertIndividualTargetQuery, Statement.RETURN_GENERATED_KEYS);
            preparedStatement.setDouble(1, individualTargetAchievementModel.getCore_target_asset());
            preparedStatement.setDouble(2, individualTargetAchievementModel.getCore_target_liabilities());
            preparedStatement.setDouble(3, individualTargetAchievementModel.getCore_target_achievement_asset());
            preparedStatement.setDouble(4, individualTargetAchievementModel.getCore_target_achievement_liabilities());
            preparedStatement.setDouble(5, individualTargetAchievementModel.getCs_asset_achievement());
            preparedStatement.setDouble(6, individualTargetAchievementModel.getCs_liabilities_achievement());
            preparedStatement.setString(7, individualTargetAchievementModel.getPeriod_from_yearmonth());
            preparedStatement.setInt(8, 0);
            preparedStatement.setString(9, individualTargetAchievementModel.getRelated_to());
            preparedStatement.setString(10, individualTargetAchievementModel.getUser_designation());
            preparedStatement.setString(11, jasonobj.get("user_username").toString());

            if (preparedStatement.executeUpdate() <= 0) {

                responceHandler.setResponceModule("insertPointValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");

            }

            responceHandler.setResponceModule("insertPointValues");
            responceHandler.setResponceType("success");
            responceHandler.setResponceCode("0000");
            responceHandler.setResponceDescription("Awesome! You were successful.");

            //Audit Trail
            resultSet = preparedStatement.getGeneratedKeys();
            resultSet.next();
            record_pk = "" + (resultSet.getInt(1));

            if (!databaseConnection.end_Connection(currentConnection)) {

                responceHandler.setResponceModule("insertPointValues");
                responceHandler.setResponceType("error");;
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("Uh oh! An error occurred, database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }

            //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            auditing.saveAuditRecord(jasonobj.get("user_username").toString(), related_table, auditType, record_pk, old_value, new_value);

        } catch (SQLException ex) {
            log.error(ex.getMessage());

        } catch (Exception ex) {
            log.error(ex.getMessage());
        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("insertPointValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert Point Value");

            }

        }

        return responceHandler;

    }

    @Override
    public ResponceHandler verifyAchievementValues(JSONObject jasonobj, int approveReject) {
        responceHandler = new ResponceHandler();
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        jsonObejcts = new JSONObjects();
        IndividualTargetAchievementModel individualTargetAchievementModel;

        //Audit Trail
        Auditing auditing = new Auditing();
        String auditType = "UPDATE";
        String related_table = "gcsm_individual_target_achievements";
        String record_pk = "";
        String old_value = "";

        try {
            individualTargetAchievementModel = jsonObejcts.convertIndividualTargetAchievementModelToJSON(jasonobj.toString());
            String pointValuesVerifyQuery
                    = "UPDATE gcsm_individual_target_achievements "
                    + "set target_achivement_status=" + approveReject + ", "
                    + "approval_reject_comment=?, " //1
                    + "approved_rejected_user=?, " //2
                    + "approved_rejected_time=now() "
                    + "where achievement_id=?";              //3

            preparedStatement = currentConnection.prepareStatement(pointValuesVerifyQuery);
            preparedStatement.setString(1, individualTargetAchievementModel.getApproval_reject_comment());
            preparedStatement.setString(2, jasonobj.get("user_username").toString());
            preparedStatement.setInt(3, individualTargetAchievementModel.getAchievement_id());

            //Audit Trail 
            record_pk = "" + individualTargetAchievementModel.getAchievement_id();
            old_value = auditing.getAllRecords(record_pk, related_table).toString();

            if (preparedStatement.executeUpdate() <= 0) {

                responceHandler.setResponceModule("verify_Point_Values_Details");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");

            }

            responceHandler.setResponceModule("verify_Point_Values_Details");
            responceHandler.setResponceType("success");
            responceHandler.setResponceCode("0000");
            responceHandler.setResponceDescription((approveReject == 1) ? "Succefully Approved" : "Successfully Rejected");

            if (!databaseConnection.end_Connection(currentConnection)) {

                responceHandler.setResponceModule("verify_Point_Values_Details");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("Uh oh! An error occurred, database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }

            //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            auditing.saveAuditRecord(jasonobj.get("user_username").toString(), related_table, auditType, record_pk, old_value, new_value);

        } catch (SQLException ex) {
            log.error(ex.getMessage());

        } catch (Exception ex) {
            log.error(ex.getMessage());
        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("verify_Point_Values_Details");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return responceHandler;
    }

    private double calculateCSAchievementValues(String product_type, String periodFrom,String perfromedByNICUnit,String relatedTo) {
        double crossSellingAchievementValue = 0;

        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        preparedStatement = null;
        resultSet = null;
        try {
            String sql ="";
            if(perfromedByNICUnit.equals("NIC")){
                sql="select sum(shadow_portfolio_value) as Total_Shadow_Portfolio from gcsm_shadow_revenue,gcsm_cross_selling_details,gcsm_product where shadow_cs_contract_no = cs_contract_no and cs_product=product_id and product_type=? and shadow_year_month=? and cs_emp_id=?";
            }
            else{
                sql="select sum(shadow_portfolio_value) as Total_Shadow_Portfolio from gcsm_shadow_revenue,gcsm_cross_selling_details,gcsm_product where shadow_cs_contract_no = cs_contract_no and cs_product=product_id and product_type=? and shadow_year_month=? and cs_units_sold_by=?";
            }

            

            preparedStatement = currentConnection.prepareStatement(sql);
            preparedStatement.setString(1, product_type);
            preparedStatement.setString(2, periodFrom.replace("-", ""));
           // preparedStatement.setString(3, periodTo.replace("-", ""));
            preparedStatement.setString(3, relatedTo);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                crossSellingAchievementValue = Double.parseDouble(String.format("%.2f", resultSet.getDouble("Total_Shadow_Portfolio")));
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        }

        return crossSellingAchievementValue;
    }

    @Override
    public JSONArray viewAchievementValuesForSelected(JSONObject jasonobj) {
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();
        try {
            String queryViewIndividualTargertQueryForSelected = "select * from gcsm_individual_target_achievements where achievement_id=" + jasonobj.getString("achievement_id");

            

            preparedStatement = currentConnection.prepareStatement(queryViewIndividualTargertQueryForSelected);
            resultSet = preparedStatement.executeQuery();
            int i = 0;
            while (resultSet.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("achievement_id", resultSet.getInt("achievement_id"));
                m_jsObj.put("core_target_asset", resultSet.getString("core_target_asset"));
                m_jsObj.put("core_target_liabilities", resultSet.getString("core_target_liabilities"));
                m_jsObj.put("core_target_achievement_asset", resultSet.getString("core_target_achievement_asset"));
                m_jsObj.put("core_target_achievement_liabilities", resultSet.getString("core_target_achievement_liabilities"));
                m_jsObj.put("cs_asset_achievement", resultSet.getString("cs_asset_achievement"));
                m_jsObj.put("cs_liabilities_achievement", resultSet.getString("cs_liabilities_achievement"));
                m_jsObj.put("period_from_yearmonth", resultSet.getString("period_from_yearmonth"));
                m_jsObj.put("target_achivement_status", resultSet.getString("target_achivement_status"));
                m_jsObj.put("related_to", resultSet.getString("related_to"));
                m_jsObj.put("user_designation", resultSet.getString("user_designation"));
                m_jsObj.put("setup_user", resultSet.getString("setup_user"));
                m_jsObj.put("setup_time", resultSet.getString("setup_time"));
                m_jsObj.put("approved_rejected_user", resultSet.getString("approved_rejected_user"));
                m_jsObj.put("approved_rejected_time", resultSet.getString("approved_rejected_time"));
                m_jsObj.put("approval_reject_comment", resultSet.getString("approval_reject_comment"));
                jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("View_RewardValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return jsArr;
    }

    @Override
    public ResponceHandler modifyAchievementValues(JSONObject jasonobj) {
        responceHandler = new ResponceHandler();
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        jsonObejcts = new JSONObjects();
        IndividualTargetAchievementModel individualTargetAchievementModel;

        //Audit Trail
        Auditing auditing = new Auditing();
        String auditType = "UPDATE";
        String related_table = "gcsm_individual_target_achievements";
        String record_pk = "";
        String old_value = "";

        try {
            individualTargetAchievementModel = jsonObejcts.convertIndividualTargetAchievementModelToJSON(jasonobj.toString());
            String relatedTo=individualTargetAchievementModel.getRelated_to();
            String perfomedByNICUnit="";
            String relatedToCalculationValue="";
            if(relatedTo.contains("-")){
                perfomedByNICUnit="NIC";
                relatedToCalculationValue=relatedTo.split(" - ")[0];
            }
            else{
                perfomedByNICUnit="Unit";
                relatedToCalculationValue=relatedTo;
            }
            individualTargetAchievementModel.setCs_asset_achievement(calculateCSAchievementValues("Asset", individualTargetAchievementModel.getPeriod_from_yearmonth(),perfomedByNICUnit,relatedToCalculationValue));
            individualTargetAchievementModel.setCs_liabilities_achievement(calculateCSAchievementValues("Liability", individualTargetAchievementModel.getPeriod_from_yearmonth(),perfomedByNICUnit,relatedToCalculationValue));
            String individualTargetAchievementQuery
                    = "UPDATE gcsm_individual_target_achievements "
                    + "set core_target_asset=?, " //1
                    + "core_target_liabilities=?, " //2
                    + "core_target_achievement_asset=?, " //3
                    + "core_target_achievement_liabilities=?, " //4    
                    + "cs_asset_achievement=?, " //5
                    + "cs_liabilities_achievement=?, " //6                    
                    + "setup_user=?, " //7
                    + "related_to=?, " //8
                     + "user_designation=?, " //9
                    + "setup_time=now() "
                    + "where achievement_id=?";     //10

            preparedStatement = currentConnection.prepareStatement(individualTargetAchievementQuery);
            preparedStatement.setDouble(1, individualTargetAchievementModel.getCore_target_asset());
            preparedStatement.setDouble(2, individualTargetAchievementModel.getCore_target_liabilities());
            preparedStatement.setDouble(3, individualTargetAchievementModel.getCore_target_achievement_asset());
            preparedStatement.setDouble(4, individualTargetAchievementModel.getCore_target_achievement_liabilities());            
            preparedStatement.setDouble(5, individualTargetAchievementModel.getCs_asset_achievement());
            preparedStatement.setDouble(6, individualTargetAchievementModel.getCs_liabilities_achievement());
            preparedStatement.setString(7, jasonobj.get("user_username").toString());
            preparedStatement.setString(8, relatedTo);
            preparedStatement.setString(9, individualTargetAchievementModel.getUser_designation());
            preparedStatement.setInt(10, individualTargetAchievementModel.getAchievement_id());

            //Audit Trail 
            record_pk = "" + individualTargetAchievementModel.getAchievement_id();
            old_value = auditing.getAllRecords(record_pk, related_table).toString();

            if (preparedStatement.executeUpdate() <= 0) {

                responceHandler.setResponceModule("modifyAchievementValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");

            }

            responceHandler.setResponceModule("modifyAchievementValues");
            responceHandler.setResponceType("success");
            responceHandler.setResponceCode("0000");
            responceHandler.setResponceDescription("Successfully Modified");

            if (!databaseConnection.end_Connection(currentConnection)) {

                responceHandler.setResponceModule("modifyAchievementValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("Uh oh! An error occurred, database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }

            //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            auditing.saveAuditRecord(jasonobj.get("user_username").toString(), related_table, auditType, record_pk, old_value, new_value);

        } catch (SQLException ex) {
            log.error(ex.getMessage());

        } catch (Exception ex) {
            log.error(ex.getMessage());
        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("verify_Point_Values_Details");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return responceHandler;
    }

    @Override
    public JSONArray getCSPerfomedUsers(JSONObject data) {
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();
        try {
            String queryGetCSPerfomedUsers = "";
            if (data.getString("actionType").equals("insert")) {
                queryGetCSPerfomedUsers = "select CONCAT(cs_emp_id,' - ',cs_employee_name) as performed_user from gcsm_cross_selling_details where cs_emp_id!=''  and cs_emp_id not in (select related_to from gcsm_individual_target_achievements where target_achivement_status=0) and cs_own_company in (select user_businessline from gcsm_user where user_username='"+data.get("user_username")+"') union select cs_units_sold_by as performed_user from gcsm_cross_selling_details where cs_units_sold_by!=''  and cs_units_sold_by not in (select related_to from gcsm_individual_target_achievements where target_achivement_status=0) and cs_own_company in (select user_businessline from gcsm_user where user_username='"+data.get("user_username")+"')";
            } else if (data.getString("actionType").equals("modify")) {
                queryGetCSPerfomedUsers = "select CONCAT(cs_emp_id,' - ',cs_employee_name) as performed_user from gcsm_cross_selling_details where cs_emp_id!='' and cs_own_company in (select user_businessline from gcsm_user where user_username='"+data.get("user_username")+"')  union select cs_units_sold_by as performed_user from gcsm_cross_selling_details where cs_units_sold_by!='' and cs_own_company in (select user_businessline from gcsm_user where user_username='"+data.get("user_username")+"')";
            }

           

            preparedStatement = currentConnection.prepareStatement(queryGetCSPerfomedUsers);
            resultSet = preparedStatement.executeQuery();
            int i = 0;
            while (resultSet.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("performed_user", resultSet.getString("performed_user"));
                jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("getCSPerfomedUsers");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return jsArr;
    }

}
