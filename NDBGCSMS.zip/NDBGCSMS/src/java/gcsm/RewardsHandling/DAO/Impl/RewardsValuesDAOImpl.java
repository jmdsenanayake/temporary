/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.RewardsHandling.DAO.Impl;

import gcsm.RewardsHandling.DAO.RewardsValuesDAO;
import gcsm.RewardsHandling.Model.RewardsValuesModel;
import gcsm.Utitlities.Impl.Auditing;
import gcsm.Utitlities.Impl.DatabaseConnection;
import gcsm.Utitlities.Impl.JSONObjects;
import gcsm.Utitlities.Model.ResponceHandler;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Janaka_5977
 */
public class RewardsValuesDAOImpl implements RewardsValuesDAO {

    static Logger log = LogManager.getLogger(RewardsValuesDAOImpl.class.getName());
    private ResponceHandler responceHandler;
    static DatabaseConnection databaseConnection;
    static Connection currentConnection = null;
    private PreparedStatement preparedStatement = null;
    private ResultSet resultSet = null;
    private JSONObjects jsonObejcts;
    private JSONArray jsArr;

    @Override
    public JSONArray viewRewardsValueDetails(JSONObject jasonobj) {
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();
        try {
            String queryViewRewardValues = "select product.product_id,product.product_name,bl_name as product_owner,ifnull(reward_value_status,0) as reward_value_status,ifnull(reward_value_comments,'---') as reward_value_comments,ifnull(reward_value_setup_user,'---') as reward_value_setup_user,ifnull(reward_value_setup_timestamp,'---') as reward_value_setup_timestamp,ifnull(reward_value_modified_user,'---') as reward_value_modified_user,ifnull(reward_modified_timestamp,'---') as reward_modified_timestamp from gcsm_businessline,gcsm_product as product  left join gcsm_reward_values as rewards on product.product_id=rewards.reward_product_id where bl_id=product.product_businessline";

            preparedStatement = currentConnection.prepareStatement(queryViewRewardValues);
            resultSet = preparedStatement.executeQuery();
            int i = 0;
            while (resultSet.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("product_id", resultSet.getInt("product_id"));
                m_jsObj.put("product_name", resultSet.getString("product_name"));
                m_jsObj.put("product_owner", resultSet.getString("product_owner"));
                m_jsObj.put("reward_value_status", resultSet.getString("reward_value_status"));
                m_jsObj.put("reward_value_comments", resultSet.getString("reward_value_comments"));
                m_jsObj.put("reward_value_setup_user", resultSet.getString("reward_value_setup_user"));
                m_jsObj.put("reward_value_setup_timestamp", resultSet.getString("reward_value_setup_timestamp"));
                m_jsObj.put("reward_value_modified_user", resultSet.getString("reward_value_modified_user"));
                m_jsObj.put("reward_modified_timestamp", resultSet.getString("reward_modified_timestamp"));
                jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("View_RewardValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return jsArr;
    }

    @Override
    public JSONArray getRewardsValueForSelected(JSONObject jasonobj) {
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();
        String username = jasonobj.get("user_username").toString();
        String roleType = jasonobj.get("session_role_type").toString();
        try {
            String queryViewRewardValues = "select product.product_name, bl_name as product_owner,ifnull(reward_value_status,0) as reward_value_status, reward_level,tier1_reward_calc_method,tier1_reward_value_or_percentage,tier2_reward_calc_method,tier2_reward_value_or_percentage,reward_cap_value,reward_1_year_less_method,reward_1_year_less_percentage,reward_1_2_year_method,reward_1_2_year_percentage,reward_value_status,reward_value_comments from gcsm_businessline, gcsm_product as product left join gcsm_reward_values as rewards on product.product_id=rewards.reward_product_id where bl_id=product.product_businessline and product_id=" + jasonobj.getString("reward_product_id");

            preparedStatement = currentConnection.prepareStatement(queryViewRewardValues);
            resultSet = preparedStatement.executeQuery();
            int i = 0;
            while (resultSet.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("product_name", resultSet.getString("product_name"));
                m_jsObj.put("product_owner", resultSet.getString("product_owner"));
                m_jsObj.put("reward_level", resultSet.getString("reward_level"));
                m_jsObj.put("tier1_reward_calc_method", resultSet.getString("tier1_reward_calc_method"));
                m_jsObj.put("tier1_reward_value_or_percentage", resultSet.getString("tier1_reward_value_or_percentage"));
                m_jsObj.put("tier2_reward_calc_method", resultSet.getString("tier2_reward_calc_method"));
                m_jsObj.put("tier2_reward_value_or_percentage", resultSet.getString("tier2_reward_value_or_percentage"));
                m_jsObj.put("reward_cap_value", resultSet.getString("reward_cap_value"));
                m_jsObj.put("reward_1_year_less_method", resultSet.getString("reward_1_year_less_method"));
                m_jsObj.put("reward_1_year_less_percentage", resultSet.getString("reward_1_year_less_percentage"));
                m_jsObj.put("reward_1_2_year_method", resultSet.getString("reward_1_2_year_method"));
                m_jsObj.put("reward_1_2_year_percentage", resultSet.getString("reward_1_2_year_percentage"));
                m_jsObj.put("reward_value_status", resultSet.getString("reward_value_status"));
                m_jsObj.put("reward_value_comments", resultSet.getString("reward_value_comments"));
                jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("View_RewardValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return jsArr;
    }

    @Override
    public ResponceHandler modifyRewardValues(JSONObject jasonobj) {
        responceHandler = new ResponceHandler();
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        jsonObejcts = new JSONObjects();
        RewardsValuesModel newRewardsValuesModel;

        //Audit Trail
        String auditType = "";
        Auditing auditing = new Auditing();
        String related_table = "gcsm_reward_values";
        String record_pk = "";
        String old_value = "##Empty##";

        try {
            newRewardsValuesModel = jsonObejcts.convertRewardsValuesModelToJSON(jasonobj.toString());
            String crossSellingRecordAvailable = "SELECT * FROM gcsm_reward_values WHERE reward_product_id=?";
            if (!databaseConnection.start_Connection(currentConnection)) {

                responceHandler.setResponceModule("modifyRewardValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("00001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection establishing problem.");

                log.error("Uh oh! An error occurred, database connection establishing problem.");
                throw new Exception("An error occurred, database connection establishing problem.");
            }

            preparedStatement = currentConnection.prepareStatement(crossSellingRecordAvailable);
            preparedStatement.setInt(1, newRewardsValuesModel.getReward_product_id());

            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                //Audit Trail
                record_pk = "" + newRewardsValuesModel.getReward_product_id();
                old_value = auditing.getAllRecords(record_pk, related_table).toString();
                String rewardValuesModifyingQuery
                        = "UPDATE gcsm_reward_values "
                        + "set reward_level=?, " //1
                        + "tier1_reward_calc_method=?, " //2
                        + "tier1_reward_value_or_percentage=?, " //3
                        + "tier2_reward_calc_method=?, " //4
                        + "tier2_reward_value_or_percentage=?, " //5
                        + "reward_cap_value=?, " //6
                        + "reward_1_year_less_method=?, " //7
                        + "reward_1_year_less_percentage=?, " //8
                        + "reward_1_2_year_method=?, " //9
                        + "reward_1_2_year_percentage=?," //10
                        + "reward_value_status=?, " //11
                        + "reward_value_modified_user=?, " //12
                        + "reward_modified_timestamp=now(), "
                        + "reward_value_comments=? " //13
                        + "where reward_product_id=?";              //14

                preparedStatement = currentConnection.prepareStatement(rewardValuesModifyingQuery);
                preparedStatement.setInt(1, newRewardsValuesModel.getReward_level());
                preparedStatement.setString(2, newRewardsValuesModel.getTier1_reward_calc_method());
                preparedStatement.setDouble(3, newRewardsValuesModel.getTier1_reward_value_or_percentage());
                preparedStatement.setString(4, newRewardsValuesModel.getTier2_reward_calc_method());
                preparedStatement.setDouble(5, newRewardsValuesModel.getTier2_reward_value_or_percentage());
                preparedStatement.setDouble(6, newRewardsValuesModel.getReward_cap_value());
                preparedStatement.setString(7, newRewardsValuesModel.getReward_1_year_less_method());
                preparedStatement.setDouble(8, newRewardsValuesModel.getReward_1_year_less_percentage());
                preparedStatement.setString(9, newRewardsValuesModel.getReward_1_2_year_method());
                preparedStatement.setDouble(10, newRewardsValuesModel.getReward_1_2_year_percentage());
                preparedStatement.setInt(11, 1);
                preparedStatement.setString(12, jasonobj.get("user_username").toString());
                preparedStatement.setString(13, newRewardsValuesModel.getReward_value_comments());
                preparedStatement.setInt(14, newRewardsValuesModel.getReward_product_id());

                if (preparedStatement.executeUpdate() <= 0) {

                    responceHandler.setResponceModule("modifyRewardValues");
                    responceHandler.setResponceType("error");
                    responceHandler.setResponceCode("0001");
                    responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");

                }

                responceHandler.setResponceModule("modifyRewardValues");
                responceHandler.setResponceType("success");
                responceHandler.setResponceCode("0000");
                responceHandler.setResponceDescription("Awesome! You were successful.");
                //Audit Trail
                auditType = "UPDATE";

            } else {
                String rewardValuesInitialConfigureQuery
                        = "INSERT INTO gcsm_reward_values ("
                        + "reward_product_id, " //1
                        + "reward_level, " //2
                        + "tier1_reward_calc_method, " //3
                        + "tier1_reward_value_or_percentage, " //4
                        + "tier2_reward_calc_method, " //5
                        + "tier2_reward_value_or_percentage, " //6
                        + "reward_cap_value," //7
                        + "reward_1_year_less_method, " //8
                        + "reward_1_year_less_percentage," //9
                        + "reward_1_2_year_method," //10
                        + "reward_1_2_year_percentage," //11
                        + "reward_value_status," //12
                        + "reward_value_setup_user," //13
                        + "reward_value_setup_timestamp,"
                        + "reward_value_modified_user," //14
                        + "reward_modified_timestamp,"
                        + "reward_value_comments) " //15
                        + "values (?,?,?,?,?,?,?,?,?,?,?,?,?,now(),?,now(),?)";

                preparedStatement = currentConnection.prepareStatement(rewardValuesInitialConfigureQuery);
                preparedStatement.setInt(1, newRewardsValuesModel.getReward_product_id());
                preparedStatement.setInt(2, newRewardsValuesModel.getReward_level());
                preparedStatement.setString(3, newRewardsValuesModel.getTier1_reward_calc_method());
                preparedStatement.setDouble(4, newRewardsValuesModel.getTier1_reward_value_or_percentage());
                preparedStatement.setString(5, newRewardsValuesModel.getTier2_reward_calc_method());
                preparedStatement.setDouble(6, newRewardsValuesModel.getTier2_reward_value_or_percentage());
                preparedStatement.setDouble(7, newRewardsValuesModel.getReward_cap_value());
                preparedStatement.setString(8, newRewardsValuesModel.getReward_1_year_less_method());
                preparedStatement.setDouble(9, newRewardsValuesModel.getReward_1_year_less_percentage());
                preparedStatement.setString(10, newRewardsValuesModel.getReward_1_2_year_method());
                preparedStatement.setDouble(11, newRewardsValuesModel.getReward_1_2_year_percentage());
                preparedStatement.setInt(12, 1);
                preparedStatement.setString(13, jasonobj.get("user_username").toString());
                preparedStatement.setString(14, jasonobj.get("user_username").toString());
                preparedStatement.setString(15, newRewardsValuesModel.getReward_value_comments());

                if (preparedStatement.executeUpdate() <= 0) {

                    responceHandler.setResponceModule("insertRewardValues");
                    responceHandler.setResponceType("error");
                    responceHandler.setResponceCode("0001");
                    responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");

                }

                responceHandler.setResponceModule("insertRewardValues");
                responceHandler.setResponceType("success");
                responceHandler.setResponceCode("0000");
                responceHandler.setResponceDescription("Awesome! You were successful.");

                //Audit Trail
                auditType = "INSERT";
                record_pk = "" + newRewardsValuesModel.getReward_product_id();
            }

            if (!databaseConnection.end_Connection(currentConnection)) {

                responceHandler.setResponceModule("modifyRewardValues");
                responceHandler.setResponceType("error");;
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("Uh oh! An error occurred, database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }

            //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            switch (auditType) {
                case "INSERT": {
                    auditing.saveAuditRecord(jasonobj.get("user_username").toString(), related_table, auditType, record_pk, old_value, new_value);
                    break;
                }
                case "UPDATE": {
                    auditing.saveAuditRecord(jasonobj.get("user_username").toString(), related_table, auditType, record_pk, old_value, new_value);
                    break;
                }
            }

        } catch (SQLException ex) {
            log.error(ex.getMessage());

        } catch (Exception ex) {
            log.error(ex.getMessage());
        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("modifyRewardValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return responceHandler;
    }

    @Override
    public ResponceHandler verifyRewardValues(JSONObject jasonobj, int verifyReject) {
        responceHandler = new ResponceHandler();
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        jsonObejcts = new JSONObjects();
        RewardsValuesModel newRewardsValuesModel;

        //Audit Trail
        Auditing auditing = new Auditing();
        String auditType = "UPDATE";
        String related_table = "gcsm_reward_values";
        String record_pk = "";
        String old_value = "";

        try {
            newRewardsValuesModel = jsonObejcts.convertRewardsValuesModelToJSON(jasonobj.toString());

            //Audit Trail
            record_pk = "" + newRewardsValuesModel.getReward_product_id();
            old_value = auditing.getAllRecords(record_pk, related_table).toString();

            String rewardValuesVerifyQuery
                    = "UPDATE gcsm_reward_values "
                    + "set reward_value_status=" + verifyReject + ", "
                    + "reward_value_comments=concat(reward_value_comments,' ',?), " //1
                    + "reward_value_modified_user=?, " //2
                    + "reward_modified_timestamp=now() "
                    + "where reward_product_id=?";              //3

            preparedStatement = currentConnection.prepareStatement(rewardValuesVerifyQuery);
            preparedStatement.setString(1, newRewardsValuesModel.getReward_value_comments());
            preparedStatement.setString(2, jasonobj.get("user_username").toString());
            preparedStatement.setInt(3, newRewardsValuesModel.getReward_product_id());

            if (preparedStatement.executeUpdate() <= 0) {

                responceHandler.setResponceModule("verify_Reward_Value_Details");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");

            }

            responceHandler.setResponceModule("verify_Reward_Value_Details");
            responceHandler.setResponceType("success");
            responceHandler.setResponceCode("0000");
            responceHandler.setResponceDescription(verifyReject == 2 ? "Succefully Approved" : "Successfully Rejected");

            if (!databaseConnection.end_Connection(currentConnection)) {

                responceHandler.setResponceModule("verify_Reward_Value_Details");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("Uh oh! An error occurred, database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }

            //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            auditing.saveAuditRecord(jasonobj.get("user_username").toString(), related_table, auditType, record_pk, old_value, new_value);

        } catch (SQLException ex) {
            log.error(ex.getMessage());

        } catch (Exception ex) {
            log.error(ex.getMessage());
        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("verify_Reward_Value_Details_Data");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return responceHandler;
    }

    @Override
    public ResponceHandler addStaffRewardEligibility(JSONObject data) {
        ResponceHandler responceHandler = new ResponceHandler();
        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        jsonObejcts = new JSONObjects();
        ResultSet resultSet = null;
        PreparedStatement preparedStatement = null;

        //Audit Trail        
        Auditing auditing = new Auditing();
        String auditType = "INSERT";
        String related_table = "gcsm_reward_eligibility";
        String record_pk = "";
        String old_value = "##Empty##";

        if (!isAlreadyConfigured(data)) {
            try {

                String addStaffRewardEligibilityQuery
                        = "INSERT INTO gcsm_reward_eligibility ("
                        + "eligibility_reward_from, " //1
                        + "eligibility_reward_to, " //2
                        + "eligibility_designation, " //3
                        + "eligibility_comment, " //4
                        + "setup_user, " //5
                        + "setup_timestamp) "
                        + "values (?,?,?,?,?,now())";

                preparedStatement = currentConnection.prepareStatement(addStaffRewardEligibilityQuery, Statement.RETURN_GENERATED_KEYS);
                preparedStatement.setString(1, data.getString("rewardFrom"));
                preparedStatement.setString(2, data.getString("rewardTo"));
                preparedStatement.setString(3, data.getString("designations"));
                preparedStatement.setString(4, data.getString("comment"));
                preparedStatement.setString(5, data.getString("user_username"));

                if (preparedStatement.executeUpdate() <= 0) {

                    responceHandler.setResponceModule("insertPointValues");
                    responceHandler.setResponceType("error");
                    responceHandler.setResponceCode("0001");
                    responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");

                }

                responceHandler.setResponceModule("insertPointValues");
                responceHandler.setResponceType("success");
                responceHandler.setResponceCode("0000");
                responceHandler.setResponceDescription("Awesome! You were successful.");

                //Audit Trail
                resultSet = preparedStatement.getGeneratedKeys();
                resultSet.next();
                record_pk = "" + (resultSet.getInt(1));

                if (!databaseConnection.end_Connection(currentConnection)) {

                    responceHandler.setResponceModule("insertPointValues");
                    responceHandler.setResponceType("error");;
                    responceHandler.setResponceCode("0001");
                    responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                    log.error("Uh oh! An error occurred, database connection terminating problem.");
                    throw new Exception("An error occurred, database connection terminating problem.");
                }

                //Audit Trail
                String new_value = auditing.getAllRecords(record_pk, related_table).toString();
                auditing.saveAuditRecord(data.get("user_username").toString(), related_table, auditType, record_pk, old_value, new_value);

            } catch (SQLException ex) {
                log.error(ex.getMessage());

            } catch (Exception ex) {
                log.error(ex.getMessage());
            } finally {

                try {

                    if (resultSet != null) {
                        resultSet.close();
                    }

                    if (preparedStatement != null) {
                        preparedStatement.close();
                    }

                    if (currentConnection != null) {
                        currentConnection.close();
                    }

                } catch (Exception e) {
                    log.error(e.getMessage());
                    responceHandler.setResponceModule("insertPointValues");
                    responceHandler.setResponceType("error");
                    responceHandler.setResponceCode("0001");
                    responceHandler.setResponceDescription("Error occured in insert Point Value");
                    log.error(e.getMessage());

                }
            }

        }
        else{
                responceHandler.setResponceModule("insertPointValues");
                responceHandler.setResponceType("success");
                responceHandler.setResponceCode("0000");
                responceHandler.setResponceDescription("Awesome! You were successful.");
        }

        return responceHandler;
    }

    private boolean isAlreadyConfigured(JSONObject data) {

        boolean isConfigured = false;
        ResponceHandler responceHandler = new ResponceHandler();
        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        jsonObejcts = new JSONObjects();

        //Audit Trail
        String auditType = "";
        Auditing auditing = new Auditing();
        String related_table = "gcsm_reward_eligibility";
        String record_pk = "";
        String old_value = "##Empty##";

        try {

            String crossSellingRecordAvailable = "SELECT * FROM gcsm_reward_eligibility WHERE eligibility_reward_from=? and eligibility_reward_to=?";
            if (!databaseConnection.start_Connection(currentConnection)) {

                responceHandler.setResponceModule("modifyRewardValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("00001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection establishing problem.");

                log.error("Uh oh! An error occurred, database connection establishing problem.");
                throw new Exception("An error occurred, database connection establishing problem.");
            }

            preparedStatement = currentConnection.prepareStatement(crossSellingRecordAvailable);
            preparedStatement.setString(1, data.getString("rewardFrom"));
            preparedStatement.setString(2, data.getString("rewardTo"));

            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                //Audit Trail
                int eligibilityID = resultSet.getInt("eligibility_id");
                record_pk = "" + eligibilityID;
                old_value = auditing.getAllRecords(record_pk, related_table).toString();

                if (eligibilityID > 0) {
                    isConfigured = true;
                    String eligibilityUpdateQuery
                            = "UPDATE gcsm_reward_eligibility "
                            + "set eligibility_designation=?, " //1
                            + "eligibility_comment=?, " //2
                            + "setup_user=?, " //3
                            + "setup_timestamp=now() "
                            + "where eligibility_id=?";              //4

                    preparedStatement = currentConnection.prepareStatement(eligibilityUpdateQuery);
                    preparedStatement.setString(1, data.getString("designations"));
                    preparedStatement.setString(2, data.getString("comment"));
                    preparedStatement.setString(3, data.getString("user_username"));
                    preparedStatement.setInt(4, eligibilityID);

                    if (preparedStatement.executeUpdate() <= 0) {

                        responceHandler.setResponceModule("modifyRewardValues");
                        responceHandler.setResponceType("error");
                        responceHandler.setResponceCode("0001");
                        responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");

                    }

                    responceHandler.setResponceModule("modifyRewardValues");
                    responceHandler.setResponceType("success");
                    responceHandler.setResponceCode("0000");
                    responceHandler.setResponceDescription("Awesome! You were successful.");
                    //Audit Trail
                    auditType = "UPDATE";

                }
                if (!databaseConnection.end_Connection(currentConnection)) {

                    responceHandler.setResponceModule("modifyRewardValues");
                    responceHandler.setResponceType("error");;
                    responceHandler.setResponceCode("0001");
                    responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                    log.error("Uh oh! An error occurred, database connection terminating problem.");
                    throw new Exception("An error occurred, database connection terminating problem.");
                }

                //Audit Trail
                String new_value = auditing.getAllRecords(record_pk, related_table).toString();

                auditing.saveAuditRecord(data.get("user_username").toString(), related_table, auditType, record_pk, old_value, new_value);

            }

        } catch (SQLException ex) {
            log.error(ex.getMessage());

        } catch (Exception ex) {
            log.error(ex.getMessage());
        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("modifyRewardValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return isConfigured;
    }
    
    @Override
    public JSONArray viewRewardEligibility(JSONObject jasonobj) {
        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();
        PreparedStatement preparedStatement=null;
        ResultSet resultSet=null;
        try {
            String queryViewRewardValues = "SELECT * FROM gcsm_reward_eligibility order by setup_timestamp desc";

            preparedStatement = currentConnection.prepareStatement(queryViewRewardValues);
            resultSet = preparedStatement.executeQuery();
            int i = 0;
            while (resultSet.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("eligibility_id", resultSet.getInt("eligibility_id"));
                m_jsObj.put("eligibility_reward_from", resultSet.getString("eligibility_reward_from"));
                m_jsObj.put("eligibility_reward_to", resultSet.getString("eligibility_reward_to"));
                m_jsObj.put("eligibility_designation", resultSet.getString("eligibility_designation"));
                m_jsObj.put("eligibility_comment", resultSet.getString("eligibility_comment"));
                m_jsObj.put("setup_user", resultSet.getString("setup_user"));
                m_jsObj.put("setup_timestamp", resultSet.getString("setup_timestamp"));
                jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("View_RewardValues");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return jsArr;
    }

}
