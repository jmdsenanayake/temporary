/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.CrossSelling.DAO;

import gcsm.CrossSelling.Model.CrossSellingManagementModel;
import gcsm.Utitlities.Model.ResponceHandler;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Janaka_5977
 */
public interface CrossSellingManagementDAO {

    public ResponceHandler saveCrossSellingData(JSONObject jasonobj);

    public JSONArray viewCrossSellingData(JSONObject jasonobj);

    public JSONArray getInfoCrossSelling(JSONObject jasonobj);
    
    public ResponceHandler updateCrossSellingData(JSONObject jasonobj);
    
    public ResponceHandler verifyCrossSellingData(JSONObject jasonobj,int newStatus);

    public JSONArray viewCrossSellingClaims(JSONObject jasonobj);
    
    public int getBusinessLineID(String businessLineName);
    
    public int getProductID(String productName);

    public ResponceHandler saveCrossSellingBulkData(List<CrossSellingManagementModel> crossSellingManagementModelList, String username);

    public boolean checkFeeIncomeApplicability(String productID);
    
}
