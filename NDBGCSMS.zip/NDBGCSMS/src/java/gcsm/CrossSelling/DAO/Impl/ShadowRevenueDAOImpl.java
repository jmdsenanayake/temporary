/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.CrossSelling.DAO.Impl;

import gcsm.CrossSelling.DAO.ShadowRevenueDAO;
import gcsm.CrossSelling.Model.ShadowRevenueModel;
import gcsm.Utitlities.Impl.Auditing;
import gcsm.Utitlities.Impl.DatabaseConnection;
import gcsm.Utitlities.Impl.JSONObjects;
import gcsm.Utitlities.Impl.SQLServerDatabaseConnection;
import gcsm.Utitlities.Model.ResponceHandler;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Janaka_5977
 */
public class ShadowRevenueDAOImpl implements ShadowRevenueDAO {

    static Logger log = LogManager.getLogger(ShadowRevenueDAOImpl.class.getName());
    private ResponceHandler responceHandler;
    private JSONArray jsArr;

    @Override
    public JSONArray getShadowRevenueDetails(JSONObject jasonobj) {
        new ShadowRevenueDAOImpl().generateShadowRevenueTable(jasonobj);

        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        JSONObject m_jsObj;
        jsArr = new JSONArray();

        try {
            if (!databaseConnection.start_Connection(currentConnection)) {

            } else {
                String sql = "select gcsm_shadow_revenue.*,csowner.bl_name as cs_own_company,product.product_name as cs_product,prodowner.bl_name as cs_product_owner,cs.cs_product_status,cs.cs_customer_name,cs.cs_customer_nic,cs.cs_customer_contactNo,cs.cs_cid,cs.cs_emp_id,cs.cs_employee_name,cs.cs_units_sold_by,cs.cs_date from gcsm_cross_selling_details as cs, gcsm_product as product, gcsm_businessline as csowner, gcsm_businessline as prodowner,gcsm_shadow_revenue where cs.cs_product=product.product_id and cs.cs_own_company=csowner.bl_id and cs.cs_product_owner=prodowner.bl_id and shadow_cs_contract_no=cs_contract_no and cs_status=5 and shadow_year_month=? and year(cs_date)=? and month(cs_date)<=? and cs_id=shadow_cs_id order by cs_own_company,shadow_setup_timestamp";
                preparedStatement = currentConnection.prepareStatement(sql);
                String yearMonth = jasonobj.get("shadow_year_month").toString();
                String year = yearMonth.substring(0, 4);
                String month = yearMonth.substring(4, 6);
                preparedStatement.setString(1, yearMonth);
                preparedStatement.setString(2, year);
                preparedStatement.setString(3, month);
                resultSet = preparedStatement.executeQuery();
                int i = 0;
                while (resultSet.next()) {
                    m_jsObj = new JSONObject();
                    m_jsObj.put("shadow_revenue_id", resultSet.getInt("shadow_revenue_id"));
                    m_jsObj.put("shadow_cs_contract_no", resultSet.getString("shadow_cs_contract_no"));
                    m_jsObj.put("shadow_year_month", resultSet.getString("shadow_year_month"));
                    m_jsObj.put("shadow_NII_value", String.format("%.2f", resultSet.getDouble("shadow_NII_value")));
                    m_jsObj.put("shadow_fee_income", String.format("%.2f", resultSet.getDouble("shadow_fee_income")));
                    m_jsObj.put("shadow_annual_fee", String.format("%.2f", resultSet.getDouble("shadow_annual_fee")));
                    m_jsObj.put("shadow_other_amount", String.format("%.2f", resultSet.getDouble("shadow_other_amount")));
                    m_jsObj.put("shadow_revenue_value", String.format("%.2f", resultSet.getDouble("shadow_revenue_value")));
                    m_jsObj.put("shadow_portfolio_value", String.format("%.2f", resultSet.getDouble("shadow_portfolio_value")));
                    m_jsObj.put("shadow_revenue_status", resultSet.getInt("shadow_revenue_status"));
                    m_jsObj.put("shadow_reject_reason", resultSet.getString("shadow_reject_reason"));
                    m_jsObj.put("shadow_year_month", resultSet.getString("shadow_year_month"));
                    m_jsObj.put("shadow_setup_user", resultSet.getString("shadow_setup_user"));
                    m_jsObj.put("shadow_setup_timestamp", resultSet.getString("shadow_setup_timestamp"));
                    m_jsObj.put("shadow_modified_user", resultSet.getString("shadow_modified_user"));
                    m_jsObj.put("shadow_modified_timestamp", resultSet.getString("shadow_modified_timestamp"));
                    m_jsObj.put("cs_own_company", resultSet.getString("cs_own_company"));
                    m_jsObj.put("cs_product", resultSet.getString("cs_product"));
                    m_jsObj.put("cs_product_owner", resultSet.getString("cs_product_owner"));
                    m_jsObj.put("cs_product_status", resultSet.getString("cs_product_status"));
                    m_jsObj.put("cs_customer_name", resultSet.getString("cs_customer_name"));
                    m_jsObj.put("cs_customer_nic", resultSet.getString("cs_customer_nic"));
                    m_jsObj.put("cs_customer_contactNo", resultSet.getString("cs_customer_contactNo"));
                    m_jsObj.put("cs_cid", resultSet.getString("cs_cid"));
                    m_jsObj.put("cs_emp_id", resultSet.getString("cs_emp_id"));
                    m_jsObj.put("cs_employee_name", resultSet.getString("cs_employee_name"));
                    m_jsObj.put("cs_units_sold_by", resultSet.getString("cs_units_sold_by"));
                    m_jsObj.put("cs_date", resultSet.getString("cs_date"));
                    jsArr.put(i, m_jsObj);
                    i++;
                }
            }
            databaseConnection.end_Connection(currentConnection);

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (currentConnection != null) {
                    currentConnection.close();
                }
            } catch (Exception e) {
                log.error(e.getMessage());
            }

        }

        return jsArr;

    }

    private void generateShadowRevenueTable(JSONObject jasonobj) {
        String username = jasonobj.getString("user_username");

        int shadowCalculationStatusCurrentID = getCurrentShadowCalculationID();

        if (shadowCalculationStatusCurrentID == 0) {

            initiateOrUpdateShadowCalculationStatus(0, username);
            shadowCalculationStatusCurrentID = getCurrentShadowCalculationID();
            String yearMonth = jasonobj.get("shadow_year_month").toString();
            System.out.println("yearMonth" + yearMonth);

            Map<String, String> shadowNotCalculatedMap = getShadowNotCalculatedContractMap(yearMonth);
            System.out.println(shadowNotCalculatedMap.toString());
            Iterator it = shadowNotCalculatedMap.entrySet().iterator();
            while (it.hasNext()) {

                Map.Entry pair = (Map.Entry) it.next();
                String cs_id = (String) pair.getKey();
                String contractNo = (String) pair.getValue();

                double portfolioValue = 0;
                double NIIamount = 0;
                double feeIncome = 0;
                double annualFee = 0;
                double otherAmount = 0;
                double shadowRevenue = 0;
                String shadowBasis = getShadowRevenueBasis(contractNo);
                if (shadowBasis.equals("Net Interest Income (NII)")) {
                    NIIamount = getNIIAmountForCrossSelling(contractNo, yearMonth);
                } else if (shadowBasis.equals("Fee Income")) {
                    feeIncome = getFeeAmount(contractNo);
                } else if (shadowBasis.equals("NII Fee Income")) {
                    NIIamount = getNIIAmountForCrossSelling(contractNo, yearMonth);
                    feeIncome = getFeeAmount(contractNo);
                } else if (shadowBasis.equals("Annual Fee")) {
                    annualFee = getAnnualFee(contractNo);
                } else if (shadowBasis.equals("Other Amount")) {
                    otherAmount = getOtherAmount(contractNo, yearMonth);
                }

                shadowRevenue = NIIamount + feeIncome + annualFee + otherAmount;

                portfolioValue = getPortfolioValue(contractNo, yearMonth);

                DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
                Connection currentConnection = databaseConnection.get_JDBC_Connection();
                PreparedStatement preparedStatement = null;
                ResultSet resultSet = null;

                //Audit Trail        
                Auditing auditing = new Auditing();
                String auditType = "INSERT";
                String related_table = "gcsm_shadow_revenue";
                String record_pk = "";
                String old_value = "##Empty##";

                try {

                    if (!databaseConnection.start_Connection(currentConnection)) {

                    } else {
                        String sql
                                = "INSERT INTO gcsm_shadow_revenue("
                                + "shadow_cs_contract_no," //1
                                + "shadow_year_month," //2
                                + "shadow_NII_value," //3
                                + "shadow_fee_income," //4
                                + "shadow_annual_fee," //5
                                + "shadow_other_amount," //6
                                + "shadow_revenue_value," //7
                                + "shadow_portfolio_value," //8
                                + "shadow_revenue_status," //9
                                + "shadow_setup_user," //10                        
                                + "shadow_modified_user,"//11
                                + "shadow_setup_timestamp,"
                                + "shadow_modified_timestamp,"
                                + "shadow_cs_id)"//12
                                + " VALUES(?,?,?,?,?,?,?,?,?,?,?,now(),now(),?)";

                        preparedStatement = currentConnection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                        preparedStatement.setString(1, contractNo);
                        preparedStatement.setString(2, yearMonth);
                        preparedStatement.setDouble(3, NIIamount);
                        preparedStatement.setDouble(4, feeIncome);
                        preparedStatement.setDouble(5, annualFee);
                        preparedStatement.setDouble(6, otherAmount);
                        preparedStatement.setDouble(7, shadowRevenue);
                        preparedStatement.setDouble(8, portfolioValue);
                        preparedStatement.setInt(9, 0);
                        preparedStatement.setString(10, jasonobj.get("user_username").toString());
                        preparedStatement.setString(11, jasonobj.get("user_username").toString());
                        preparedStatement.setString(12, cs_id);
                        int executeUpdate = preparedStatement.executeUpdate();
                        resultSet = preparedStatement.getGeneratedKeys();
                    }

                    while (resultSet.next()) {
                        //Audit Trail
                        record_pk = "" + (resultSet.getInt(1));
                    }

                    if (!databaseConnection.end_Connection(currentConnection)) {

                        log.error("Uh oh! An error occurred, database connection terminating problem.");

                    }

                    //Audit Trail
                    String new_value = auditing.getAllRecords(record_pk, related_table).toString();
                    auditing.saveAuditRecord(jasonobj.get("user_username").toString(), related_table, auditType, record_pk, old_value, new_value);

                } catch (Exception e) {
                    log.error(e.getMessage());

                } finally {

                    try {

                        if (resultSet != null) {
                            resultSet.close();
                        }

                        if (preparedStatement != null) {
                            preparedStatement.close();
                        }

                        if (currentConnection != null) {
                            currentConnection.close();
                        }

                    } catch (Exception e) {
                        log.error(e.getMessage());
                    }
                }

                it.remove(); // avoids a ConcurrentModificationException
            }
//            //List<String> shadowNotCalculatedList = getShadowNotCalculatedContractList(yearMonth);
//            for (String contractNo : shadowNotCalculatedList) {
////                if (!checkContractAlreadyExists(contractNo, yearMonth)) {
//                    double portfolioValue = 0;
//                    double NIIamount = 0;
//                    double feeIncome = 0;
//                    double annualFee = 0;
//                    double otherAmount = 0;
//                    double shadowRevenue = 0;
//                    String shadowBasis = getShadowRevenueBasis(contractNo);
//                    if (shadowBasis.equals("Net Interest Income (NII)")) {
//                        NIIamount = getNIIAmountForCrossSelling(contractNo, yearMonth);
//                    } else if (shadowBasis.equals("Fee Income")) {
//                        feeIncome = getFeeAmount(contractNo);
//                    } else if (shadowBasis.equals("NII Fee Income")) {
//                        NIIamount = getNIIAmountForCrossSelling(contractNo, yearMonth);
//                        feeIncome = getFeeAmount(contractNo);
//                    } else if (shadowBasis.equals("Annual Fee")) {
//                        annualFee = getAnnualFee(contractNo);
//                    } else if (shadowBasis.equals("Other Amount")) {
//                        otherAmount = getOtherAmount(contractNo, yearMonth);
//                    }
//
//                    shadowRevenue = NIIamount + feeIncome + annualFee + otherAmount;
//
//                    portfolioValue = getPortfolioValue(contractNo, yearMonth);
//
//                    DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
//                    Connection currentConnection = databaseConnection.get_JDBC_Connection();
//                    PreparedStatement preparedStatement = null;
//                    ResultSet resultSet = null;
//
//                    //Audit Trail        
//                    Auditing auditing = new Auditing();
//                    String auditType = "INSERT";
//                    String related_table = "gcsm_shadow_revenue";
//                    String record_pk = "";
//                    String old_value = "##Empty##";
//
//                    try {
//
//                        if (!databaseConnection.start_Connection(currentConnection)) {
//
//                        } else {
//                            String sql
//                                    = "INSERT INTO gcsm_shadow_revenue("
//                                    + "shadow_cs_contract_no," //1
//                                    + "shadow_year_month," //2
//                                    + "shadow_NII_value," //3
//                                    + "shadow_fee_income," //4
//                                    + "shadow_annual_fee," //5
//                                    + "shadow_other_amount," //6
//                                    + "shadow_revenue_value," //7
//                                    + "shadow_portfolio_value," //8
//                                    + "shadow_revenue_status," //9
//                                    + "shadow_setup_user," //10                        
//                                    + "shadow_modified_user,"//11
//                                    + "shadow_setup_timestamp,"
//                                    + "shadow_modified_timestamp)"
//                                    + " VALUES(?,?,?,?,?,?,?,?,?,?,?,now(),now())";
//
//                            preparedStatement = currentConnection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
//                            preparedStatement.setString(1, contractNo);
//                            preparedStatement.setString(2, yearMonth);
//                            preparedStatement.setDouble(3, NIIamount);
//                            preparedStatement.setDouble(4, feeIncome);
//                            preparedStatement.setDouble(5, annualFee);
//                            preparedStatement.setDouble(6, otherAmount);
//                            preparedStatement.setDouble(7, shadowRevenue);
//                            preparedStatement.setDouble(8, portfolioValue);
//                            preparedStatement.setInt(9, 0);
//                            preparedStatement.setString(10, jasonobj.get("user_username").toString());
//                            preparedStatement.setString(11, jasonobj.get("user_username").toString());
//                            int executeUpdate = preparedStatement.executeUpdate();
//                            resultSet = preparedStatement.getGeneratedKeys();
//                        }
//
//                        while (resultSet.next()) {
//                            //Audit Trail
//                            record_pk = "" + (resultSet.getInt(1));
//                        }
//
//                        if (!databaseConnection.end_Connection(currentConnection)) {
//
//                            log.error("Uh oh! An error occurred, database connection terminating problem.");
//
//                        }
//
//                        //Audit Trail
//                        String new_value = auditing.getAllRecords(record_pk, related_table).toString();
//                        auditing.saveAuditRecord(jasonobj.get("user_username").toString(), related_table, auditType, record_pk, old_value, new_value);
//
//                    } catch (Exception e) {
//                        log.error(e.getMessage());
//
//                    } finally {
//
//                        try {
//
//                            if (resultSet != null) {
//                                resultSet.close();
//                            }
//
//                            if (preparedStatement != null) {
//                                preparedStatement.close();
//                            }
//
//                            if (currentConnection != null) {
//                                currentConnection.close();
//                            }
//
//                        } catch (Exception e) {
//                            log.error(e.getMessage());
//                        }
//                    }
//                }
//            }
            initiateOrUpdateShadowCalculationStatus(shadowCalculationStatusCurrentID, username);
        }

    }

    // private List getShadowNotCalculatedContractList(String yearMonth) {
    private Map getShadowNotCalculatedContractMap(String yearMonth) {
        String year = yearMonth.substring(0, 4);
        String month = yearMonth.substring(4, 6);
        Map shadowNotCalculatedMap = new HashMap<>();
        //List shadowNotCalculatedList = new ArrayList<String>();

        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {

            String sql = "Select cs_id,cs_contract_no from gcsm_cross_selling_details where cs_status=5  and year(cs_date)=? and month(cs_date)<=? and cs_contract_no not in (select shadow_cs_contract_no from gcsm_shadow_revenue where shadow_year_month=?)";

            preparedStatement = currentConnection.prepareStatement(sql);
            preparedStatement.setString(1, year);
            preparedStatement.setString(2, month);
            preparedStatement.setString(3, yearMonth);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                shadowNotCalculatedMap.put(resultSet.getString("cs_id"), resultSet.getString("cs_contract_no"));
                //shadowNotCalculatedList.add(resultSet.getString("cs_contract_no"));
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
            }
        }
        // return shadowNotCalculatedList;
        return shadowNotCalculatedMap;
    }

    private boolean checkContractAlreadyExists(String contractNo, String yearMonth) {
        boolean isExists = false;

        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {

            String sql = "Select shadow_cs_contract_no from gcsm_shadow_revenue where shadow_cs_contract_no=? and shadow_year_month=?";

            preparedStatement = currentConnection.prepareStatement(sql);
            preparedStatement.setString(1, contractNo);
            preparedStatement.setString(2, yearMonth);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                isExists = true;
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
            }

        }
        return isExists;
    }

    private String getShadowRevenueBasis(String contractNo) {
        String basis = "";
        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {

            String sql = "Select product_shadow_basis from gcsm_product where product_id in (Select cs_product from gcsm_cross_selling_details where cs_contract_no=?)";

            preparedStatement = currentConnection.prepareStatement(sql);
            preparedStatement.setString(1, contractNo);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                basis = resultSet.getString("product_shadow_basis");
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
            }

        }
        return basis;
    }

    private double getFeeAmount(String contractNo) {
        double feeAmount = 0;
        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {

            String sql = "Select cs_fee from gcsm_cross_selling_details where cs_contract_no=? order by cs_id desc limit 1";

            preparedStatement = currentConnection.prepareStatement(sql);
            preparedStatement.setString(1, contractNo);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                feeAmount = resultSet.getDouble("cs_fee");
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
            }

        }
        return feeAmount;
    }

    private double getNIIAmountForCrossSelling(String contractNo, String yearMonth) {
        String year = yearMonth.substring(0, 4);
        int month = Integer.parseInt(yearMonth.substring(4, 6));

        String period = "";

        for (int i = month; i > 0; i--) {
            String monthToPut = i < 10 ? "0" + i : "" + i;
            period += "'" + year + monthToPut + "',";
        }

        period = period.substring(0, period.length() - 1);

        SQLServerDatabaseConnection sqlserver_databaseConnection = SQLServerDatabaseConnection.getInstance();;
        Connection sqlserver_currentConnection = sqlserver_databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        double NIIAmount = 0;
        try {
            if (!sqlserver_databaseConnection.start_Connection(sqlserver_currentConnection)) {

            } else {
                String sql = "select sum(NII_AMOUNT) as NII_AMOUNT from PROFITABILITY_MAS where CON_REF_NO=? and UP_DT_KY in (" + period + ")";
                preparedStatement = sqlserver_currentConnection.prepareStatement(sql);
                preparedStatement.setString(1, contractNo);

                resultSet = preparedStatement.executeQuery();
                while (resultSet.next()) {
                    NIIAmount = resultSet.getDouble("NII_AMOUNT");
                }
            }
            sqlserver_databaseConnection.end_Connection(sqlserver_currentConnection);

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (sqlserver_currentConnection != null) {
                    sqlserver_currentConnection.close();
                }
            } catch (Exception e) {
                log.error(e.getMessage());

            }

        }
        return NIIAmount;
    }

    private double getAnnualFee(String contractNo) {
        double annualFee = 0;
        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {

            String sql = "select product_annual_fee from gcsm_product, gcsm_cross_selling_details where product_id=cs_product and cs_contract_no=? order by cs_id desc limit 1";

            preparedStatement = currentConnection.prepareStatement(sql);
            preparedStatement.setString(1, contractNo);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                annualFee = resultSet.getDouble("product_annual_fee");
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
            }

        }
        return annualFee;
    }

    @Override
    public ResponceHandler verifyShadowRevenueData(JSONObject jasonobj, int verifyReject) {
        responceHandler = new ResponceHandler();
        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        JSONObjects jsonObejcts = new JSONObjects();
        ShadowRevenueModel newShadowRevenueModel;

        //Audit Trail
        Auditing auditing = new Auditing();
        String auditType = "UPDATE";
        String related_table = "gcsm_shadow_revenue";
        String record_pk = "";
        String old_value = "";

        try {
            newShadowRevenueModel = jsonObejcts.convertShadowRevenueModelToJSON(jasonobj.toString());
            String shadowRevenueRecordUpdate
                    = "UPDATE gcsm_shadow_revenue "
                    + "set shadow_revenue_status=" + verifyReject + ", "
                    + "shadow_reject_reason=?, " //1
                    + "shadow_modified_user=?, " //2
                    + "shadow_modified_timestamp=now() "
                    + "where shadow_revenue_id=?";              //3

            preparedStatement = currentConnection.prepareStatement(shadowRevenueRecordUpdate);
            preparedStatement.setString(1, newShadowRevenueModel.getShadow_reject_reason());
            preparedStatement.setString(2, jasonobj.get("user_username").toString());
            preparedStatement.setInt(3, newShadowRevenueModel.getShadow_revenue_id());

            //Audit Trail 
            record_pk = "" + newShadowRevenueModel.getShadow_revenue_id();
            old_value = auditing.getAllRecords(record_pk, related_table).toString();

            if (preparedStatement.executeUpdate() <= 0) {

                responceHandler.setResponceModule("verify_Shadow_Revenue_Details");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");

            }

            responceHandler.setResponceModule("verify_Shadow_Revenue_Details");
            responceHandler.setResponceType("success");
            responceHandler.setResponceCode("0000");
            responceHandler.setResponceDescription((verifyReject == 1) ? "Succefully Approved" : (verifyReject == -1) ? "Successfully Rejected" : "");

            if (!databaseConnection.end_Connection(currentConnection)) {

                responceHandler.setResponceModule("verify_Shadow_Revenue_Details");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("Uh oh! An error occurred, database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }

            //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            auditing.saveAuditRecord(jasonobj.get("user_username").toString(), related_table, auditType, record_pk, old_value, new_value);

        } catch (SQLException ex) {
            log.error(ex.getMessage());

        } catch (Exception ex) {
            log.error(ex.getMessage());
        } finally {

            try {

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("verify_shadowRevenue_Details");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }
        }
        return responceHandler;
    }

    private double getOtherAmount(String contractNo, String yearMonth) {
        double annualFee = 0;
        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {

            String sql = "select other_amount_value from gcsm_shadow_other_amounts where other_amount_contractNo=? and other_amount_yearmonth=?";

            preparedStatement = currentConnection.prepareStatement(sql);
            preparedStatement.setString(1, contractNo);
            preparedStatement.setString(2, yearMonth);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                annualFee = resultSet.getDouble("other_amount_value");
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
            }

        }
        return annualFee;
    }

    @Override
    public JSONArray otherShadowRevenueBasisDetails(JSONObject jasonobj) {
        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        JSONObject m_jsObj;
        jsArr = new JSONArray();

        try {
            if (!databaseConnection.start_Connection(currentConnection)) {

            } else {
                String sql = "select * from gcsm_shadow_other_amounts order by configured_timestamp desc";
                preparedStatement = currentConnection.prepareStatement(sql);
                resultSet = preparedStatement.executeQuery();
                int i = 0;
                while (resultSet.next()) {
                    m_jsObj = new JSONObject();
                    m_jsObj.put("other_amount_id", resultSet.getInt("other_amount_id"));
                    m_jsObj.put("other_amount_contractNo", resultSet.getString("other_amount_contractNo"));
                    m_jsObj.put("other_amount_value", String.format("%.2f", resultSet.getDouble("other_amount_value")));
                    m_jsObj.put("other_amount_yearmonth", resultSet.getString("other_amount_yearmonth"));
                    m_jsObj.put("configured_user", resultSet.getString("configured_user"));
                    m_jsObj.put("configured_timestamp", resultSet.getString("configured_timestamp"));
                    jsArr.put(i, m_jsObj);
                    i++;
                }
            }
            databaseConnection.end_Connection(currentConnection);

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (currentConnection != null) {
                    currentConnection.close();
                }
            } catch (Exception e) {
                log.error(e.getMessage());
            }

        }

        return jsArr;
    }

    @Override
    public ResponceHandler insertUpdateOtherAmount(String contractNo, String yearMonth, double amount, String username) {

        int otherAmountIdIfExist = checkForExistingOtherAmount(contractNo, yearMonth);

        if (otherAmountIdIfExist > 0) {
            responceHandler = updateOtherAmount(otherAmountIdIfExist, amount, username);
        } else {
            responceHandler = insertOtherAmount(contractNo, amount, yearMonth, username);
        }

        return responceHandler;
    }

    private int checkForExistingOtherAmount(String contractNo, String yearMonth) {
        int otherAmountId = 0;

        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            if (!databaseConnection.start_Connection(currentConnection)) {

            } else {
                String sql = "SELECT other_amount_id FROM gcsm_shadow_other_amounts where other_amount_contractNo=? and other_amount_yearmonth=?";
                preparedStatement = currentConnection.prepareStatement(sql);
                preparedStatement.setString(1, contractNo);
                preparedStatement.setString(2, yearMonth);
                resultSet = preparedStatement.executeQuery();

                while (resultSet.next()) {
                    otherAmountId = resultSet.getInt("other_amount_id");
                }
            }

            databaseConnection.end_Connection(currentConnection);

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (currentConnection != null) {
                    currentConnection.close();
                }
            } catch (Exception e) {
                log.error(e.getMessage());
            }

        }

        return otherAmountId;
    }

    private ResponceHandler updateOtherAmount(int otherAmountId, double amount, String username) {
        responceHandler = new ResponceHandler();
        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        JSONObjects jsonObejcts = new JSONObjects();

        //Audit Trail
        Auditing auditing = new Auditing();
        String auditType = "UPDATE";
        String related_table = "gcsm_shadow_other_amounts";
        String record_pk = "";
        String old_value = "";

        try {

            String shadowOtherAmountsUpdateSuery
                    = "UPDATE gcsm_shadow_other_amounts "
                    + "set other_amount_value=?, " //1  
                    + "configured_user=?, " //2
                    + "configured_timestamp=now() " //2
                    + "where other_amount_id=?";        //3

            preparedStatement = currentConnection.prepareStatement(shadowOtherAmountsUpdateSuery);
            preparedStatement.setDouble(1, amount);
            preparedStatement.setString(2, username);
            preparedStatement.setInt(3, otherAmountId);

            //Audit Trail 
            record_pk = "" + otherAmountId;
            old_value = auditing.getAllRecords(record_pk, related_table).toString();

            if (preparedStatement.executeUpdate() <= 0) {

                responceHandler.setResponceModule("modifyOtherAmount");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");

            }

            responceHandler.setResponceModule("modifyOtherAmount");
            responceHandler.setResponceType("success");
            responceHandler.setResponceCode("0000");
            responceHandler.setResponceDescription("Success");

            if (!databaseConnection.end_Connection(currentConnection)) {

                responceHandler.setResponceModule("modifyOtherAmount");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("Uh oh! An error occurred, database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }

            //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            auditing.saveAuditRecord(username, related_table, auditType, record_pk, old_value, new_value);

        } catch (SQLException ex) {
           log.error(ex.getMessage());

        } catch (Exception ex) {
            log.error(ex.getMessage());
        } finally {

            try {

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("modifyOtherAmount");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in modifyOtherAmount");

            }
        }
        return responceHandler;
    }

    private ResponceHandler insertOtherAmount(String contractNo, double amount, String yearMonth, String username) {
        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        //Audit Trail        
        Auditing auditing = new Auditing();
        String auditType = "INSERT";
        String related_table = "gcsm_shadow_other_amounts";
        String record_pk = "";
        String old_value = "##Empty##";

        try {

            if (!databaseConnection.start_Connection(currentConnection)) {

            } else {
                String sql
                        = "INSERT INTO gcsm_shadow_other_amounts("
                        + "other_amount_contractNo," //1
                        + "other_amount_value," //2
                        + "other_amount_yearmonth," //3
                        + "configured_user," //4
                        + "configured_timestamp)"
                        + " VALUES(?,?,?,?,now())";

                preparedStatement = currentConnection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                preparedStatement.setString(1, contractNo);
                preparedStatement.setDouble(2, amount);
                preparedStatement.setString(3, yearMonth);
                preparedStatement.setString(4, username);
                int executeUpdate = preparedStatement.executeUpdate();
                resultSet = preparedStatement.getGeneratedKeys();
            }

            while (resultSet.next()) {
                //Audit Trail
                record_pk = "" + (resultSet.getInt(1));
            }

            if (!databaseConnection.end_Connection(currentConnection)) {

                log.error("Uh oh! An error occurred, database connection terminating problem.");

            }

            //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            auditing.saveAuditRecord(username, related_table, auditType, record_pk, old_value, new_value);

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
            }
        }

        return responceHandler;
    }

    @Override
    public JSONArray getOtherContractValues(JSONObject data) {
        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        JSONObject m_jsObj;
        jsArr = new JSONArray();

        try {
            if (!databaseConnection.start_Connection(currentConnection)) {

            } else {
                String sql = "select * from gcsm_other_contract_values order by configured_timestamp desc";
                preparedStatement = currentConnection.prepareStatement(sql);
                resultSet = preparedStatement.executeQuery();
                int i = 0;
                while (resultSet.next()) {
                    m_jsObj = new JSONObject();
                    m_jsObj.put("other_contract_value_id", resultSet.getInt("other_contract_value_id"));
                    m_jsObj.put("other_contract_value_contractNo", resultSet.getString("other_contract_value_contractNo"));
                    m_jsObj.put("other_contract_value_amount", String.format("%.2f", resultSet.getDouble("other_contract_value_amount")));
                    m_jsObj.put("other_contract_value_yearmonth", resultSet.getString("other_contract_value_yearmonth"));
                    m_jsObj.put("configured_user", resultSet.getString("configured_user"));
                    m_jsObj.put("configured_timestamp", resultSet.getString("configured_timestamp"));
                    jsArr.put(i, m_jsObj);
                    i++;
                }
            }
            databaseConnection.end_Connection(currentConnection);

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (currentConnection != null) {
                    currentConnection.close();
                }
            } catch (Exception e) {
                log.error(e.getMessage());
            }

        }

        return jsArr;
    }

    @Override
    public ResponceHandler insertUpdateOtherContractValues(String contractNo, String yearMonth, double value, String username) {

        int otherContractValuesIdIfExist = checkForExistingOtherContractValues(contractNo, yearMonth);

        if (otherContractValuesIdIfExist > 0) {
            responceHandler = updateOtherContractValue(otherContractValuesIdIfExist, value, username);
        } else {
            responceHandler = insertOtherContractValue(contractNo, value, yearMonth, username);
        }

        return responceHandler;
    }

    private int checkForExistingOtherContractValues(String contractNo, String yearMonth) {
        int otherContractValuesId = 0;

        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            if (!databaseConnection.start_Connection(currentConnection)) {

            } else {
                String sql = "SELECT other_contract_value_id FROM gcsm_other_contract_values where other_contract_value_contractNo=? and other_contract_value_yearmonth=?";
                preparedStatement = currentConnection.prepareStatement(sql);
                preparedStatement.setString(1, contractNo);
                preparedStatement.setString(2, yearMonth);
                resultSet = preparedStatement.executeQuery();

                while (resultSet.next()) {
                    otherContractValuesId = resultSet.getInt("other_contract_value_id");
                }
            }

            databaseConnection.end_Connection(currentConnection);

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (currentConnection != null) {
                    currentConnection.close();
                }
            } catch (Exception e) {
                log.error(e.getMessage());
            }

        }

        return otherContractValuesId;
    }

    private ResponceHandler updateOtherContractValue(int otherContractValueID, double value, String username) {
        responceHandler = new ResponceHandler();
        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        JSONObjects jsonObejcts = new JSONObjects();

        //Audit Trail
        Auditing auditing = new Auditing();
        String auditType = "UPDATE";
        String related_table = "gcsm_other_contract_values";
        String record_pk = "";
        String old_value = "";

        try {

            String shadowOtherAmountsUpdateSuery
                    = "UPDATE gcsm_other_contract_values "
                    + "set other_contract_value_amount=?, " //1  
                    + "configured_user=?, " //2
                    + "configured_timestamp=now() " //2
                    + "where other_contract_value_id=?";        //3

            preparedStatement = currentConnection.prepareStatement(shadowOtherAmountsUpdateSuery);
            preparedStatement.setDouble(1, value);
            preparedStatement.setString(2, username);
            preparedStatement.setInt(3, otherContractValueID);

            //Audit Trail 
            record_pk = "" + otherContractValueID;
            old_value = auditing.getAllRecords(record_pk, related_table).toString();

            if (preparedStatement.executeUpdate() <= 0) {

                responceHandler.setResponceModule("modifyOtherContractvalue");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");

            }

            responceHandler.setResponceModule("modifyOtherContractvalue");
            responceHandler.setResponceType("success");
            responceHandler.setResponceCode("0000");
            responceHandler.setResponceDescription("Success");

            if (!databaseConnection.end_Connection(currentConnection)) {

                responceHandler.setResponceModule("modifyOtherContractvalue");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("Uh oh! An error occurred, database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }

            //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            auditing.saveAuditRecord(username, related_table, auditType, record_pk, old_value, new_value);

        } catch (SQLException ex) {
            ex.printStackTrace();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {

            try {

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("modifyOtherContractvalue");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in modifyOtherContractvalue");

            }
        }
        return responceHandler;
    }

    private ResponceHandler insertOtherContractValue(String contractNo, double value, String yearMonth, String username) {
        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        //Audit Trail        
        Auditing auditing = new Auditing();
        String auditType = "INSERT";
        String related_table = "gcsm_other_contract_values";
        String record_pk = "";
        String old_value = "##Empty##";

        try {

            if (!databaseConnection.start_Connection(currentConnection)) {

            } else {
                String sql
                        = "INSERT INTO gcsm_other_contract_values("
                        + "other_contract_value_contractNo," //1
                        + "other_contract_value_amount," //2
                        + "other_contract_value_yearmonth," //3
                        + "configured_user," //4
                        + "configured_timestamp)"
                        + " VALUES(?,?,?,?,now())";

                preparedStatement = currentConnection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                preparedStatement.setString(1, contractNo);
                preparedStatement.setDouble(2, value);
                preparedStatement.setString(3, yearMonth);
                preparedStatement.setString(4, username);
                int executeUpdate = preparedStatement.executeUpdate();
                resultSet = preparedStatement.getGeneratedKeys();
            }

            while (resultSet.next()) {
                //Audit Trail
                record_pk = "" + (resultSet.getInt(1));
            }

            if (!databaseConnection.end_Connection(currentConnection)) {

                log.error("Uh oh! An error occurred, database connection terminating problem.");

            }

            //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            auditing.saveAuditRecord(username, related_table, auditType, record_pk, old_value, new_value);

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
            }
        }

        return responceHandler;
    }

    private double getPortfolioValue(String contractNo, String yearMonth) {
        double portfolioValue = 0;

        String contractValueRetrievalMethod = getContractValueRetrivalMethod(contractNo);

        switch (contractValueRetrievalMethod) {
            case "Profitability System":
                portfolioValue = getPortfolioValueFromProfitabilitySystem(contractNo, yearMonth);
                break;

            case "Other Contract Values File":
                portfolioValue = getPortfolioValueFromOtherFile(contractNo, yearMonth);
                break;
        }

        return portfolioValue;
    }

    private double getPortfolioValueFromProfitabilitySystem(String contractNo, String yearMonth) {
        SQLServerDatabaseConnection sqlserver_databaseConnection = SQLServerDatabaseConnection.getInstance();;
        Connection sqlserver_currentConnection = sqlserver_databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        double portfolioValue = 0;
        try {
            if (!sqlserver_databaseConnection.start_Connection(sqlserver_currentConnection)) {

            } else {
                String sql = "select sum(PORT_AMT) as PORT_AMT from SEG_PROFITABILITY_MAS where CON_REF_NO=? and UP_DT_KY=? AND FLG_MODULE IN (2,3)";
                preparedStatement = sqlserver_currentConnection.prepareStatement(sql);
                preparedStatement.setString(1, contractNo);
                preparedStatement.setString(2, yearMonth);

                resultSet = preparedStatement.executeQuery();
                while (resultSet.next()) {
                    portfolioValue = resultSet.getDouble("PORT_AMT");
                }
            }
            sqlserver_databaseConnection.end_Connection(sqlserver_currentConnection);

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (sqlserver_currentConnection != null) {
                    sqlserver_currentConnection.close();
                }
            } catch (Exception e) {
                log.error(e.getMessage());

            }

        }
        return portfolioValue;
    }

    private String getContractValueRetrivalMethod(String contractNo) {
        String method = "";

        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            if (!databaseConnection.start_Connection(currentConnection)) {

            } else {
                String sql = "select product_contract_value_retrive_from from gcsm_product where product_id in (select cs_product from gcsm_cross_selling_details where cs_contract_no =?)";
                preparedStatement = currentConnection.prepareStatement(sql);
                preparedStatement.setString(1, contractNo);
                resultSet = preparedStatement.executeQuery();

                while (resultSet.next()) {
                    method = resultSet.getString("product_contract_value_retrive_from");
                }
            }

            databaseConnection.end_Connection(currentConnection);

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (currentConnection != null) {
                    currentConnection.close();
                }
            } catch (Exception e) {
                log.error(e.getMessage());
            }

        }

        return method;
    }

    private double getPortfolioValueFromOtherFile(String contractNo, String yearMonth) {
        double portfolioValue = 0;

        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            if (!databaseConnection.start_Connection(currentConnection)) {

            } else {
                String sql = "select other_contract_value_amount from gcsm_other_contract_values where other_contract_value_contractNo=? and other_contract_value_yearmonth=?";
                preparedStatement = currentConnection.prepareStatement(sql);
                preparedStatement.setString(1, contractNo);
                preparedStatement.setString(2, yearMonth);
                resultSet = preparedStatement.executeQuery();

                while (resultSet.next()) {
                    portfolioValue = resultSet.getDouble("other_contract_value_amount");
                }
            }

            databaseConnection.end_Connection(currentConnection);

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (currentConnection != null) {
                    currentConnection.close();
                }
            } catch (Exception e) {
                log.error(e.getMessage());
            }

        }

        return portfolioValue;
    }

    private int getCurrentShadowCalculationID() {
        int currentCalculationID = 0;

        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {

            String sql = "select shadow_calculation_status_id from gcsm_shadow_calculation_status where shdaow_calcuation_status=1";
            preparedStatement = currentConnection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                currentCalculationID = resultSet.getInt("shadow_calculation_status_id");
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (currentConnection != null) {
                    currentConnection.close();
                }
            } catch (Exception e) {
                log.error(e.getMessage());
            }

        }

        return currentCalculationID;
    }

    private void initiateOrUpdateShadowCalculationStatus(int status_id, String username) {

        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        //Audit Trail
        Auditing auditing = new Auditing();
        String auditType = "";
        String related_table = "gcsm_shadow_calculation_status";
        String record_pk = "";
        String old_value = "##Empty##";

        String query = "";

        if (status_id == 0) {
            query = "INSERT INTO gcsm_shadow_calculation_status (shdaow_calcuation_status,shadow_calculation_stareted_time) values ('1',now())";
            //Audit Trail
            auditType = "INSERT";
        } else {
            query = "UPDATE gcsm_shadow_calculation_status set shdaow_calcuation_status=2 where shadow_calculation_status_id='" + status_id + "'";

            //Audit Trail
            auditType = "UPDATE";
            old_value = auditing.getAllRecords(status_id + "", related_table).toString();
        }

        try {
            if (!databaseConnection.start_Connection(currentConnection)) {

            } else {
                preparedStatement = currentConnection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
                preparedStatement.executeUpdate();
                resultSet = preparedStatement.getGeneratedKeys();

                if (resultSet.first()) {
                    record_pk = "" + resultSet.getInt(1);
                }
                else{
                    record_pk = "" + status_id;
                }
            }

            databaseConnection.end_Connection(currentConnection);

            //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            auditing.saveAuditRecord(username, related_table, auditType, record_pk, old_value, new_value);

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (currentConnection != null) {
                    currentConnection.close();
                }
            } catch (Exception e) {
                log.error(e.getMessage());
            }

        }

    }

    @Override
    public ResponceHandler eraseShadowRevenueData(String shadowYearMonth, String username) {
        responceHandler = new ResponceHandler();
        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;

        //Audit Trail
        Auditing auditing = new Auditing();
        String auditType = "DELETE";
        String related_table = "gcsm_shadow_revenue";
        String record_pk = "Multiple";
        String old_value = getshadowErasingRecords(shadowYearMonth);
        try {

            String shadowRevenueRecordUpdate
                    = "delete from gcsm_shadow_revenue where shadow_year_month='" + shadowYearMonth + "'";              //3

            preparedStatement = currentConnection.prepareStatement(shadowRevenueRecordUpdate);

            if (preparedStatement.executeUpdate() <= 0) {

                responceHandler.setResponceModule("Erase Shadow Revenue");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");

            }

            responceHandler.setResponceModule("Erase Shadow Revenue");
            responceHandler.setResponceType("success");
            responceHandler.setResponceCode("0000");
            responceHandler.setResponceDescription("Successfuly Erased Shadow Revenue Records");

            if (!databaseConnection.end_Connection(currentConnection)) {

                responceHandler.setResponceModule("Erase Shadow Revenue");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("Uh oh! An error occurred, database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }

            //Audit Trail
            String new_value = "##Empty##";
            auditing.saveAuditRecord(username, related_table, auditType, record_pk, old_value, new_value);
        } catch (SQLException ex) {
            log.error(ex.getMessage());

        } catch (Exception ex) {
            log.error(ex.getMessage());
        } finally {

            try {

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("Erase Shadow Revenue");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in erasing shadow revenue");

            }
        }
        return responceHandler;
    }

    @Override
    public boolean checkIsValidYearMonth(String yearMonth) {
        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        boolean isValidYearMonth = true;

        JSONObject m_jsObj;
        jsArr = new JSONArray();
        try {
            if (!databaseConnection.start_Connection(currentConnection)) {

            } else {
                String sql = "select distinct shadow_year_month from gcsm_shadow_revenue where shadow_year_month =?";
                preparedStatement = currentConnection.prepareStatement(sql);
                preparedStatement.setString(1, yearMonth);
                resultSet = preparedStatement.executeQuery();
                if (resultSet.first()) {
                    m_jsObj = new JSONObject();
                    isValidYearMonth = false;
                }
            }
            databaseConnection.end_Connection(currentConnection);

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (currentConnection != null) {
                    currentConnection.close();
                }
            } catch (Exception e) {
                log.error(e.getMessage());
            }

        }

        return isValidYearMonth;
    }

    @Override
    public boolean checkIsSahdowCalculationRunning() {
        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        boolean isNotRunning = true;

        JSONObject m_jsObj;
        jsArr = new JSONArray();
        try {
            if (!databaseConnection.start_Connection(currentConnection)) {

            } else {
                String sql = "select shadow_calculation_status_id from gcsm_shadow_calculation_status where shdaow_calcuation_status=1";
                preparedStatement = currentConnection.prepareStatement(sql);
                resultSet = preparedStatement.executeQuery();
                if (resultSet.first()) {
                    m_jsObj = new JSONObject();
                    isNotRunning = false;
                }
            }
            databaseConnection.end_Connection(currentConnection);

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (currentConnection != null) {
                    currentConnection.close();
                }
            } catch (Exception e) {
                log.error(e.getMessage());
            }

        }

        return isNotRunning;
    }

    private String getshadowErasingRecords(String yearMonth) {

        StringBuilder shadowErasingRecords = new StringBuilder("");

        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {

            String sql = "select * from gcsm_shadow_revenue where shadow_year_month=?";
            preparedStatement = currentConnection.prepareStatement(sql);
            preparedStatement.setString(1, yearMonth);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                StringBuilder recordDetails = new StringBuilder("{");

                for (int i = 0; i < 16; i++) {
                    recordDetails.append(resultSet.getString(i + 1)).append(",");
                }

                recordDetails.deleteCharAt(recordDetails.lastIndexOf(","));

                recordDetails.append("}");

                shadowErasingRecords.append(recordDetails).append(",");

            }

            shadowErasingRecords.deleteCharAt(shadowErasingRecords.lastIndexOf(","));

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (currentConnection != null) {
                    currentConnection.close();
                }
            } catch (Exception e) {
                log.error(e.getMessage());
            }
        }
        return shadowErasingRecords.toString();
    }
}
