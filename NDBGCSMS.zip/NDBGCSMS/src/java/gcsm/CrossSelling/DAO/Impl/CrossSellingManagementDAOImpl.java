/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.CrossSelling.DAO.Impl;

import gcsm.CrossSelling.DAO.CrossSellingManagementDAO;
import gcsm.CrossSelling.Model.CrossSellingManagementModel;
import gcsm.Utitlities.Impl.Auditing;
import gcsm.Utitlities.Impl.DatabaseConnection;
import gcsm.Utitlities.Impl.JSONObjects;
import gcsm.Utitlities.Model.ResponceHandler;
import gcsm.Utitlities.Model.RoleTypes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Janaka_5977
 */
public class CrossSellingManagementDAOImpl implements CrossSellingManagementDAO {

    static Logger log = LogManager.getLogger(CrossSellingManagementDAOImpl.class.getName());
    private ResponceHandler responceHandler;
    static DatabaseConnection databaseConnection;
    static Connection currentConnection = null;
    private PreparedStatement preparedStatement = null;
    private ResultSet resultSet = null;
    private JSONObjects jsonObejcts;
    private JSONArray jsArr;

    @Override
    public ResponceHandler saveCrossSellingData(JSONObject jasonobj) {

        responceHandler = new ResponceHandler();
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        jsonObejcts = new JSONObjects();
        CrossSellingManagementModel newCrossSellingManagementModel;

        //Audit Trail        
        Auditing auditing = new Auditing();
        String auditType = "INSERT";
        String related_table = "gcsm_cross_selling_details";
        String record_pk = "";
        String old_value = "##Empty##";

        try {
            newCrossSellingManagementModel = jsonObejcts.convertCrossSellingManagementModelToJSON(jasonobj.toString());
            if (!databaseConnection.start_Connection(currentConnection)) {

                responceHandler.setResponceModule("saveCrossSelling");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("00001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection establishing problem.");

                log.error("Uh oh! An error occurred, database connection establishing problem.");
                throw new Exception("An error occurred, database connection establishing problem.");
            } else {
                String queryInsertCrossSellingDetails
                        = "INSERT INTO gcsm_cross_selling_details("
                        + "cs_own_company," //1
                        + "cs_product_owner," //2
                        + "cs_product," //3
                        + "cs_product_status," //4
                        + "cs_customer_name," //5
                        + "cs_customer_nic," //6
                        + "cs_customer_contactNo," //7
                        + "cs_cid," //8
                        + "cs_fee," //9
                        + "cs_emp_id," //10
                        + "cs_employee_name," //11
                        + "cs_units_sold_by," //12
                        + "cs_date," //13
                        + "cs_contract_no," //14
                        + "cs_comment," //15
                        + "cs_status," //16
                        + "cs_setup_user," //17
                        + "cs_modified_user," //18
                        + "cs_setup_timestamp,"
                        + "cs_modified_timestamp)"
                        + " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,now(),now())";

                preparedStatement = currentConnection.prepareStatement(queryInsertCrossSellingDetails, Statement.RETURN_GENERATED_KEYS);
                preparedStatement.setInt(1, newCrossSellingManagementModel.getCs_own_company());
                preparedStatement.setInt(2, newCrossSellingManagementModel.getCs_product_owner());
                preparedStatement.setInt(3, newCrossSellingManagementModel.getCs_product());
                preparedStatement.setString(4, newCrossSellingManagementModel.getCs_product_status());
                preparedStatement.setString(5, newCrossSellingManagementModel.getCs_customer_name());
                preparedStatement.setString(6, newCrossSellingManagementModel.getCs_customer_nic());
                preparedStatement.setString(7, newCrossSellingManagementModel.getCs_customer_contactNo());
                preparedStatement.setString(8, newCrossSellingManagementModel.getCs_cid());
                preparedStatement.setDouble(9, newCrossSellingManagementModel.getCs_fee());
                preparedStatement.setString(10, newCrossSellingManagementModel.getCs_emp_id());
                preparedStatement.setString(11, newCrossSellingManagementModel.getCs_employee_name());
                preparedStatement.setString(12, newCrossSellingManagementModel.getCs_units_sold_by());
                preparedStatement.setString(13, newCrossSellingManagementModel.getCs_date());
                preparedStatement.setString(14, newCrossSellingManagementModel.getCs_contract_no());
                preparedStatement.setString(15, newCrossSellingManagementModel.getCs_comment().replace("##", "%"));
                preparedStatement.setInt(16, 0);
                preparedStatement.setString(17, jasonobj.get("user_username").toString());
                preparedStatement.setString(18, jasonobj.get("user_username").toString());
                int executeUpdate = preparedStatement.executeUpdate();
                resultSet = preparedStatement.getGeneratedKeys();
            }

            while (resultSet.next()) {
                //Audit Trail
                record_pk = "" + (resultSet.getInt(1));

            }

            responceHandler.setResponceModule("saveCrossSelling");
            responceHandler.setResponceType("success");
            responceHandler.setResponceCode("0000");
            responceHandler.setResponceDescription("Awesome! You were successful.");

            if (!databaseConnection.end_Connection(currentConnection)) {

                responceHandler.setResponceModule("saveCrossSelling");
                responceHandler.setResponceType("error");;
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("Uh oh! An error occurred, database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }

            //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            auditing.saveAuditRecord(jasonobj.get("user_username").toString(), related_table, auditType, record_pk, old_value, new_value);

        } catch (Exception e) {
            log.error(e.getMessage());

            responceHandler.setResponceModule("saveCrossSelling");
            responceHandler.setResponceType("error");
            responceHandler.setResponceCode("00002");
            responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to insert this record.\n" + e);

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("saveCrossSelling");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return responceHandler;
    }

    @Override
    public JSONArray viewCrossSellingData(JSONObject jasonobj) {
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();
        String username = jasonobj.get("user_username").toString();
        String roleType = jasonobj.get("session_role_type").toString();
        /*  cs_status 
         0   ->  Pending Approval from Line Head, 
         1   ->  Pending Approval from Product Owner, 
         -1  ->  Rejected by Line Head, 
         -2  ->  Rejected by Product Owner, 
         2   ->  Revision Required by Line Head, 
         3   ->  Revision Required by Product Owner, 
         4   ->  Revision Required by Finance Admin, 
         5   ->  Approved
         */
        try {
            String queryViewCrossSellingDetails = "";
            if (roleType.equals(RoleTypes.INPUTER)) {
                queryViewCrossSellingDetails = "SELECT cs_id, csowner.bl_name as cs_own_company, product_name as cs_product,cs_product_status, prodowner.bl_name as cs_product_owner, cs_customer_name, cs_customer_nic, cs_customer_contactNo, cs_cid, cs_fee, cs_emp_id, cs_employee_name, cs_units_sold_by, cs_date, cs_contract_no, cs_comment, cs_status, cs_setup_user, concat(user_name_first,' ',user_name_last) as full_name, cs_setup_timestamp, cs_modified_user, cs_modified_timestamp, cs_reject_reason FROM gcsm_cross_selling_details, gcsm_product, gcsm_businessline as csowner, gcsm_businessline as prodowner,gcsm_user WHERE cs_product=product_id and cs_setup_user=user_username and cs_own_company=csowner.bl_id and cs_product_owner=prodowner.bl_id and cs_setup_user='" + username + "'  ORDER BY cs_modified_timestamp DESC;";
            } else if (roleType.equals(RoleTypes.AUTHORIZER)) {
                queryViewCrossSellingDetails = "SELECT cs_id, csowner.bl_name as cs_own_company, product_name as cs_product,cs_product_status, prodowner.bl_name as cs_product_owner, cs_customer_name, cs_customer_nic, cs_customer_contactNo, cs_cid, cs_fee, cs_emp_id, cs_employee_name, cs_units_sold_by, cs_date, cs_contract_no, cs_comment, cs_status, cs_setup_user, concat(user_name_first,' ',user_name_last) as full_name, cs_setup_timestamp, cs_modified_user, cs_modified_timestamp, cs_reject_reason FROM gcsm_cross_selling_details, gcsm_product, gcsm_businessline as csowner, gcsm_businessline as prodowner,gcsm_user WHERE cs_product=product_id and cs_setup_user=user_username and cs_own_company=csowner.bl_id and cs_product_owner=prodowner.bl_id and cs_setup_user in (select user_username from gcsm_user where user_businessline in (Select user_businessline from gcsm_user where user_username='" + username + "')) ORDER BY cs_modified_timestamp DESC";
            } else if (roleType.equals(RoleTypes.FINANCE_ADMINISTRATOR)) {
                queryViewCrossSellingDetails = "SELECT cs_id, csowner.bl_name as cs_own_company, product_name as cs_product,cs_product_status, prodowner.bl_name as cs_product_owner, cs_customer_name, cs_customer_nic, cs_customer_contactNo, cs_cid, cs_fee, cs_emp_id, cs_employee_name, cs_units_sold_by, cs_date, cs_contract_no, cs_comment, cs_status, cs_setup_user, concat(user_name_first,' ',user_name_last) as full_name, cs_setup_timestamp, cs_modified_user, cs_modified_timestamp, cs_reject_reason FROM gcsm_cross_selling_details, gcsm_product, gcsm_businessline as csowner, gcsm_businessline as prodowner,gcsm_user WHERE cs_product=product_id and cs_setup_user=user_username and cs_own_company=csowner.bl_id and cs_product_owner=prodowner.bl_id and cs_setup_user=user_username and cs_status in (5) ORDER BY cs_modified_timestamp DESC";
            } else if (roleType.equals(RoleTypes.OTHER_LINE_ADMINISTRATOR)) {
                queryViewCrossSellingDetails = "SELECT \n"
                        + "	cs_id, \n"
                        + "    csowner.bl_name as cs_own_company, \n"
                        + "    product_name as cs_product,\n"
                        + "    cs_product_status, \n"
                        + "    prodowner.bl_name as cs_product_owner, \n"
                        + "    cs_customer_name, \n"
                        + "    cs_customer_nic, \n"
                        + "    cs_customer_contactNo, \n"
                        + "    cs_cid, \n"
                        + "    cs_fee, \n"
                        + "    cs_emp_id, \n"
                        + "    cs_employee_name, \n"
                        + "    cs_units_sold_by, \n"
                        + "    cs_date, \n"
                        + "    cs_contract_no, \n"
                        + "    cs_comment, \n"
                        + "    cs_status, \n"
                        + "    cs_setup_user,\n"
                        + "    concat(user_name_first,' ',user_name_last) as full_name,  \n"
                        + "    cs_setup_timestamp, \n"
                        + "    cs_modified_user, \n"
                        + "    cs_modified_timestamp, \n"
                        + "    cs_reject_reason \n"
                        + "FROM \n"
                        + "	gcsm_cross_selling_details, \n"
                        + "    gcsm_product, \n"
                        + "    gcsm_businessline as csowner, \n"
                        + "    gcsm_businessline as prodowner,\n"
                        + "    gcsm_user \n"
                        + "WHERE \n"
                        + "	cs_product=product_id and \n"
                        + "     cs_setup_user=user_username and \n"
                        + "    cs_own_company=csowner.bl_id and \n"
                        + "    cs_product_owner=prodowner.bl_id and \n"
                        + "    cs_own_company in (\n"
                        + "	select \n"
                        + "		bl_id \n"
                        + "	from \n"
                        + "		gcsm_businessline \n"
                        + "	where \n"
                        + "		bl_head in (\n"
                        + "        select \n"
                        + "			bl_name \n"
                        + "		from \n"
                        + "			gcsm_businessline \n"
                        + "		where \n"
                        + "			bl_id in (\n"
                        + "            Select \n"
                        + "				user_businessline \n"
                        + "			from \n"
                        + "				gcsm_user \n"
                        + "			where \n"
                        + "				user_username='"+username+"'\n"
                        + "			)\n"
                        + "        )\n"
                        + "	) \n"
                        + "ORDER BY \n"
                        + "	cs_modified_timestamp DESC";
            }

            preparedStatement = currentConnection.prepareStatement(queryViewCrossSellingDetails);
            resultSet = preparedStatement.executeQuery();
            int i = 0;
            while (resultSet.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("cs_id", resultSet.getInt("cs_id"));
                m_jsObj.put("cs_own_company", resultSet.getString("cs_own_company"));
                m_jsObj.put("cs_product_owner", resultSet.getString("cs_product_owner"));
                m_jsObj.put("cs_product", resultSet.getString("cs_product"));
                m_jsObj.put("cs_product_status", resultSet.getString("cs_product_status"));
                m_jsObj.put("cs_customer_name", resultSet.getString("cs_customer_name"));
                m_jsObj.put("cs_customer_contactNo", resultSet.getString("cs_customer_contactNo"));
                m_jsObj.put("cs_customer_nic", resultSet.getString("cs_customer_nic"));
                m_jsObj.put("cs_cid", resultSet.getString("cs_cid"));
                m_jsObj.put("cs_fee", resultSet.getDouble("cs_fee"));
                m_jsObj.put("cs_emp_id", resultSet.getString("cs_emp_id"));
                m_jsObj.put("cs_employee_name", resultSet.getString("cs_employee_name"));
                m_jsObj.put("cs_units_sold_by", resultSet.getString("cs_units_sold_by"));
                m_jsObj.put("cs_date", resultSet.getString("cs_date"));
                m_jsObj.put("isShadowCalculated", getWhetherShadowCalculated(resultSet.getString("cs_date")));
                m_jsObj.put("cs_contract_no", resultSet.getString("cs_contract_no"));
                m_jsObj.put("cs_comment", resultSet.getString("cs_comment"));
                m_jsObj.put("cs_reject_reason", resultSet.getString("cs_reject_reason"));
                m_jsObj.put("cs_status", resultSet.getInt("cs_status"));
                m_jsObj.put("cs_setup_user", resultSet.getString("cs_setup_user"));
                m_jsObj.put("full_name", resultSet.getString("full_name"));
                m_jsObj.put("cs_setup_timestamp", resultSet.getString("cs_setup_timestamp"));
                m_jsObj.put("cs_modified_user", resultSet.getString("cs_modified_user"));
                m_jsObj.put("cs_modified_timestamp", resultSet.getString("cs_modified_timestamp"));
                m_jsObj.put("cs_same_user_created", (username.equals(resultSet.getString("cs_setup_user")) ? 1 : 0));
                jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("View_crossSellingData");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return jsArr;

    }

    @Override
    public JSONArray getInfoCrossSelling(JSONObject jasonobj) {
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();
        try {

            String queryViewCrossSellingDetails
                    = "SELECT gcsm_cross_selling_details.*,gcsm_product.product_name "
                    + "FROM gcsm_cross_selling_details,gcsm_product "
                    + "WHERE gcsm_cross_selling_details.cs_product=gcsm_product.product_id AND "
                    + "cs_id=" + jasonobj.getString("cs_id") + "";
            preparedStatement = currentConnection.prepareStatement(queryViewCrossSellingDetails);
            resultSet = preparedStatement.executeQuery();

            int i = 0;
            while (resultSet.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("cs_id", resultSet.getInt("cs_id"));
                m_jsObj.put("cs_own_company", resultSet.getInt("cs_own_company"));
                m_jsObj.put("cs_product_owner", resultSet.getInt("cs_product_owner"));
                m_jsObj.put("cs_product", resultSet.getInt("cs_product"));
                m_jsObj.put("cs_product_status", resultSet.getString("cs_product_status"));
                m_jsObj.put("cs_customer_name", resultSet.getString("cs_customer_name"));
                m_jsObj.put("cs_customer_contactNo", resultSet.getString("cs_customer_contactNo"));
                m_jsObj.put("cs_customer_nic", resultSet.getString("cs_customer_nic"));
                m_jsObj.put("cs_cid", resultSet.getString("cs_cid"));
                m_jsObj.put("cs_fee", resultSet.getDouble("cs_fee"));
                m_jsObj.put("cs_emp_id", resultSet.getString("cs_emp_id"));
                m_jsObj.put("cs_employee_name", resultSet.getString("cs_employee_name"));
                m_jsObj.put("cs_units_sold_by", resultSet.getString("cs_units_sold_by"));
                m_jsObj.put("cs_date", resultSet.getString("cs_date"));
                m_jsObj.put("cs_contract_no", resultSet.getString("cs_contract_no"));
                m_jsObj.put("cs_comment", resultSet.getString("cs_comment"));
                m_jsObj.put("cs_status", resultSet.getInt("cs_status"));
                m_jsObj.put("cs_setup_user", resultSet.getString("cs_setup_user"));
                m_jsObj.put("cs_setup_timestamp", resultSet.getString("cs_setup_timestamp"));
                m_jsObj.put("cs_modified_user", resultSet.getString("cs_modified_user"));
                m_jsObj.put("cs_modified_timestamp", resultSet.getString("cs_modified_timestamp"));
                m_jsObj.put("product_name", resultSet.getString("product_name"));
                jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("View_crossSellingData");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return jsArr;
    }

    @Override
    public ResponceHandler updateCrossSellingData(JSONObject jasonobj) {
        responceHandler = new ResponceHandler();
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        jsonObejcts = new JSONObjects();
        CrossSellingManagementModel newCrossSellingManagementModel;

        try {
            newCrossSellingManagementModel = jsonObejcts.convertCrossSellingManagementModelToJSON(jasonobj.toString());
            String crossSellingRecordAvailable = "SELECT * FROM gcsm_cross_selling_details WHERE cs_id=?";
            if (!databaseConnection.start_Connection(currentConnection)) {

                responceHandler.setResponceModule("saveCrossSelling");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("00001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection establishing problem.");

                log.error("Uh oh! An error occurred, database connection establishing problem.");
                throw new Exception("An error occurred, database connection establishing problem.");
            }

            preparedStatement = currentConnection.prepareStatement(crossSellingRecordAvailable);
            preparedStatement.setInt(1, newCrossSellingManagementModel.getCs_id());

            resultSet = preparedStatement.executeQuery();

            //Audit Trail
            Auditing auditing = new Auditing();
            String auditType = "UPDATE";
            String related_table = "gcsm_cross_selling_details";
            String record_pk = "";
            String old_value = "";

            if (resultSet.next()) {
                String crossSellingRecordUpdate
                        = "UPDATE gcsm_cross_selling_details "
                        + "set cs_own_company=?, " //1
                        + "cs_product_owner=?, " //2
                        + "cs_product=?, " //3
                        + "cs_product_status=?, " //4
                        + "cs_customer_name=?, " //5
                        + "cs_customer_nic=?, " //6
                        + "cs_customer_contactNo=?, " //7
                        + "cs_cid=?, " //8
                        + "cs_fee=?, " //9
                        + "cs_emp_id=?," //10
                        + "cs_employee_name=?, " //11
                        + "cs_units_sold_by=?, " //12
                        + "cs_date=?, " //13
                        + "cs_contract_no=?, " //14
                        + "cs_comment=?, " //15
                        + "cs_status=?, " //16
                        + "cs_modified_user=?, " //17
                        + "cs_modified_timestamp=now() "
                        + "where cs_id=?";              //18

                preparedStatement = currentConnection.prepareStatement(crossSellingRecordUpdate);
                preparedStatement.setInt(1, newCrossSellingManagementModel.getCs_own_company());
                preparedStatement.setInt(2, newCrossSellingManagementModel.getCs_product_owner());
                preparedStatement.setInt(3, newCrossSellingManagementModel.getCs_product());
                preparedStatement.setString(4, newCrossSellingManagementModel.getCs_product_status());
                preparedStatement.setString(5, newCrossSellingManagementModel.getCs_customer_name());
                preparedStatement.setString(6, newCrossSellingManagementModel.getCs_customer_nic());
                preparedStatement.setString(7, newCrossSellingManagementModel.getCs_customer_contactNo());
                preparedStatement.setString(8, newCrossSellingManagementModel.getCs_cid());
                preparedStatement.setDouble(9, newCrossSellingManagementModel.getCs_fee());
                preparedStatement.setString(10, newCrossSellingManagementModel.getCs_emp_id());
                preparedStatement.setString(11, newCrossSellingManagementModel.getCs_employee_name());
                preparedStatement.setString(12, newCrossSellingManagementModel.getCs_units_sold_by());
                preparedStatement.setString(13, newCrossSellingManagementModel.getCs_date());
                preparedStatement.setString(14, newCrossSellingManagementModel.getCs_contract_no());
                preparedStatement.setString(15, newCrossSellingManagementModel.getCs_comment().replace("##", "%"));
                preparedStatement.setInt(16, 0);
                preparedStatement.setString(17, jasonobj.get("user_username").toString());
                preparedStatement.setInt(18, newCrossSellingManagementModel.getCs_id());

                //Audit Trail 
                record_pk = "" + newCrossSellingManagementModel.getCs_id();
                old_value = auditing.getAllRecords(record_pk, related_table).toString();

                if (preparedStatement.executeUpdate() <= 0) {

                    responceHandler.setResponceModule("update_Cross_Selling_Details");
                    responceHandler.setResponceType("error");
                    responceHandler.setResponceCode("0001");
                    responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");

                }

                responceHandler.setResponceModule("update_Cross_Selling_Details");
                responceHandler.setResponceType("success");
                responceHandler.setResponceCode("0000");
                responceHandler.setResponceDescription("Awesome! You were successful.");

            }
            if (!databaseConnection.end_Connection(currentConnection)) {

                responceHandler.setResponceModule("update_Cross_Selling_Details");
                responceHandler.setResponceType("error");;
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("Uh oh! An error occurred, database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }

            //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            auditing.saveAuditRecord(jasonobj.get("user_username").toString(), related_table, auditType, record_pk, old_value, new_value);

        } catch (SQLException ex) {
            ex.printStackTrace();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("View_crossSellingData");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return responceHandler;

    }

    @Override
    public ResponceHandler verifyCrossSellingData(JSONObject jasonobj, int newStatus) {
        responceHandler = new ResponceHandler();
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        jsonObejcts = new JSONObjects();
        CrossSellingManagementModel newCrossSellingManagementModel;

        //Audit Trail
        Auditing auditing = new Auditing();
        String auditType = "UPDATE";
        String related_table = "gcsm_cross_selling_details";
        String record_pk = "";
        String old_value = "";

        try {
            newCrossSellingManagementModel = jsonObejcts.convertCrossSellingManagementModelToJSON(jasonobj.toString());
            String crossSellingRecordUpdate
                    = "UPDATE gcsm_cross_selling_details "
                    + "set cs_status=" + newStatus + ", "
                    + "cs_reject_reason=?, " //1
                    + "cs_modified_user=?, " //2
                    + "cs_modified_timestamp=now() "
                    + "where cs_id=?";              //3

            preparedStatement = currentConnection.prepareStatement(crossSellingRecordUpdate);
            preparedStatement.setString(1, newCrossSellingManagementModel.getCs_reject_reason());
            preparedStatement.setString(2, jasonobj.get("user_username").toString());
            preparedStatement.setInt(3, newCrossSellingManagementModel.getCs_id());

            //Audit Trail 
            record_pk = "" + newCrossSellingManagementModel.getCs_id();
            old_value = auditing.getAllRecords(record_pk, related_table).toString();

            if (preparedStatement.executeUpdate() <= 0) {

                responceHandler.setResponceModule("verify_Cross_Selling_Details");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to update this record.");

            }

            responceHandler.setResponceModule("verify_Cross_Selling_Details");
            responceHandler.setResponceType("success");
            responceHandler.setResponceCode("0000");
            responceHandler.setResponceDescription((newStatus == 1 || newStatus == 5) ? "Succefully Approved" : (newStatus == 2 || newStatus == 3 || newStatus == 4) ? "Succefully Sent for Revise" : "Successfully Rejected");

            if (!databaseConnection.end_Connection(currentConnection)) {

                responceHandler.setResponceModule("verify_Cross_Selling_Details");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("Uh oh! An error occurred, database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }

            //Audit Trail
            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
            auditing.saveAuditRecord(jasonobj.get("user_username").toString(), related_table, auditType, record_pk, old_value, new_value);

        } catch (SQLException ex) {
            ex.printStackTrace();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("verify_crossSellingData");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return responceHandler;
    }

    @Override
    public JSONArray viewCrossSellingClaims(JSONObject jasonobj) {
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();
        String username = jasonobj.get("user_username").toString();

        try {
            /*  cs_status 
             0   ->  Pending Approval from Line Head, 
             1   ->  Pending Approval from Product Owner, 
             -1  ->  Rejected by Line Head, 
             -2  ->  Rejected by Product Owner, 
             2   ->  Revision Required by Line Head, 
             3   ->  Revision Required by Product Owner, 
             4   ->  Revision Required by Finance Admin, 
             5   ->  Approved
             */
            String queryViewCrossSellingDetails = "SELECT cs_id, csowner.bl_name as cs_own_company, product_name as cs_product,cs_product_status, prodowner.bl_name as cs_product_owner, cs_customer_name, cs_customer_nic, cs_customer_contactNo, cs_cid, cs_fee, cs_emp_id, cs_employee_name, cs_units_sold_by, cs_date, cs_contract_no, cs_comment, cs_status, cs_setup_user, concat(user_name_first,' ',user_name_last) as full_name, cs_setup_timestamp, cs_modified_user, cs_modified_timestamp, cs_reject_reason FROM gcsm_cross_selling_details, gcsm_product, gcsm_businessline as csowner, gcsm_businessline as prodowner,gcsm_user WHERE cs_product=product_id and cs_setup_user=user_username and cs_own_company=csowner.bl_id and cs_product_owner=prodowner.bl_id and cs_status in(1,-2,5) and cs_product_owner in (select user_businessline from gcsm_user where user_username='" + username + "') ORDER BY cs_modified_timestamp DESC";

            

            preparedStatement = currentConnection.prepareStatement(queryViewCrossSellingDetails);
            resultSet = preparedStatement.executeQuery();
            int i = 0;
            while (resultSet.next()) {

                m_jsObj = new JSONObject();

                m_jsObj.put("cs_id", resultSet.getInt("cs_id"));
                m_jsObj.put("cs_own_company", resultSet.getString("cs_own_company"));
                m_jsObj.put("cs_product_owner", resultSet.getString("cs_product_owner"));
                m_jsObj.put("cs_product", resultSet.getString("cs_product"));
                m_jsObj.put("cs_product_status", resultSet.getString("cs_product_status"));
                m_jsObj.put("cs_customer_name", resultSet.getString("cs_customer_name"));
                m_jsObj.put("cs_customer_contactNo", resultSet.getString("cs_customer_contactNo"));
                m_jsObj.put("cs_customer_nic", resultSet.getString("cs_customer_nic"));
                m_jsObj.put("cs_cid", resultSet.getString("cs_cid"));
                m_jsObj.put("cs_fee", resultSet.getDouble("cs_fee"));
                m_jsObj.put("cs_emp_id", resultSet.getString("cs_emp_id"));
                m_jsObj.put("cs_employee_name", resultSet.getString("cs_employee_name"));
                m_jsObj.put("cs_units_sold_by", resultSet.getString("cs_units_sold_by"));
                m_jsObj.put("cs_date", resultSet.getString("cs_date"));
                m_jsObj.put("cs_contract_no", resultSet.getString("cs_contract_no"));
                m_jsObj.put("cs_comment", resultSet.getString("cs_comment"));
                m_jsObj.put("cs_status", resultSet.getInt("cs_status"));
                m_jsObj.put("cs_setup_user", resultSet.getString("cs_setup_user"));
                m_jsObj.put("full_name", resultSet.getString("full_name"));
                m_jsObj.put("cs_setup_timestamp", resultSet.getString("cs_setup_timestamp"));
                m_jsObj.put("cs_modified_user", resultSet.getString("cs_modified_user"));
                m_jsObj.put("cs_modified_timestamp", resultSet.getString("cs_modified_timestamp"));
                m_jsObj.put("cs_same_user_created", (username.equals(resultSet.getString("cs_setup_user")) ? 1 : 0));
                jsArr.put(i, m_jsObj);
                i++;

            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("View_crossSellingData");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return jsArr;
    }

    @Override
    public int getBusinessLineID(String businessLineName) {
        int businessLineID = 0;

        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            if (!databaseConnection.start_Connection(currentConnection)) {

            } else {
                String sql = "SELECT bl_id FROM gcsm_businessline where bl_name=?";

                preparedStatement = currentConnection.prepareStatement(sql);
                preparedStatement.setString(1, businessLineName);

                resultSet = preparedStatement.executeQuery();

                while (resultSet.next()) {
                    businessLineID = resultSet.getInt("bl_id");
                }
            }

        } catch (Exception e) {
            log.error(e.getMessage());
        
         } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("getBusinessLineID");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return businessLineID;
    }

    @Override
    public int getProductID(String productName) {
        int productID = 0;

       DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            if (!databaseConnection.start_Connection(currentConnection)) {

            } else {
                String sql = "SELECT product_id FROM gcsm_product where product_name=?";

                preparedStatement = currentConnection.prepareStatement(sql);
                preparedStatement.setString(1, productName);

                resultSet = preparedStatement.executeQuery();

                while (resultSet.next()) {
                    productID = resultSet.getInt("product_id");
                }
            }

        } catch (Exception e) {
            log.error(e.getMessage());
        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("getBusinessLineID");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }
        }
        return productID;
    }

    public ResponceHandler saveCrossSellingBulkData(List<CrossSellingManagementModel> CrossSellingManagementModelList, String username) {

        responceHandler = new ResponceHandler();
        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObjects jsonObejcts = new JSONObjects();
        PreparedStatement preparedStatement=null;
        ResultSet resultSet=null;

        //Audit Trail        
//        Auditing auditing = new Auditing();
//        String auditType = "INSERT";
//        String related_table = "gcsm_cross_selling_details";
//        String record_pk = "";
//        String old_value = "##Empty##";
        try {

            if (!databaseConnection.start_Connection(currentConnection)) {

                responceHandler.setResponceModule("saveCrossSelling");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("00001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection establishing problem.");

                log.error("Uh oh! An error occurred, database connection establishing problem.");
                throw new Exception("An error occurred, database connection establishing problem.");
            } else {
                String queryInsertCrossSellingDetails
                        = "INSERT INTO gcsm_cross_selling_details("
                        + "cs_own_company," //1
                        + "cs_product_owner," //2
                        + "cs_product," //3
                        + "cs_product_status," //4
                        + "cs_customer_name," //5
                        + "cs_customer_nic," //6
                        + "cs_customer_contactNo," //7
                        + "cs_cid," //8
                        + "cs_fee," //9
                        + "cs_emp_id," //10
                        + "cs_employee_name," //11
                        + "cs_units_sold_by," //12
                        + "cs_date," //13
                        + "cs_contract_no," //14
                        + "cs_comment," //15
                        + "cs_status," //16
                        + "cs_setup_user," //17
                        + "cs_modified_user," //18
                        + "cs_setup_timestamp,"
                        + "cs_modified_timestamp)"
                        + " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,now(),now())";

                preparedStatement = currentConnection.prepareStatement(queryInsertCrossSellingDetails, Statement.RETURN_GENERATED_KEYS);

                for (CrossSellingManagementModel crossSellingManagementModel : CrossSellingManagementModelList) {
                    preparedStatement.setInt(1, crossSellingManagementModel.getCs_own_company());
                    preparedStatement.setInt(2, crossSellingManagementModel.getCs_product_owner());
                    preparedStatement.setInt(3, crossSellingManagementModel.getCs_product());
                    preparedStatement.setString(4, crossSellingManagementModel.getCs_product_status());
                    preparedStatement.setString(5, crossSellingManagementModel.getCs_customer_name());
                    preparedStatement.setString(6, crossSellingManagementModel.getCs_customer_nic());
                    preparedStatement.setString(7, crossSellingManagementModel.getCs_customer_contactNo());
                    preparedStatement.setString(8, crossSellingManagementModel.getCs_cid());
                    preparedStatement.setDouble(9, crossSellingManagementModel.getCs_fee());
                    preparedStatement.setString(10, crossSellingManagementModel.getCs_emp_id());
                    preparedStatement.setString(11, crossSellingManagementModel.getCs_employee_name());
                    preparedStatement.setString(12, crossSellingManagementModel.getCs_units_sold_by());
                    preparedStatement.setString(13, crossSellingManagementModel.getCs_date());
                    preparedStatement.setString(14, crossSellingManagementModel.getCs_contract_no());
                    preparedStatement.setString(15, crossSellingManagementModel.getCs_comment());
                    preparedStatement.setInt(16, 0);
                    preparedStatement.setString(17, username);
                    preparedStatement.setString(18, username);
                    preparedStatement.addBatch();
                }

                int[] executeUpdate = preparedStatement.executeBatch();
                resultSet = preparedStatement.getGeneratedKeys();
            }

            while (resultSet.next()) {
                //Audit Trail
//                record_pk = "" + (resultSet.getInt(1));

            }

            responceHandler.setResponceModule("saveCrossSelling");
            responceHandler.setResponceType("success");
            responceHandler.setResponceCode("0000");
            responceHandler.setResponceDescription("Awesome! You were successful.");

            if (!databaseConnection.end_Connection(currentConnection)) {

                responceHandler.setResponceModule("saveCrossSelling");
                responceHandler.setResponceType("error");;
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Uh oh! An error occurred, database connection terminating problem.");

                log.error("Uh oh! An error occurred, database connection terminating problem.");
                throw new Exception("An error occurred, database connection terminating problem.");
            }

            //Audit Trail
//            String new_value = auditing.getAllRecords(record_pk, related_table).toString();
//            auditing.saveAuditRecord(jasonobj.get("user_username").toString(), related_table, auditType, record_pk, old_value, new_value);
        } catch (Exception e) {
            log.error(e.getMessage());

            responceHandler.setResponceModule("saveCrossSelling");
            responceHandler.setResponceType("error");
            responceHandler.setResponceCode("00002");
            responceHandler.setResponceDescription("Uh oh! An error occurred, and we were unable to insert this record.\n" + e);

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                log.error(e.getMessage());
                responceHandler.setResponceModule("saveCrossSelling");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");

            }

        }

        return responceHandler;
    }

    @Override
    public boolean checkFeeIncomeApplicability(String productID) {
        boolean isFeeIncomeApplicable=true;

        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        try {
            if (!databaseConnection.start_Connection(currentConnection)) {

            } else {
                String sql = "select product_shadow_basis from gcsm_product where product_id=? and product_shadow_basis='Annual Fee';";

                preparedStatement = currentConnection.prepareStatement(sql);
                preparedStatement.setString(1, productID);

                resultSet = preparedStatement.executeQuery();

                if (resultSet.first()) {
                    isFeeIncomeApplicable = false;
                }
            }

        } catch (Exception e) {
            log.error(e.getMessage());
        }        
        return isFeeIncomeApplicable;
    }
    
    private boolean getWhetherShadowCalculated(String cs_date) {
        boolean isShadowCalculated=false;
        String year=cs_date.split("-")[0];
        String month=cs_date.split("-")[1];

        DatabaseConnection databaseConnection = DatabaseConnection.getInstance();
        Connection currentConnection = databaseConnection.get_JDBC_Connection();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {

            String sql = "select * from gcsm_shadow_revenue where shadow_year_month=?";
            preparedStatement = currentConnection.prepareStatement(sql);
            preparedStatement.setString(1, (year+""+month));
            resultSet = preparedStatement.executeQuery();

            if (resultSet.first()) {
               isShadowCalculated=true;
            }

           

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (currentConnection != null) {
                    currentConnection.close();
                }
            } catch (Exception e) {
                log.error(e.getMessage());
            }
        }
        return isShadowCalculated;
    }

}
