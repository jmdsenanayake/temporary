/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.CrossSelling.DAO;

import gcsm.Utitlities.Model.ResponceHandler;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Janaka_5977
 */
public interface ShadowRevenueDAO {
    
     public JSONArray getShadowRevenueDetails(JSONObject jasonobj);
     
     public ResponceHandler verifyShadowRevenueData(JSONObject jasonobj,int verifyReject);
     
     public JSONArray otherShadowRevenueBasisDetails(JSONObject jasonobj);    
     
     public ResponceHandler insertUpdateOtherAmount(String contractNo, String yearMonth, double amount,String username);

    public JSONArray getOtherContractValues(JSONObject data);
    
    public ResponceHandler insertUpdateOtherContractValues(String contractNo, String yearMonth, double value,String username);
    
    public ResponceHandler eraseShadowRevenueData(String shadowYearMonth,String username);

    public boolean checkIsValidYearMonth(String cs_date);

    public boolean checkIsSahdowCalculationRunning();
}
