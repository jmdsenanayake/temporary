/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.CrossSelling.Controller;

import gcsm.CrossSelling.DAO.CrossSellingManagementDAO;
import gcsm.CrossSelling.DAO.Impl.CrossSellingManagementDAOImpl;
import gcsm.Utitlities.Model.ResponceHandler;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Janaka_5977
 */
public class CrossSellingManagementController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    static Logger log = LogManager.getLogger(CrossSellingManagementController.class.getName());
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JSONObject result = new JSONObject();
        JSONObject data = new JSONObject();
        String m_strfunction = "";
        PrintWriter out = response.getWriter();
        ResponceHandler responceHandler;
        JSONArray jsArr = null;
        HttpSession session = request.getSession(false);
        String username=session.getAttribute("session_username").toString();
        String roleType=session.getAttribute("session_role_type").toString();
        

        try {

            Enumeration enumeration = request.getParameterNames();
            while (enumeration.hasMoreElements()) {

                String parameterName = (String) enumeration.nextElement();
                if (parameterName.equalsIgnoreCase("functionName")) {
                    m_strfunction = request.getParameter(parameterName);
                } else {
                    data.put(parameterName, request.getParameter(parameterName));
                }
            }

            CrossSellingManagementDAO crossSellingManagementDAO = new CrossSellingManagementDAOImpl();
            data.put("user_username", username);
            data.put("session_role_type", roleType);
            if (m_strfunction.equalsIgnoreCase("saveCrossSelling")) {
               
               responceHandler = crossSellingManagementDAO.saveCrossSellingData(data);
                if (responceHandler.getResponceType().equals("success")) {
                    result.put(responceHandler.getResponceType().trim(), responceHandler.getResponceDescription().trim());
                    out.print(result);
                } else {

                    result.put(responceHandler.getResponceType().trim(), responceHandler.getResponceDescription().trim());
                    out.print(result);
                }
            }
            
            else if(m_strfunction.equalsIgnoreCase("viewCrossSelling")) {
                jsArr = crossSellingManagementDAO.viewCrossSellingData(data);
                out.print(jsArr);
                log("Output Returned with "+jsArr.length()+" records");
            }
            else if(m_strfunction.equalsIgnoreCase("viewCrossSellingClaims")) {
                jsArr = crossSellingManagementDAO.viewCrossSellingClaims(data);
                out.print(jsArr);
                log("Output Returned with "+jsArr.length()+" records");
            }
            
            else if(m_strfunction.equalsIgnoreCase("getInfoCrossSelling")) {
                data.put("cs_id", request.getParameter("cs_id"));
                jsArr = crossSellingManagementDAO.getInfoCrossSelling(data);
                out.print(jsArr);
                log("Output Returned with "+jsArr.length()+" records");
            }
            
            else if (m_strfunction.equalsIgnoreCase("updateCrossSelling")) {
               responceHandler = crossSellingManagementDAO.updateCrossSellingData(data);
                if (responceHandler.getResponceType().equals("success")) {
                    result.put(responceHandler.getResponceType().trim(), responceHandler.getResponceDescription().trim());
                    out.print(result);
                } else {

                    result.put(responceHandler.getResponceType().trim(), responceHandler.getResponceDescription().trim());
                    out.print(result);
                }
            }
            
            else if(m_strfunction.equalsIgnoreCase("verifyInfoCrossSelling")){
                String approvalType=data.get("approvalType").toString().trim();
                String rejectReviseApprove=data.get("rejectReviseApprove").toString().trim();
                int newStatus=0;
                
                if(approvalType.equals("line_head")){
                    if(rejectReviseApprove.equals("reject")){
                        newStatus=-1;
                    }
                    else if(rejectReviseApprove.equals("revise")){
                        newStatus=2;
                    }
                    else if(rejectReviseApprove.equals("approve")){
                        newStatus=1;
                    }
                }
                else if(approvalType.equals("prod_owner")){
                     if(rejectReviseApprove.equals("reject")){
                        newStatus=-2;
                    }
                    else if(rejectReviseApprove.equals("revise")){
                        newStatus=3;
                    }
                    else if(rejectReviseApprove.equals("approve")){
                        newStatus=5;
                    }
                
                }
                else if(approvalType.equals("finance")){
                    if(rejectReviseApprove.equals("revise")){
                        newStatus=4;
                    }
                }     
                responceHandler = crossSellingManagementDAO.verifyCrossSellingData(data,newStatus);
                if (responceHandler.getResponceType().equals("success")) {
                    result.put(responceHandler.getResponceType().trim(), responceHandler.getResponceDescription().trim());
                    out.print(result);
                } else {

                    result.put(responceHandler.getResponceType().trim(), responceHandler.getResponceDescription().trim());
                    out.print(result);
                }
            }
            
            else if(m_strfunction.equals("checkFeeIncomeApplicability")){
                boolean isFeeIncomeApplicble = crossSellingManagementDAO.checkFeeIncomeApplicability((String)data.getString("product_id"));               
                 if (isFeeIncomeApplicble) {
                    result.put("success", "Fee Income Applicable");
                    out.print(result);
                } else {
                   result.put("error", "Fee Income Not applicable");
                    out.print(result);
                }
            }
//            else if(m_strfunction.equalsIgnoreCase("rejectInfoCrossSelling")){
//                responceHandler = crossSellingManagementDAO.verifyCrossSellingData(data,-1);
//                if (responceHandler.getResponceType().equals("success")) {
//                    result.put(responceHandler.getResponceType().trim(), responceHandler.getResponceDescription().trim());
//                    out.print(result);
//                } else {
//
//                    result.put(responceHandler.getResponceType().trim(), responceHandler.getResponceDescription().trim());
//                    out.print(result);
//                }
//            }
//            else if(m_strfunction.equalsIgnoreCase("reviseInfoCrossSelling")){
//                responceHandler = crossSellingManagementDAO.verifyCrossSellingData(data,2);
//                if (responceHandler.getResponceType().equals("success")) {
//                    result.put(responceHandler.getResponceType().trim(), responceHandler.getResponceDescription().trim());
//                    out.print(result);
//                } else {
//
//                    result.put(responceHandler.getResponceType().trim(), responceHandler.getResponceDescription().trim());
//                    out.print(result);
//                }
//            }

        } catch (Exception e) {
            log.error(e.getMessage());
           if ((session.getAttribute("session_username") == null) || (session.getAttribute("session_username") == "")) {
            response.sendRedirect("../Common/LoginPage.jsp");
        }
        }

        out.flush();
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
