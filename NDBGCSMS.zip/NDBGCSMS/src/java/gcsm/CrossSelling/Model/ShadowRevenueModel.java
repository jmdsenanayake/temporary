/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.CrossSelling.Model;

/**
 *
 * @author Janaka_5977
 */
public class ShadowRevenueModel {
    private int shadow_revenue_id;
    private String shadow_cs_contract_no;
    private String shadow_year_month;
    private double shadow_NII_value;
    private double shadow_fee_income;
    private double shadow_annual_fee;
    private double shadow_revenue_value;
    private int shadow_revenue_status;
    private String shadow_reject_reason;

    /**
     * @return the shadow_revenue_id
     */
    public int getShadow_revenue_id() {
        return shadow_revenue_id;
    }

    /**
     * @param shadow_revenue_id the shadow_revenue_id to set
     */
    public void setShadow_revenue_id(int shadow_revenue_id) {
        this.shadow_revenue_id = shadow_revenue_id;
    }

    /**
     * @return the shadow_cs_contract_no
     */
    public String getShadow_cs_contract_no() {
        return shadow_cs_contract_no;
    }

    /**
     * @param shadow_cs_contract_no the shadow_cs_contract_no to set
     */
    public void setShadow_cs_contract_no(String shadow_cs_contract_no) {
        this.shadow_cs_contract_no = shadow_cs_contract_no;
    }

    /**
     * @return the shadow_year_month
     */
    public String getShadow_year_month() {
        return shadow_year_month;
    }

    /**
     * @param shadow_year_month the shadow_year_month to set
     */
    public void setShadow_year_month(String shadow_year_month) {
        this.shadow_year_month = shadow_year_month;
    }

    /**
     * @return the shadow_NII_value
     */
    public double getShadow_NII_value() {
        return shadow_NII_value;
    }

    /**
     * @param shadow_NII_value the shadow_NII_value to set
     */
    public void setShadow_NII_value(double shadow_NII_value) {
        this.shadow_NII_value = shadow_NII_value;
    }

    /**
     * @return the shadow_fee_income
     */
    public double getShadow_fee_income() {
        return shadow_fee_income;
    }

    /**
     * @param shadow_fee_income the shadow_fee_income to set
     */
    public void setShadow_fee_income(double shadow_fee_income) {
        this.shadow_fee_income = shadow_fee_income;
    }

    /**
     * @return the shadow_annual_fee
     */
    public double getShadow_annual_fee() {
        return shadow_annual_fee;
    }

    /**
     * @param shadow_annual_fee the shadow_annual_fee to set
     */
    public void setShadow_annual_fee(double shadow_annual_fee) {
        this.shadow_annual_fee = shadow_annual_fee;
    }

    /**
     * @return the shadow_revenue_value
     */
    public double getShadow_revenue_value() {
        return shadow_revenue_value;
    }

    /**
     * @param shadow_revenue_value the shadow_revenue_value to set
     */
    public void setShadow_revenue_value(double shadow_revenue_value) {
        this.shadow_revenue_value = shadow_revenue_value;
    }

    /**
     * @return the shadow_revenue_status
     */
    public int getShadow_revenue_status() {
        return shadow_revenue_status;
    }

    /**
     * @param shadow_revenue_status the shadow_revenue_status to set
     */
    public void setShadow_revenue_status(int shadow_revenue_status) {
        this.shadow_revenue_status = shadow_revenue_status;
    }

    /**
     * @return the shadow_reject_reason
     */
    public String getShadow_reject_reason() {
        return shadow_reject_reason;
    }

    /**
     * @param shadow_reject_reason the shadow_reject_reason to set
     */
    public void setShadow_reject_reason(String shadow_reject_reason) {
        this.shadow_reject_reason = shadow_reject_reason;
    }
}
