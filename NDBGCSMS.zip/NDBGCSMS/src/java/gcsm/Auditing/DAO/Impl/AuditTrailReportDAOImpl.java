/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Auditing.DAO.Impl;

import gcsm.Auditing.DAO.AduitTrailReportDAO;
import gcsm.Utitlities.Impl.DatabaseConnection;
import gcsm.Utitlities.Impl.JSONObjects;
import gcsm.Utitlities.Model.ResponceHandler;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
/**
 *
 * @author Janaka_5977
 */
public class AuditTrailReportDAOImpl implements AduitTrailReportDAO{
    
    static Logger log = LogManager.getLogger(AuditTrailReportDAOImpl.class.getName());
    private ResponceHandler responceHandler;
    static DatabaseConnection databaseConnection;
    static Connection currentConnection = null;
    private PreparedStatement preparedStatement = null;
    private ResultSet resultSet = null;
    private JSONObjects jsonObejcts;
    private JSONArray jsArr;

    @Override
    public JSONArray fillAdutiTrailReportContent(JSONObject jasonobj) {
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();

        String reportFrom = jasonobj.getString("reportFrom");
        String reportTo = jasonobj.getString("reportTo");
        try {

            //String queryViewCrossSellingReports = "SELECT shadow_year_month,cs_own_company, cs_product_owner,shadow_cs_contract_no,shadow_NII_value,portfolio_value FROM gcsm_cross_selling_details, gcsm_shadow_revenue, gcsm_reward_details where shadow_cs_contract_no=cs_contract_no and cs_contract_no=reward_contract_no and shadow_year_month='" + yearMonth + "' and cs_own_company='"+ownCompany+"'";           
            String queryViewCrossSellingFeeIncomeReports = ""
                    + "SELECT * FROM gcsm_auditing where date(`current_timestamp`) between ? and ?  and related_table!='gcsm_user' order by audit_id desc";

         

            preparedStatement = currentConnection.prepareStatement(queryViewCrossSellingFeeIncomeReports);
            preparedStatement.setString(1, reportFrom);
            preparedStatement.setString(2, reportTo);
            resultSet = preparedStatement.executeQuery();
            System.out.println(preparedStatement);
            int i = 0;
            while (resultSet.next()) {
                m_jsObj = new JSONObject();

                m_jsObj.put("audit_id", resultSet.getString("audit_id"));
                m_jsObj.put("current_timestamp", resultSet.getString("current_timestamp"));
                m_jsObj.put("current_user", resultSet.getString("current_user"));
                m_jsObj.put("related_table", resultSet.getString("related_table"));
                m_jsObj.put("dml_type", resultSet.getString("dml_type"));
                m_jsObj.put("record_pk", resultSet.getString("record_pk"));
                m_jsObj.put("previous_value", resultSet.getString("previous_value"));
                m_jsObj.put("new_value", resultSet.getString("new_value"));
                
                jsArr.put(i, m_jsObj);
                i++;
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                responceHandler.setResponceModule("View_AuditTrailReport");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");
                log.error(e.getMessage());
            }
        }

        return jsArr;
    }
    
    @Override
    public JSONArray fillLoginHistoryReportContent(JSONObject jasonobj) {
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();

        String reportFrom = jasonobj.getString("reportFrom");
        String reportTo = jasonobj.getString("reportTo");
        try {

            //String queryViewCrossSellingReports = "SELECT shadow_year_month,cs_own_company, cs_product_owner,shadow_cs_contract_no,shadow_NII_value,portfolio_value FROM gcsm_cross_selling_details, gcsm_shadow_revenue, gcsm_reward_details where shadow_cs_contract_no=cs_contract_no and cs_contract_no=reward_contract_no and shadow_year_month='" + yearMonth + "' and cs_own_company='"+ownCompany+"'";           
            String queryViewCrossSellingFeeIncomeReports = ""
                    + "SELECT * FROM gcsm_user_login_trail where date(`login_timestamp`) between ? and ?  order by login_trail_id desc";

            

            preparedStatement = currentConnection.prepareStatement(queryViewCrossSellingFeeIncomeReports);
            preparedStatement.setString(1, reportFrom);
            preparedStatement.setString(2, reportTo);
            resultSet = preparedStatement.executeQuery();
            System.out.println(preparedStatement);
            int i = 0;
            while (resultSet.next()) {
                m_jsObj = new JSONObject();

                m_jsObj.put("login_trail_id", resultSet.getString("login_trail_id"));
                m_jsObj.put("login_username", resultSet.getString("login_username"));
                m_jsObj.put("login_timestamp", resultSet.getString("login_timestamp"));
                m_jsObj.put("logout_timestamp", resultSet.getString("logout_timestamp"));
                
                jsArr.put(i, m_jsObj);
                i++;
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                responceHandler.setResponceModule("fillLoginHistoryReportContent");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");
                log.error(e.getMessage());
            }
        }

        return jsArr;
    }

    @Override
    public JSONArray fillAdutiTrailReportContentSMS(JSONObject jasonobj) {
        databaseConnection = DatabaseConnection.getInstance();
        currentConnection = databaseConnection.get_JDBC_Connection();
        JSONObject m_jsObj;
        jsArr = new JSONArray();

        String reportFrom = jasonobj.getString("reportFrom");
        String reportTo = jasonobj.getString("reportTo");
        try {

            //String queryViewCrossSellingReports = "SELECT shadow_year_month,cs_own_company, cs_product_owner,shadow_cs_contract_no,shadow_NII_value,portfolio_value FROM gcsm_cross_selling_details, gcsm_shadow_revenue, gcsm_reward_details where shadow_cs_contract_no=cs_contract_no and cs_contract_no=reward_contract_no and shadow_year_month='" + yearMonth + "' and cs_own_company='"+ownCompany+"'";           
            String queryViewCrossSellingFeeIncomeReports = ""
                    + "SELECT * FROM gcsm_auditing where date(`current_timestamp`) between ? and ? and related_table='gcsm_user' order by audit_id desc";

            

            preparedStatement = currentConnection.prepareStatement(queryViewCrossSellingFeeIncomeReports);
            preparedStatement.setString(1, reportFrom);
            preparedStatement.setString(2, reportTo);
            resultSet = preparedStatement.executeQuery();
            System.out.println(preparedStatement);
            int i = 0;
            while (resultSet.next()) {
                m_jsObj = new JSONObject();

                m_jsObj.put("audit_id", resultSet.getString("audit_id"));
                m_jsObj.put("current_timestamp", resultSet.getString("current_timestamp"));
                m_jsObj.put("current_user", resultSet.getString("current_user"));
                m_jsObj.put("related_table", resultSet.getString("related_table"));
                m_jsObj.put("dml_type", resultSet.getString("dml_type"));
                m_jsObj.put("record_pk", resultSet.getString("record_pk"));
                m_jsObj.put("previous_value", resultSet.getString("previous_value"));
                m_jsObj.put("new_value", resultSet.getString("new_value"));
                
                jsArr.put(i, m_jsObj);
                i++;
            }

        } catch (Exception e) {
            log.error(e.getMessage());

        } finally {

            try {

                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }

                if (currentConnection != null) {
                    currentConnection.close();
                }

            } catch (Exception e) {
                responceHandler.setResponceModule("View_AuditTrailReport");
                responceHandler.setResponceType("error");
                responceHandler.setResponceCode("0001");
                responceHandler.setResponceDescription("Error occured in insert user role");
                log.error(e.getMessage());
            }
        }

        return jsArr;
    }
    
}
