/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gcsm.Auditing.DAO;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Janaka_5977
 */
public interface AduitTrailReportDAO {

    public JSONArray fillAdutiTrailReportContent(JSONObject data);
    
    public JSONArray fillLoginHistoryReportContent(JSONObject jasonobj);

    public JSONArray fillAdutiTrailReportContentSMS(JSONObject data);
    
}
